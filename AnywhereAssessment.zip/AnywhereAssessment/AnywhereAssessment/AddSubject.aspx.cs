﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI;
using BL;

namespace AnywhereAssessment
{
    public partial class WebForm4 : System.Web.UI.Page
    {

        SqlConnection con = new SqlConnection(Properties.Settings.Default.constring);
        public static List<string> subjects = new List<string>() { "Maths", "English", "Science" };


        protected void Page_Load(object sender, EventArgs e)
        {
            SqlCommand cmd;
            SqlDataAdapter da;
            DataTable dt = new DataTable();
            DataRow dr;

            con.Open();

            da = new SqlDataAdapter("SELECT * FROM SUBJECT_DETAILS;", con);
            da.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dr = dt.Rows[i];
                ListBox1.Items.Add(dr[1].ToString());
            }
            con.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int flag = 0;


            SqlCommand cmd;
            SqlDataAdapter da;
            DataTable dt = new DataTable();
            DataRow dr;

            con.Open();

            da = new SqlDataAdapter("SELECT * FROM SUBJECT_DETAILS;", con);
            da.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dr = dt.Rows[i];

                if (TextBox1.Text.ToString().Equals(dr[1].ToString()))
                {
                    //MessageBox.Show("Subject Already present");
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Subject Already Present');", true);
                    flag = 1;
                    break;
                }

            }
            
            if (flag == 0)
            {


                Subject s = new Subject();
                

                    s.subject = TextBox1.Text;
                    s.AddSubject();
                

                //string query = "INSERT INTO SUBJECT_DETAILS " + "Values('" + TextBox1.Text + "');";

                //cmd = new SqlCommand(query, con);
                //cmd.ExecuteNonQuery();


                subjects.Add(TextBox1.Text);
                //MessageBox.Show("Subject Added Successfully");
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Subject Added Successfully');", true);

                TextBox1.Text = "";
            }

            ListBox1.Items.Clear();

            con.Close();

            //foreach (string s in subjects)
            //{

            //    listBox1.Items.Add(s);
            //}

            con.Open();

            SqlDataAdapter da2;
            DataTable dt2 = new DataTable();

            da2 = new SqlDataAdapter("SELECT * FROM SUBJECT_DETAILS;", con);
            da2.Fill(dt2);

            for (int i = 0; i < dt2.Rows.Count; i++)
            {
                dr = dt2.Rows[i];
                ListBox1.Items.Add(dr[1].ToString());
            }
            con.Close();
        }
    }
}