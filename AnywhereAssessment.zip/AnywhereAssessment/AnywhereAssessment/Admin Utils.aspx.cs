﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AnywhereAssessment
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //Session["examid"] = "";
                //Session.Timeout = 1;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (RadioButtonList1.SelectedItem.Text.Equals("Exam Setup"))
            {
                LinkButton1.PostBackUrl = "~/Exam Setup.aspx";
            }
            else if (RadioButtonList1.SelectedItem.Text.Equals("View Registered Users"))
            {
                LinkButton1.PostBackUrl = "~/View Registration.aspx";
            }
            else if (RadioButtonList1.SelectedItem.Text.Equals("Add Subject"))
            {
                LinkButton1.PostBackUrl = "~/AddSubject.aspx";
            }
            else if (RadioButtonList1.SelectedItem.Text.Equals("View Results"))
            {
                LinkButton1.PostBackUrl = "~/ViewResults.aspx";
            }
            else if (RadioButtonList1.SelectedItem.Text.Equals("Update Exam"))
            {
                LinkButton1.PostBackUrl = "~/ExamUpdate.aspx";
            }
            
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            
        }
    }
}