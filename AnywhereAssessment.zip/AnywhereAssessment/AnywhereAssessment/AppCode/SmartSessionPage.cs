﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AnywhereAssessment.App_Code
{
    public class SmartSessionPage : System.Web.UI.Page
    {
        private const string uname = "UserName";
        public string UserName
        {
            get
            {
                return (string)Session[uname];
            }
            set
            {
                Session[uname] = value;
            }
        }

        public void logOut()
        {
            Session.Abandon();
            Response.Redirect("LoginContent.aspx");
        }
    }
}