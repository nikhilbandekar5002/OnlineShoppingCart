﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using BL;

namespace AnywhereAssessment
{
    public partial class WebForm2 : System.Web.UI.Page
    {

        public string url { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            url = Button1.PostBackUrl;

            if (!this.IsPostBack)
            {
                SqlConnection con = new SqlConnection("Data Source=DEV106;Initial Catalog=ANYWHERE_ASSESSMENT_SYSTEM;User ID=sa");
                SqlCommand cmd;
                SqlDataAdapter da;
                DataTable dt = new DataTable();
                DataRow dr;

                Dictionary<int, string> sub = new Dictionary<int, string>();

                con.Open();

                da = new SqlDataAdapter("SELECT * FROM SUBJECT_DETAILS;", con);
                da.Fill(dt);


                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dr = dt.Rows[i];
                    sub.Add(Convert.ToInt32(dr[0].ToString()), dr[1].ToString());
                }
                con.Close();
                //for (int i = 0; i < AddSubject.subjects.Count; i++ )
                //    comboBox1.Items.Add(AddSubject.subjects[i]);
                DropDownList1.DataSource = sub;

                DropDownList1.DataTextField = "Value";
                DropDownList1.DataValueField = "Key";
                DropDownList1.DataBind();
                //comboBox1.SelectedText = "Math";

                SqlDataAdapter da2;
                DataTable dt2 = new DataTable();

                con.Open();

                da2 = new SqlDataAdapter("SELECT MAX(EXAM_ID) + 1 FROM EXAM_DETAILS;", con);
                da2.Fill(dt2);

                dr = dt2.Rows[0];


                //if (dr[0] == null)
                //{
                //    TextBox4.Text = "1";
                //}
                //else
                //{
                    TextBox4.Text = dr[0].ToString();
                ////}

                con.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.constring);
            SqlCommand cmd;
            SqlDataAdapter da;




            //QuestionPaper quespaper = new QuestionPaper(Convert.ToInt32(TextBox4.Text), Convert.ToInt32(TextBox2.Text), Convert.ToInt32(TextBox3.Text));
            // quespaper.AddExamDtls(comboBox1.SelectedText, Convert.ToInt32(TextBox2.Text), Convert.ToInt32(TextBox3.Text), Convert.ToInt32(TextBox4.Text), Convert.ToInt32(TextBox1.Text),dateTimePicker1.Value);

            //con.Open();


            //string query = "INSERT INTO EXAM_DETAILS " + "Values('" + DropDownList1.SelectedValue + "','" + Convert.ToInt32(TextBox1.Text) + "'," + Convert.ToInt32(TextBox2.Text) + ",'" + Convert.ToInt32(TextBox3.Text) + "');";

            //cmd = new SqlCommand(query, con);
            //cmd.ExecuteNonQuery();

            //con.Close();

            //quespaper.Show();

           // this.Close();
            //Button1.PostBackUrl
        }

        public class ComboBoxItem
        {
            public string Text { get; set; }
            public int Value { get; set; }

            public override string ToString()
            {
                return Text;
            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
           

            
         //   Button1.PostBackUrl = url + "?noq=" + TextBox2.Text + ",marks=" + TextBox3.Text + ",examid=" + TextBox4.Text;
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
           // Button1.PostBackUrl = url + "?noq=" + TextBox2.Text + ",marks=" + TextBox3.Text + ",examid=" + TextBox4.Text;

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {
          //  Button1.PostBackUrl = url + "?noq=" + TextBox2.Text + ",marks=" + TextBox3.Text + ",examid=" + TextBox4.Text;

        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {
            //Button1.PostBackUrl = url + "?noq=" + TextBox2.Text + "&marks=" + TextBox3.Text + "&examid=" + TextBox4.Text;

        }

        protected void TextBox4_TextChanged(object sender, EventArgs e)
        {
          //  Button1.PostBackUrl = url + "?noq=" + TextBox2.Text + ",marks=" + TextBox3.Text + ",examid=" + TextBox4.Text;

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = new SqlConnection(Properties.Settings.Default.constring);
                SqlCommand cmd;
                SqlDataAdapter da;

                EXAMDETAILS ex = new EXAMDETAILS();
                ex.subjectcode = Convert.ToInt32(DropDownList1.SelectedValue);
                ex.duration = Convert.ToInt32(TextBox1.Text);
                ex.noofquestions = Convert.ToInt32(TextBox2.Text);
                ex.marks = Convert.ToInt32(TextBox3.Text);
                ex.examid = Convert.ToInt32(TextBox4.Text);
                ex.ExamDtls_Insert();

                Application["examid"] = ex.examid;
                Application["pendmarks"] = ex.marks;
                Application["noq"] = ex.noofquestions;
                string redirecturl = "~/QuestionPaper.aspx?examid=" + ex.examid;
                Response.Redirect("~/QuestionPaper.aspx?examid=" + ex.examid);
                // QuestionPaper quespaper = new QuestionPaper(Convert.ToInt32(textBox4.Text), Convert.ToInt32(textBox2.Text), Convert.ToInt32(textBox3.Text));
                // quespaper.AddExamDtls(comboBox1.SelectedText, Convert.ToInt32(textBox2.Text), Convert.ToInt32(textBox3.Text), Convert.ToInt32(textBox4.Text), Convert.ToInt32(textBox1.Text),dateTimePicker1.Value);

                //con.Open();


                //string query = "INSERT INTO EXAM_DETAILS " + "Values('" + DropDownList1.SelectedValue + "','" + Convert.ToInt32(TextBox1.Text) + "'," + Convert.ToInt32(TextBox2.Text) + ",'" + Convert.ToInt32(TextBox3.Text) + "');";

                //cmd = new SqlCommand(query, con);
                //cmd.ExecuteNonQuery();


                //quespaper.Show();

                //this.Close();
            }
            catch(Exception ex)
            {
                Response.Write("<script>alert('Please Enter Valid Data in the Fields');</script>");
            }
            
        }
    }
}