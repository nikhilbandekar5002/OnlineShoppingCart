﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BL;
using System.Data.Linq;
using DL;
using AnywhereAssessment.App_Code;

namespace AnywhereAssessment
{
    public partial class LoginContent : SmartSessionPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            LoginDetails ld = new LoginDetails();
            ld.password = TextBox2.Text;
            ld.userID = TextBox1.Text;

            string loginResult = ld.LoginSP();

            if (loginResult != null)
            {
                UserName = loginResult;
                if (UserName == "Admin")
                    Response.Redirect("Admin Utils.aspx");
                else
                    Response.Redirect("ViewExamHistory.aspx");
            }
            else
            {
                Response.Write("<script>alert('Invalid Credentials')</script>");
            }
        }

        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}