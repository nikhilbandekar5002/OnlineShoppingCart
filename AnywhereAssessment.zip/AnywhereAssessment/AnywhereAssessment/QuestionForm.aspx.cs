﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AnywhereAssessment.App_Code;
using BL;

namespace AnywhereAssessment
{
    public partial class QuestionForm : SmartSessionPage
    {
        DataRow dr;
        DataTable dt;
        int i = 0;
        int marks = 0;
        int timeLeft;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (UserName == null)
                Response.Redirect("LoginContent.aspx");
            else
            {
                if (!IsPostBack)
                {
                    int examID = Convert.ToInt32(Request.QueryString["EID"]);
                    ViewState["ExamID"] = examID.ToString();
                    Exams ex = new Exams();
                    ex.examID = examID;
                    DataTable exams = ex.getByID();
                    ViewState["TotalMarks"] = exams.Rows[0][4];
                    ViewState["timeLeft"] = exams.Rows[0][2];
                    timeLeft = Convert.ToInt32(ViewState["timeLeft"]);
                    
                    Questions q = new Questions();
                    q.ExamID = examID;
                    dt = q.findByExamId();
                    if (dt.Rows.Count > 0)
                    {
                        dr = dt.Rows[0];
                        Label1.Text = dr[2].ToString();
                        RadioButton1.Text = dr[3].ToString();
                        RadioButton2.Text = dr[4].ToString();
                        RadioButton3.Text = dr[5].ToString();
                        RadioButton4.Text = dr[6].ToString();
                    }
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                i = Convert.ToInt32(ViewState["i"]);
                marks = Convert.ToInt32(ViewState["marks"]);
                i++;

                Questions q = new Questions();
                q.ExamID = Convert.ToInt32(ViewState["ExamID"]);

                dt = q.findByExamId();
                dr = dt.Rows[i-1];

                if (RadioButton1.Checked)
                {
                    if (dr[7].ToString() == "A")
                        marks += Convert.ToInt32(dr[8]);
                }

                if (RadioButton2.Checked)
                {
                    if (dr[7].ToString() == "B")
                        marks += Convert.ToInt32(dr[8]);
                }

                if (RadioButton3.Checked)
                {
                    if (dr[7].ToString() == "C")
                        marks += Convert.ToInt32(dr[8]);
                }

                if (RadioButton4.Checked)
                {
                    if (dr[7].ToString() == "D")
                        marks += Convert.ToInt32(dr[8]);
                }

                if (dt.Rows.Count > i)
                {
                    dr = dt.Rows[i];
                    Label1.Text = dr[2].ToString();
                    RadioButton1.Text = dr[3].ToString();
                    RadioButton2.Text = dr[4].ToString();
                    RadioButton3.Text = dr[5].ToString();
                    RadioButton4.Text = dr[6].ToString();
                    //i++;
                }

                else
                {
                    ViewState["marks"] = marks.ToString();
                    saveData();
                }

                ViewState["i"] = i.ToString();
                ViewState["marks"] = marks.ToString();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        public void saveData()
        {
            ExamHistory eh = new ExamHistory();

            string grade;

            Decimal marksObtained = Convert.ToDecimal(ViewState["marks"]);
            Decimal total = Convert.ToDecimal(ViewState["TotalMarks"]);

            float per =(float)marksObtained / (float)total;

            if (per >= 0.9)
                grade = "A";
            else if (per >= 0.7)
                grade = "B";
            else if (per >= 0.6)
                grade = "C";
            else if (per >= 0.5)
                grade = "D";
            else 
                grade = "F";

            eh.userID = UserName;
            eh.examID = Convert.ToInt32(ViewState["ExamID"]);
            eh.score = Convert.ToInt32(ViewState["marks"]);
            eh.result = grade;
            eh.insert();
            Response.Redirect("QuestionsExitPage.aspx?eid=" + ViewState["ExamID"].ToString() + "&grade=" + grade + "&marks=" + ViewState["marks"].ToString());

        }

        protected void Timer1_Tick(object sender, EventArgs e)
        {
            timeLeft = Convert.ToInt32(ViewState["timeLeft"]);
            timeLeft--;
            Label2.Text = timeLeft.ToString();

            ViewState["timeLeft"] = timeLeft.ToString();

            if (timeLeft <= 5)
                Label2.ForeColor = ColorTranslator.FromHtml("#e74c3c");

            if (timeLeft == 0)
            {
                saveData();
            }

        }
    }
}
