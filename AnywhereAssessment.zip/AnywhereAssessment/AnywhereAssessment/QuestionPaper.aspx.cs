﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using BL;
using System.Data;

namespace AnywhereAssessment
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        public  int quesCounter {get; set;}

        DataTable dt;
        DataRow dr;

        public static List<Question> questions;

        public string subject { get; set; }
        public int noofques { get; set; }
        public int marks { get; set; }
        public int examid { get; set; }
        public int duration { get; set; }
        public DateTime examdate { get; set; }
        public static int pendmarks { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                ViewState["marks"] = "";
                ViewState["question"] = "";
                ViewState["A"] = "";
                ViewState["B"] = "";
                ViewState["C"] = "";
                ViewState["D"] = "";
                ViewState["correctoption"] = "";

             
               
                questions = new List<Question>();

                //examid = Convert.ToInt32(Request["examid"]);
                noofques = Convert.ToInt32(Request["noq"]);
                pendmarks = Convert.ToInt32(Request["marks"]);
                TextBox1.Text = pendmarks.ToString();
                quesCounter = 0;

                
                
            }
            
                examid = Convert.ToInt32(Application["examid"].ToString());
                pendmarks = Convert.ToInt32(Application["pendmarks"].ToString());
                noofques = Convert.ToInt32(Application["noq"].ToString());
                TextBox1.Text = pendmarks.ToString();
                quesCounter = Convert.ToInt32(ViewState["quesCounter"]);
               

                Label19.Text = "Question " + (quesCounter + 1);

                if (Request.QueryString["UpdateExam"] == "Y")
                {
                    Questions q = new Questions();
                    q.ExamID = examid;
                    dt = q.findByExamId();
                    if (dt.Rows.Count > 0)
                    {
                        dr = dt.Rows[quesCounter];

                        if (!IsPostBack)
                        {
                            TextBox3.Text = dr[2].ToString();
                            TextBox4.Text = dr[3].ToString();
                            TextBox5.Text = dr[4].ToString();
                            TextBox6.Text = dr[5].ToString();
                            TextBox7.Text = dr[6].ToString();
                            TextBox8.Text = dr[7].ToString();
                            TextBox2.Text = dr[8].ToString();

                           
                        }
                    }
                }
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            { 
            SqlConnection con = new SqlConnection(Properties.Settings.Default.constring);
            SqlCommand cmd;
            SqlDataAdapter da;


            if (quesCounter <= noofques)
            {
                Question newQuestion = new Question();
                newQuestion.question = TextBox3.Text;
                newQuestion.optionA = TextBox4.Text;
                newQuestion.optionB = TextBox5.Text;
                newQuestion.optionC = TextBox6.Text;
                newQuestion.optionD = TextBox7.Text;
                newQuestion.marks = Convert.ToInt32(TextBox2.Text);
                newQuestion.correctoption = TextBox8.Text;

                QUESTION q = new QUESTION();
                q.question = TextBox3.Text;
                q.A = TextBox4.Text;
                q.B = TextBox5.Text;
                q.C = TextBox6.Text;
                q.D = TextBox7.Text;
                q.marks = Convert.ToInt32(TextBox2.Text);
                q.CorrectOption = TextBox8.Text;
                q.examid = examid;

                if (Request.QueryString["UpdateExam"] == "Y")
                {
                    q.questionID = Convert.ToInt32(dr[0].ToString());
                    q.Question_Update();
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Question Updated Successfully');", true);
                }
                else
                {
                    q.Question_Insert();
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Question Added Successfully');", true);
                }
                //questions.Add(newQuestion);

                //con.Open();


                //string query = "INSERT INTO QUESTIONS " + "Values(" + examid + ",'" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "'," + Convert.ToInt32(TextBox2.Text) + ");";

                //cmd = new SqlCommand(query, con);
                //cmd.ExecuteNonQuery();


                //  MessageBox.Show("Question Added Successfully");


                pendmarks -= Convert.ToInt32(TextBox2.Text.ToString());
                Application["pendmarks"] = pendmarks;


                if ((Request.QueryString["UpdateExam"] == "Y") && ((quesCounter + 1) != noofques))
                {
                    dr = dt.Rows[quesCounter + 1];
                    TextBox3.Text = dr[2].ToString();
                    TextBox4.Text = dr[3].ToString();
                    TextBox5.Text = dr[4].ToString();
                    TextBox6.Text = dr[5].ToString();
                    TextBox7.Text = dr[6].ToString();
                    TextBox8.Text = dr[7].ToString();
                    TextBox2.Text = dr[8].ToString();
                    TextBox1.Text = pendmarks.ToString();

                    ViewState["marks"] = TextBox2.Text;
                    ViewState["question"] = TextBox3.Text;
                    ViewState["A"] = TextBox4.Text;
                    ViewState["B"] = TextBox5.Text;
                    ViewState["C"] = TextBox6.Text;
                    ViewState["D"] = TextBox7.Text;
                    ViewState["correctoption"] = TextBox8.Text;


                }
                else
                {
                    TextBox8.Text = "";
                    TextBox2.Text = "";
                    TextBox3.Text = "";
                    TextBox4.Text = "";
                    TextBox5.Text = "";
                    TextBox6.Text = "";
                    TextBox7.Text = "";
                    TextBox1.Text = pendmarks.ToString();

                }
                //con.Close();
            
            }

            quesCounter += 1;
            
            ViewState["quesCounter"] = quesCounter.ToString();
            Label19.Text = "Question " + (quesCounter + 1);
            if (quesCounter == noofques)
            {
               // this.Close();
                //ExamSetup.examid += 1;
                Response.Redirect("Admin Utils.aspx");
            }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Please Enter Valid Data in the Fields');</script>");
            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}