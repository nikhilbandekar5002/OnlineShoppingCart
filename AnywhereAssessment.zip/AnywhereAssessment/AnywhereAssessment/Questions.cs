﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AnywhereAssessment
{
    public class Question
    {
        public string question { get; set; }
        public string optionA { get; set; }
        public string optionB { get; set; }
        public string optionC { get; set; }
        public string optionD { get; set; }
        public int marks { get; set; }
        public string correctoption { get; set; }
    }
}