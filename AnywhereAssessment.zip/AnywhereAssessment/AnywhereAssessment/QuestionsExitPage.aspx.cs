﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;

namespace AnywhereAssessment
{
    public partial class QuestionsExitPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int eid = Convert.ToInt32(Request.QueryString["eid"]);
            Questions q = new Questions();
            q.ExamID = eid;
            DataTable dt = q.findByExamId();
            GridView1.DataSource = dt;
            GridView1.DataBind();

            Label3.Text = Request.QueryString["marks"];
            Label4.Text = Request.QueryString["grade"];
        }
    }
}