﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AnywhereAssessment.App_Code;
using BL;

namespace AnywhereAssessment
{
    public partial class RegisterContent : SmartSessionPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (RadioButton1.Checked == false && RadioButton2.Checked == false)
                    Label9.Text = "Required";
                else
                {
                    USER u = new USER();
                    u.fname = TextBox1.Text;
                    u.lname = TextBox2.Text;
                    u.age = Convert.ToInt32(TextBox3.Text);
                    u.email = TextBox4.Text;
                    u.userID = TextBox5.Text;
                    u.password = TextBox6.Text;

                    if (RadioButton1.Checked)
                        u.gender = "M";
                    else
                        u.gender = "F";

                    int x = u.insert();

                    if (x < 0)
                    {
                        TextBox5.Text = "";
                        Label10.Text = "Username: " + u.userID + " already taken";
                    }
                    else
                        Response.Redirect("LoginContent.aspx");
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}