﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using AnywhereAssessment.App_Code;
using BL;

namespace AnywhereAssessment
{
    public partial class TakeExam : SmartSessionPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (UserName == null)
                Response.Redirect("LoginContent.aspx");
            else
            {
                if (!IsPostBack)
                {
                    Subjects s = new Subjects();
                    DataTable dt = s.fetch();

                    DropDownList2.DataSource = dt;
                    DropDownList2.DataTextField = "SUB_NAME";
                    DropDownList2.DataValueField = "SUB_CODE";
                    DropDownList2.DataBind();
                }
            }
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Exams x = new Exams();
            x.scode = Convert.ToInt32(DropDownList2.SelectedValue);
            DataTable dt = x.getBySubject();

            DropDownList3.DataSource = dt;
            DropDownList3.DataTextField = "EXAM_ID";
            DropDownList3.DataValueField = "EXAM_ID";
            DropDownList3.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (DropDownList3.Items.Count <= 0)
                Label3.Text = "Please Select a valid exam";
            else
            {
                ExamHistory eh = new ExamHistory();
                eh.examID = Convert.ToInt32(DropDownList3.SelectedValue);
                eh.userID = UserName;
                DataTable dt = eh.searchByUserAndExamHistory();
                if (dt.Rows.Count > 0)
                    Label3.Text = "You have already completed this Exam";
                else
                    Response.Redirect("QuestionForm.aspx?EID=" + DropDownList3.SelectedItem.Text + "&Marks=" + DropDownList3.SelectedValue);
            }
        }
    }
}