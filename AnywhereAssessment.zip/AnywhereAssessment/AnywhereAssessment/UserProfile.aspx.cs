﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AnywhereAssessment.App_Code;
using BL;

namespace AnywhereAssessment
{
    public partial class UserProfile : SmartSessionPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (UserName == null)
                Response.Redirect("LoginContent.aspx");
            else
            {
                if (!IsPostBack)
                {

                    USER u = new USER();
                    DataTable dt = u.findById(UserName);
                    TextBox1.Text = (string)dt.Rows[0][0];
                    TextBox2.Text = (string)dt.Rows[0][1];
                    TextBox3.Text = dt.Rows[0][2].ToString();
                    TextBox4.Text = (string)dt.Rows[0][4];
                    TextBox5.Text = (string)dt.Rows[0][5];
                    TextBox6.Text = (string)dt.Rows[0][6];

                    if ("M" == dt.Rows[0][3].ToString())
                        RadioButton1.Checked = true;

                    else
                        RadioButton2.Checked = true;

                    RadioButton1.Enabled = false;
                    RadioButton2.Enabled = false;
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Button1.Text == "Edit")
                enableEverything();

            else if (Button1.Text == "Cancel")
                disableEverything();
        }

        private void enableEverything()
        {
            TextBox1.CssClass = TextBox1.CssClass.Replace("text-box", "");
            TextBox2.CssClass = TextBox2.CssClass.Replace("text-box", "");
            TextBox3.CssClass = TextBox3.CssClass.Replace("text-box", "");
            TextBox4.CssClass = TextBox4.CssClass.Replace("text-box", "");
            //TextBox5.CssClass = TextBox5.CssClass.Replace("text-box", "");
            TextBox6.CssClass = TextBox6.CssClass.Replace("text-box", "");
            TextBox1.ReadOnly = false;
            TextBox2.ReadOnly = false;
            TextBox3.ReadOnly = false;
            TextBox4.ReadOnly = false;
            //TextBox5.ReadOnly = false;
            TextBox6.ReadOnly = false;
            RadioButton1.Enabled = true;
            RadioButton2.Enabled = true;
            Button1.Text = "Cancel";
            Button2.Visible = true;
        }

        private void disableEverything()
        {
            TextBox1.CssClass = "text-box";
            TextBox2.CssClass = "text-box";
            TextBox3.CssClass = "text-box";
            TextBox4.CssClass = "text-box";
            //TextBox5.CssClass = "text-box";
            TextBox6.CssClass = "text-box";
            TextBox1.ReadOnly = true;
            TextBox2.ReadOnly = true;
            TextBox3.ReadOnly = true;
            TextBox4.ReadOnly = true;
            //TextBox5.ReadOnly = true;
            TextBox6.ReadOnly = true;
            RadioButton1.Enabled = false;
            RadioButton2.Enabled = false;
            Button1.Text = "Edit";
            Button2.Visible = false;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            USER u = new USER();
            u.fname = TextBox1.Text;
            u.lname = TextBox2.Text;
            u.age = Convert.ToInt32(TextBox3.Text);
            u.email = TextBox4.Text;
            u.userID = TextBox5.Text;
            u.password = TextBox6.Text;
            u.userIDOld = (string)UserName;
            if (RadioButton1.Checked == true)
                u.gender = "M";
            else if (RadioButton2.Checked == true)
                u.gender = "F";

            u.update();
            disableEverything();
        }
    }
}