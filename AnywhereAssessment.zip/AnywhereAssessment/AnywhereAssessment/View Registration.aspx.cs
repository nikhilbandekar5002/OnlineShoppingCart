﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BL;

namespace AnywhereAssessment
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        string constr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                //this.BindData();

                LoadData l = new LoadData();
                GridView3.DataSource = l.LoadRegisterDtls();
                GridView3.DataBind();
            }
        }

        private void BindData()
        {
            
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("select * from USER_DETAILS"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                         //   GridView2.DataSource = dt;
                          //  GridView2.DataBind();
                        }
                    }
                }
            }
        }

       

        protected void GridView3_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if(e.CommandName == "delete")
            {
                USER u = new USER();
                u.REGNO = Convert.ToInt32(e.CommandArgument);
                u.DELETEUSER();

                LoadData l = new LoadData();
                GridView3.DataSource = l.LoadRegisterDtls();
                GridView3.DataBind();
            }

            if (e.CommandName == "Edit")
            {
                USER u = new USER();
                u.REGNO = Convert.ToInt32(e.CommandArgument);
                //u.DELETEUSER();

                LoadData l = new LoadData();
                DataSet ds = (DataSet) l.LoadUserByRegNo(u.REGNO.ToString());
                string user = ds.Tables[0].Rows[0][0].ToString();
                Response.Redirect("UpdateUserDtls.aspx?uid=" + user);
            }
           
        }

       

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            USER u = new USER();
            u.REGNO = Convert.ToInt32(e.ToString());
            u.DELETEUSER();

            LoadData l = new LoadData();
            GridView3.DataSource = l.LoadRegisterDtls();
            GridView3.DataBind();
        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            USER u = new USER();
            u.REGNO = Convert.ToInt32(e.ToString());
            u.DELETEUSER();

            LoadData l = new LoadData();
            GridView3.DataSource = l.LoadRegisterDtls();
            GridView3.DataBind();
        }

        protected void Button2_Click2(object sender, EventArgs e)
        {

        }

        protected void GridView3_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView3.EditIndex = e.NewEditIndex;

            //GridView3.DataSource = l.LoadRegisterDtls();
            //GridView3.DataBind();
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {

        }

        protected void GridView3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       

       
        //protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //}

        //protected void GridView2_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        //{

        //}

        //protected void GridView2_SelectedIndexChanged1(object sender, EventArgs e)
        //{

        //}

        //protected void GridView2_RowEditing(object sender, GridViewEditEventArgs e)
        //{
        //    //SqlConnection con = new SqlConnection(constr);
        //}

        //protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
        //{
        //    //SqlConnection con = new SqlConnection(constr);
        //    //GridViewRow row = (GridViewRow)GridView2.Rows[e.RowIndex];
        //    //Label lbldeleteid = (Label)row.FindControl("lblID");
        //    //con.Open();
        //    //string f = GridView2.Rows[e.RowIndex].Cells[1].Text;
        //    ////GridView2.
        //    //SqlCommand cmd = new SqlCommand("delete FROM USER_DETAILS where REGNO= " + Convert.ToInt32(GridView2.Rows[e.RowIndex].Cells[0].ToString()) + "", con);
        //    //cmd.ExecuteNonQuery();
        //    //con.Close();
        //    //BindData();

        //}

      
        
    }
}