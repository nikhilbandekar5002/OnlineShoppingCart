﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using AnywhereAssessment.App_Code;
using BL;

namespace AnywhereAssessment
{
    public partial class ViewExamHistory : SmartSessionPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (UserName == null)
                Response.Redirect("LoginContent.aspx");
            else
            {
                if (!this.IsPostBack)
                    this.BindData();
            }
        }

        private void BindData()
        {
            ExamHistory eh = new ExamHistory();
            eh.userID = UserName;
            DataTable dt = eh.fetch();
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
        }

        protected void GridView1_PageIndexChanging1(object sender, GridViewPageEventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       
    }
}
