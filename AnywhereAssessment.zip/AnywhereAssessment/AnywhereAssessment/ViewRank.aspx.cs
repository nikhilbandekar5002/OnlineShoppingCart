﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using AnywhereAssessment.App_Code;
using BL;

namespace AnywhereAssessment
{
    public partial class ViewRank : SmartSessionPage
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (UserName == null)
                Response.Redirect("LoginContent.aspx");
            else
            {
                if (!IsPostBack)
                {
                    Subjects s = new Subjects();
                    DataTable dt = s.fetch();

                    DropDownList2.DataSource = dt;
                    DropDownList2.DataTextField = "SUB_NAME";
                    DropDownList2.DataValueField = "SUB_CODE";
                    DropDownList2.DataBind();
                }
            }
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Exams x = new Exams();
            x.scode = Convert.ToInt32(DropDownList2.SelectedValue);
            DataTable dt = x.getBySubject(UserName);

            DropDownList3.DataSource = dt;
            DropDownList3.DataTextField = "EXAM_ID";
            DropDownList3.DataValueField = "EXAM_ID";
            DropDownList3.DataBind();
            if (DropDownList3.Items.Count > 0)
                populateRankTable();
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {
            populateRankTable();
        }

        public void populateRankTable()
        {
            ExamHistory x = new ExamHistory();
            x.examID = Convert.ToInt32(DropDownList3.SelectedValue);
            DataTable dt = x.getByRank();

            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
}