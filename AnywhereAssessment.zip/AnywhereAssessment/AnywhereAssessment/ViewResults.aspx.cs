﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace AnywhereAssessment
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(Properties.Settings.Default.constring);

        Dictionary<string, string> sub = new Dictionary<string, string>();
        List<string> exams = new List<string>();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string query = "SELECT * FROM SUBJECT_DETAILS";
                con.Open();

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                foreach (DataRow d in dt.Rows)
                {
                    //ComboBoxItem ci = new ComboBoxItem() { Value = Convert.ToInt32(d[0]), Text = d[1].ToString() };
                    sub.Add(d[0].ToString(), d[1].ToString());
                    //comboBox1.Items.Add(ci);
                }

                DropDownList1.DataSource = sub;
                DropDownList1.DataTextField = "Value";
                DropDownList1.DataValueField = "Key";
                DropDownList1.DataBind();

                con.Close();
            }

           // comboBox1.SelectedIndex = 0;
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList2.Items.Clear();
            //comboBox2.Items.Clear();
            con.Open();

            string query = "Select EXAM_ID from EXAM_DETAILS where SUB_CODE = " + (DropDownList1.SelectedItem).Value;

            SqlDataAdapter da2 = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            da2.Fill(dt);

            foreach (DataRow d in dt.Rows)
            {
                //ComboBoxItem ci = new ComboBoxItem() { Value = Convert.ToInt32(d[0]), Text = d[0].ToString() };
                exams.Add((d[0].ToString()));
                //comboBox2.Items.Add(ci);
            }

            DropDownList2.DataSource = exams;
            //DropDownList2.DataTextField = "Value";
            //DropDownList2.DataValueField = "Key";
            DropDownList2.DataBind();
            con.Close();

            if (exams.Count <= 0)
            {

            }
            else
            {
                DropDownList2.SelectedIndex = 0;
            }
                //comboBox2.SelectedIndex = 0;

            con.Close();
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string query = "select ld.USER_ID,eh.SCORE  from EXAM_HISTORY AS eh " +
                           "INNER JOIN LOGIN_DETAILS ld on eh.USER_ID = ld.USER_ID " +
                           "where eh.EXAM_ID = " + DropDownList2.Text +
                           "order by eh.SCORE desc;";

            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(query, con);

            DataTable dt = new DataTable();
            da.Fill(dt);


            GridView1.DataSource = dt;
            GridView1.DataBind();

            con.Close();
        }

        protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}