﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace AnywhereAssessment
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO USER_DETAILS VALUES('" + TextBox1.Text + "','" + TextBox2.Text + "'," + TextBox3.Text + ",'" + TextBox4.Text + "','" + TextBox5.Text  + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE USER_DETAILS SET FNAME =  '" + TextBox1.Text + "',LNAME = '" + TextBox2.Text + "', AGE = " + TextBox3.Text + ", GENDER = '" + TextBox4.Text + "',EMAILID = '" + TextBox5.Text + "' where REGNO = " + TextBox6.Text + "", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}