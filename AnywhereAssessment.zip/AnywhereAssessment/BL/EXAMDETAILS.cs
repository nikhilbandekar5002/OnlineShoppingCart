﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DL;

namespace BL
{
    public class EXAMDETAILS
    {
        public int subjectcode {get; set;}
        public int duration { get; set; }
        public int marks { get; set; }
        public int noofquestions { get; set; }
        public int examid { get; set; }

        public void ExamDtls_Insert()
        {
            DataClasses1DataContext d = new DataClasses1DataContext();
            d.ADDEXAM(subjectcode, duration, marks, noofquestions);


        }

        public object ExamDtls_Fecth(int exid)
        {
            ExamsDAL ex = new ExamsDAL();
            return ex.getByID(exid);
        }

    }
}
