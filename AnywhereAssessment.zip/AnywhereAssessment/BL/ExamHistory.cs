﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Linq;
using System.Data;
using DL;


namespace BL
{
    public class ExamHistory
    {
        public string userID { get; set; }
        public int examID { get; set; }
        public DateTime examDate { get; set; }
        public string result { get; set; }
        public int score { get; set; }

        public void insert()
        {
            DataClasses1DataContext d = new DataClasses1DataContext();
            d.ADDEXAMHISTORY(userID, examID, result, score);
        }

        public DataTable fetch()
        {
            ExamHistoryDAL d = new ExamHistoryDAL();
            return d.getData(userID);
        }

        public DataTable searchByUserAndExamHistory()
        {
            ExamHistoryDAL d = new ExamHistoryDAL();
            return d.searchByUserAndExamHistory(examID,userID);
        }

        public DataTable getByRank()
        {
            ExamHistoryDAL d = new ExamHistoryDAL();
            return d.getData(examID);
        }
    }
}
