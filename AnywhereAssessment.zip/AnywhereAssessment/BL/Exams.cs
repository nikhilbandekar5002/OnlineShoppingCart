﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DL;

namespace BL
{
    public class Exams
    {
        public string sname { get; set; }
        public int scode { get; set; }
        public int examID { get; set; }

        public DataTable getBySubject()
        {
            ExamsDAL s = new ExamsDAL();
            return s.getBySubject(scode);
        }

        public DataTable getBySubject(string u)
        {
            ExamsDAL s = new ExamsDAL();
            return s.getBySubject(scode,u);
        }

        public DataTable getByID()
        {
            ExamsDAL s = new ExamsDAL();
            return s.getByID(examID);
        }
    }
}
