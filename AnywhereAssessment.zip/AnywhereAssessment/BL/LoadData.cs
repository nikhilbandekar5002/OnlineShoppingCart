﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DL;

namespace BL
{
    public class LoadData
    {
        public object LoadRegisterDtls()
        {
            Populate p = new Populate();
            return p.LoadRegistration();
        }

        public object LoadUserByRegNo(string x)
        {
            UserDAL u = new UserDAL();
            return u.findByRegNo(x);
        }

     }
}
