﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DL;
using System.Data;
using System.Data.Linq;

namespace BL
{
    public class LoginDetails
    {
        public string userID { get; set; }
        public string password { get; set; }
                
        public string LoginSP()
        {
            DataClasses1DataContext d = new DataClasses1DataContext();
            ISingleResult<LOGINResult> log = d.LOGIN(userID, password);

            try
            {
                var query = (from l in log
                             select
                             new { l.USER_ID }).Single();
                
                string userName = (string)query.USER_ID;
                return userName;
            }
            catch (InvalidOperationException ex)
            {
                string userName = null;
                return userName;
            }
            
        }
    }
}
