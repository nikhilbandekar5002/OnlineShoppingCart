﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DL;

namespace BL
{
    public class QUESTION
    {
        public int examid { get; set; }
        public string question { get; set; }
        public string A { get; set; }
        public string B { get; set; }
        public string C { get; set; }
        public string D { get; set; }
        public string CorrectOption { get; set; }
        public int marks { get; set; }
        public int questionID { get; set; }

        public void Question_Insert()
        {
            DataClasses1DataContext d = new DataClasses1DataContext();
            d.ADDQUESTIONS(examid, question, A, B, C, D, CorrectOption, marks,"INSERT",null);

        }

        public void Question_Update()
        {
            DataClasses1DataContext d = new DataClasses1DataContext();
            d.ADDQUESTIONS(examid, question, A, B, C, D, CorrectOption, marks,"UPDATE",questionID);

        }
    }
}
