﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DL;

namespace BL
{
    public class Questions
    {
        public int ExamID { get; set; }
        
        public DataTable findByExamId()
        {
            QuestionsDAL q = new QuestionsDAL();
            return q.findByExamId(ExamID);
        }
    }
}
