﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DL;

namespace BL
{
    public class Subject
    {
        public string subject { get; set; }

        public void AddSubject()
        {
            DataClasses1DataContext d = new DataClasses1DataContext();
            
                d.ADDSUBJECT(subject);
            
        }

        
        
    }
}
