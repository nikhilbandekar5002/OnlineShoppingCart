﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DL;

namespace BL
{
    public class Subjects
    {
        public string sname { get; set; }
        public string scode { get; set; }
        
        public DataTable fetch()
        {
            SubjectsDAL s = new SubjectsDAL();
            return s.getAll();
        }
    }
}
