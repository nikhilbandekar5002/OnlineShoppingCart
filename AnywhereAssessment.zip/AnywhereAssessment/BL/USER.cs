﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DL;

namespace BL
{
    public class USER
    {
        public int REGNO { get; set; }

        public string fname { get; set; }
        public string lname { get; set; }
        public int age { get; set; }
        public string gender { get; set; }
        public string email { get; set; }
        public string userID { get; set; }
        public string userIDOld { get; set; }
        public string password { get; set; }

        public int insert()
        {
            try
            {
                DataClasses1DataContext u = new DataClasses1DataContext();
                return u.ADDUSER(fname, lname, age, gender, email, userID, password);
            }
            catch(SqlException ex)
            {
                return -1;
            }
        }

        public DataTable findById()
        {
            UserDAL u = new UserDAL();
            return u.findByID(userID);
        }

        public DataTable findById(string s)
        {
            UserDAL u = new UserDAL();
            return u.findByID(s);
        }

        public void update()
        {
            DataClasses1DataContext u = new DataClasses1DataContext();
            u.spUSER(fname, lname, age, gender, email, userID, userIDOld, password, "SAVEDATA");
        }

        public void DELETEUSER()
        {
            GridviewOperations g = new GridviewOperations();

            g.deletedata(REGNO);
            

        }




    }
}
