using System.Data.Linq;
using System.Reflection;
namespace DL
{
    partial class DataClasses1DataContext
    {

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.ADDEXAM")]
        public int ADDEXAM([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "SUBJECTCODE", DbType = "Int")] System.Nullable<int> sUBJECTCODE, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "DURATION", DbType = "Int")] System.Nullable<int> dURATION, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "MARKS", DbType = "Int")] System.Nullable<int> mARKS, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "NOOFQUES", DbType = "Int")] System.Nullable<int> nOOFQUES)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), sUBJECTCODE, dURATION, mARKS, nOOFQUES);
            return ((int)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.ADDEXAMHISTORY")]
        public int ADDEXAMHISTORY([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "USERID", DbType = "VarChar(5)")] string uSERID, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "EXAMID", DbType = "Int")] System.Nullable<int> eXAMID, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "RESULT", DbType = "VarChar(5)")] string rESULT, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "SCORE", DbType = "Int")] System.Nullable<int> sCORE)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), uSERID, eXAMID, rESULT, sCORE);
            return ((int)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.ADDSUBJECT")]
        public int ADDSUBJECT([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "SUBJECT", DbType = "VarChar(50)")] string sUBJECT)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), sUBJECT);
            return ((int)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.ADDUSER")]
        public int ADDUSER([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "FNAME", DbType = "VarChar(50)")] string fNAME, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "LNAME", DbType = "VarChar(50)")] string lNAME, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "AGE", DbType = "Int")] System.Nullable<int> aGE, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "GENDER", DbType = "VarChar(5)")] string gENDER, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "EMAILID", DbType = "VarChar(50)")] string eMAILID, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "USERID", DbType = "VarChar(50)")] string uSERID, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "PASSWORD", DbType = "VarChar(50)")] string pASSWORD)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), fNAME, lNAME, aGE, gENDER, eMAILID, uSERID, pASSWORD);
            return ((int)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.DELETEUSER")]
        public int DELETEUSER([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "REGNO", DbType = "Int")] System.Nullable<int> rEGNO)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), rEGNO);
            return ((int)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.GETANSWEREDEXAMS")]
        public ISingleResult<GETANSWEREDEXAMSResult> GETANSWEREDEXAMS([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "USERID", DbType = "VarChar(50)")] string uSERID, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "SUBCOE", DbType = "Int")] System.Nullable<int> sUBCOE)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), uSERID, sUBCOE);
            return ((ISingleResult<GETANSWEREDEXAMSResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.GETEXAMHISTORY")]
        public ISingleResult<GETEXAMHISTORYResult> GETEXAMHISTORY([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "USERID", DbType = "VarChar(50)")] string uSERID)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), uSERID);
            return ((ISingleResult<GETEXAMHISTORYResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.GETEXAMHISTORYBYRANK")]
        public ISingleResult<GETEXAMHISTORYBYRANKResult> GETEXAMHISTORYBYRANK([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "EXAMID", DbType = "Int")] System.Nullable<int> eXAMID)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), eXAMID);
            return ((ISingleResult<GETEXAMHISTORYBYRANKResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.LOGIN")]
        public ISingleResult<LOGINResult> LOGIN([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "USERID", DbType = "VarChar(50)")] string uSERID, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "PASSWORD", DbType = "VarChar(50)")] string pASSWORD)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), uSERID, pASSWORD);
            return ((ISingleResult<LOGINResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.SEARCHBYUSERANDEXAM")]
        public ISingleResult<SEARCHBYUSERANDEXAMResult> SEARCHBYUSERANDEXAM([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "USERID", DbType = "VarChar(50)")] string uSERID, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "EXAMID", DbType = "Int")] System.Nullable<int> eXAMID)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), uSERID, eXAMID);
            return ((ISingleResult<SEARCHBYUSERANDEXAMResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.spFETCHUSER")]
        public ISingleResult<spFETCHUSERResult> spFETCHUSER([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "USER", DbType = "VarChar(50)")] string uSER)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), uSER);
            return ((ISingleResult<spFETCHUSERResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.spUSER")]
        public ISingleResult<spUSERResult> spUSER([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "FNAME", DbType = "VarChar(50)")] string fNAME, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "LNAME", DbType = "VarChar(50)")] string lNAME, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "AGE", DbType = "Int")] System.Nullable<int> aGE, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "GENDER", DbType = "VarChar(5)")] string gENDER, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "EMAILID", DbType = "VarChar(50)")] string eMAILID, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "USERID", DbType = "VarChar(50)")] string uSERID, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "USERIDOLD", DbType = "VarChar(50)")] string uSERIDOLD, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "PASSWORD", DbType = "VarChar(50)")] string pASSWORD, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "ACTION", DbType = "VarChar(20)")] string aCTION)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), fNAME, lNAME, aGE, gENDER, eMAILID, uSERID, uSERIDOLD, pASSWORD, aCTION);
            return ((ISingleResult<spUSERResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.ADDQUESTIONS")]
        public int ADDQUESTIONS([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "EXAMID", DbType = "Int")] System.Nullable<int> eXAMID, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "QUESTION", DbType = "VarChar(50)")] string qUESTION, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "A", DbType = "VarChar(50)")] string a, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "B", DbType = "VarChar(50)")] string b, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "C", DbType = "VarChar(50)")] string c, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "D", DbType = "VarChar(50)")] string d, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "CORRECTOPTION", DbType = "VarChar(50)")] string cORRECTOPTION, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "MARKS", DbType = "Int")] System.Nullable<int> mARKS, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "OPERATION", DbType = "VarChar(50)")] string oPERATION, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "QUESTIONID", DbType = "Int")] System.Nullable<int> qUESTIONID)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), eXAMID, qUESTION, a, b, c, d, cORRECTOPTION, mARKS, oPERATION, qUESTIONID);
            return ((int)(result.ReturnValue));
        }
    }
}
