﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace DL
{
    public class ExamHistoryDAL
    {
        public DataTable getData(string userID)
        {
            try
            {
                string connstr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(connstr);
                string query = "GETEXAMHISTORY";
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@USERID", userID);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch(Exception ex)
            {
                Console.Write(ex.Message);
                return null;
            }
        }

        public DataTable getData(int examID)
        {
            try
            {
                string connstr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(connstr);
                string query = "GETEXAMHISTORYBYRANK";
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EXAMID", examID);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                return null;
            }
        }

        public DataTable searchByUserAndExamHistory(int x, string y)
        {
            string connstr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connstr);
            string query = "SEARCHBYUSERANDEXAM";
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@USERID", y);
            cmd.Parameters.AddWithValue("@EXAMID", x);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        } 
    }
}
