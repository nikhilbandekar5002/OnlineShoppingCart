﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DL
{
    public class ExamsDAL
    {
        public DataTable getBySubject(int s)
        {
            try
            {
                string connstr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(connstr);
                string query = "SELECT * FROM EXAM_DETAILS WHERE SUB_CODE = "+s;
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                return null;
            }
        }

        public DataTable getBySubject(int s, string u)
        {
            try
            {
                string connstr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(connstr);
                string query = "GETANSWEREDEXAMS";
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@USERID", u);
                cmd.Parameters.AddWithValue("@SUBCOE", s);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                return null;
            }
        }

        public DataTable getByID(int ex)
        {
            string connstr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connstr);
            string query = "select * from exam_details where exam_id =" + ex;
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }
}
