﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Threading.Tasks;

namespace DL
{
    public class GridviewOperations
    {
        public string constr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
        public int deletedata(int REGNO)
        {
            int res = 0;
            try
            {
                SqlConnection con = new SqlConnection(constr);
                con.Open();
                SqlCommand cmd = new SqlCommand("DELETEUSER", con);
                cmd.Parameters.Add("@REGNO", REGNO);
                cmd.CommandType = CommandType.StoredProcedure;
                res = cmd.ExecuteNonQuery();

                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return res;


        }


    }
}
