﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace DL
{
    public class Populate
    {
        public string constr;

        public object LoadRegistration()
        {
            constr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
            string query = "SELECT * from USER_DETAILS";
            DataSet ds = (DataSet)ExecuteSqlString(query);
            return ds;
        }

        public object ExecuteSqlString(string sqlstring)
        {
            SqlConnection obj = new SqlConnection(constr);
            obj.Open();
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand(sqlstring, obj);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            return ds;
        }

    }
}
