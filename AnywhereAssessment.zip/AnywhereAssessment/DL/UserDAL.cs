﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DL
{
    public class UserDAL
    {
        public DataTable findByID(string x)
        {
            try
            {
                string connstr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(connstr);
                string query = "spUser";
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@USERIDOLD", x);
                cmd.Parameters.AddWithValue("@ACTION", "FETCHDATA");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                return null;
            }
        }


        public DataSet findByRegNo(string x)
        {
            try
            {
                string constr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
                string query = "SELECT USER_ID from LOGIN_DETAILS WHERE REGNO = " + x;
                DataSet ds = (DataSet)ExecuteSqlString(query);
                return ds;
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                return null;
            }
        }


        public object ExecuteSqlString(string sqlstring)
        {
            string constr = ConfigurationManager.ConnectionStrings["ANYWHERE_ASSESSMENT_SYSTEMConnectionString"].ConnectionString;
            SqlConnection obj = new SqlConnection(constr);
            obj.Open();
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand(sqlstring, obj);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            return ds;
        }
    
    }
}
