﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ2SQLDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeDataContext context = new EmployeeDataContext();

            //List<Emp> result = (from emp in context.Emps
            //                    where emp.DeptId == 2
            //                    orderby emp.Salary descending
            //                    select emp).ToList();

            ////Deferred Loading
            //foreach (Emp e in result)
            //{
            //    Console.WriteLine(e.EmpName);
            //    Console.WriteLine(e.Salary);
            //    Console.WriteLine(e.Dept.DName); //Lazy loading
            //    Console.WriteLine();
            //}

            //var result2 = from emp in context.Emps
            //              where emp.DeptId == 2
            //              orderby emp.Salary descending
            //              select new { emp.EmpName, Dept = emp.Dept.DName };

            var result2 = context.Emps.Where(emp => emp.DeptId == 2)
                                      .OrderByDescending(emp => emp.Salary)
                                      .Select(emp => new { emp.EmpName, Dept = emp.Dept.DName });
          
            foreach (var item in result2)
            {
                Console.WriteLine(item);
            }

            Emp newEmp = new Emp
            {
                EmpId = 102,
                EmpName = "James",
                Salary = 9400,
                DeptId = 3
            };
            context.Emps.InsertOnSubmit(newEmp);

            Emp empToUpdate = (from emp in context.Emps
                              where emp.EmpId == 2
                              select emp).SingleOrDefault();
            empToUpdate.Salary += 1000;

            Emp empToDelete = context.Emps.SingleOrDefault(emp => emp.EmpId == 101);
            context.Emps.DeleteOnSubmit(empToDelete);

            try
            {
                context.SubmitChanges();
            }
            catch (Exception)
            {
                
                throw;
            }

            context.Dispose();
            Console.ReadKey();
        }
    }
}
