﻿// <summary>
/// Page Name 		: ServiceSearchT.aspx.cs
/// Created By 		: 
/// Created On		: 
/// Description		: UI for Service Search for training
/// </summary>
/* Modification History :
*        Who			     Date		    Description
* --------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
 01                
*/


using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using ServiceProxyManager.Factory.B2CXMLAPIWebService;
using ServiceProxyManager.ProxyClasses.B2CXMLAPIWebService;
using ServiceProxyManager.ProxyClasses.Services;
using TSBrowser.Base;

public partial class Pages_Services_ServiceSearch : ODLControls.ODLPage
{
    private string _sSupplierID = "0";
    private string _sServiceLongName = string.Empty;
    private string _sRedirectPageName = string.Empty;
    private string sStringData = "Results found-Showing";
    DataTable dt;


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            _sRedirectPageName = "ServiceMain";
        }
        LoadJavaScriptMessages();
    }

    protected void grdServiceSearch_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onmouseout", "RemoveHover(this)");

            LinkButton lnkBtnViewService = (LinkButton)e.Row.FindControl("lnkBtnViewService");

            if (lnkBtnViewService != null)
            {
                lnkBtnViewService.Text = Base.GetMultilingualText("lnkBtnViewService", Path.GetFileNameWithoutExtension(this.AppRelativeVirtualPath).ToString());
            }

            ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "AjustGridHeight", "AjustGridHeight('false');", true);//Harshad(32)
        }

    }

    protected void grdServiceSearch_PageIndexChanging(Object sender, GridViewPageEventArgs e)
    {
        #region PageIndexChanging
        //try
        //{
        //    if (grdServiceSearch.SelectedIndex > -1)
        //    {
        //        grdServiceSearch.SelectedIndex = -1;
        //    }
        //    if (e.NewPageIndex > 0)
        //        grdServiceSearch.PageIndex = e.NewPageIndex;
        //    else
        //        grdServiceSearch.PageIndex = 0;

        //    int PageDataCount = 0;
        //    int pageData = (grdServiceSearch.PageIndex + 1) * grdServiceSearch.PageSize;
        //    if (pageData >= grdServiceSearch.Data.Rows.Count)
        //    {
        //        PageDataCount = grdServiceSearch.Data.Rows.Count;
        //    }
        //    else
        //    {
        //        PageDataCount = pageData;
        //    }
        //    int Data = (grdServiceSearch.PageSize * grdServiceSearch.PageIndex) + 1;

        //    if (e.NewPageIndex > 0)
        //    {
        //        lblHeaderResult.Text = string.Format("{0} {1} {2}-{3}", grdServiceSearch.Data.Rows.Count, sStringData, Data, PageDataCount);
        //        lblFooterResults.Text = lblHeaderResult.Text;
        //    }
        //    else
        //    {
        //        lblHeaderResult.Text = string.Format("{0} {1} {2}-{3}", grdServiceSearch.Data.Rows.Count, sStringData, 1, PageDataCount);
        //        lblFooterResults.Text = lblHeaderResult.Text;
        //    }
        //    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "AjustGridHeight", "AjustGridHeight('false');", true);//Harshad(32)
        //    grdServiceSearch.ReBind();

        //    updPnlSearchService.Update();


        //}
        //catch (Exception ex)
        //{
        //    this.ShowExceptionMessage(ex);
        //} 
        #endregion
    }

    protected void grdServiceSearch_DataBound(Object sender, EventArgs e)
    {

        #region data_bound
        //GridViewRow pagerRow = grdServiceSearch.BottomPagerRow;

        //if (pagerRow != null)
        //{
        //    Label result = (Label)pagerRow.Cells[0].FindControl("lblResultsCount");
        //    result.Text = result.Text + ViewState["TotalRowCount"].ToString();
        //} 
        #endregion
    }

    protected void grdServiceSearch_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        #region Row command
        //try
        //{
        //    AuditManager.AuditManager.Log("Pages.Services.ServiceVilla.aspx.cs : grdAssignedRoom_RowCommand", "Error", AuditManager.AuditManager.AuditType.Debug, AuditManager.AuditManager.ApplicationLayer.Website);

        //    if (e.CommandName == "ServiceName")
        //    {
        //        int serviceID = Convert.ToInt32(e.CommandArgument);
        //        LinkButton IB = (LinkButton)e.CommandSource;
        //        GridViewRow row = (GridViewRow)IB.NamingContainer;
        //        int index = row.RowIndex;
        //        string strType = ODLServiceTypeSearch1.ServiceTypeID.ToString().Trim();
        //        if (strType == "")
        //            strType = grdServiceSearch.Data.Rows[index]["ServiceTypeID"].ToString().Trim();

        //        string[] strArrSeprator = new string[] { "||" };
        //        string multi = Base.GetMultilingualText("Service", "Menu");
        //        string[] strArrResourceText = multi.Split(strArrSeprator, StringSplitOptions.None);
        //        string pagename = strArrResourceText[0] + ": " + IB.Text;

        //        string href = "Pages/Training/" + "ServiceMain" + ".aspx?ServiceId=" + serviceID.ToString() + "&RegionId=" + "0" + "&ServiceTypeId=" + "0";

        //        CommonFunctions.AddFrame(this.Page, this.GetType(), pagename, href);
        //    }

        //    if (e.CommandName == "EditService")
        //    {

        //        int intDataItemIndex = 0;
        //        if (e.CommandSource.GetType().Name.Equals("ImageButton"))
        //        {
        //            intDataItemIndex = Convert.ToInt32(((ImageButton)e.CommandSource).CommandArgument);
        //        }
        //        else if (e.CommandSource.GetType().Name.Equals("LinkButton"))
        //        {
        //            intDataItemIndex = Convert.ToInt32(((LinkButton)e.CommandSource).CommandArgument);
        //        }
        //        int ServiceID = Convert.ToInt32(grdServiceSearch.Data.Rows[intDataItemIndex]["ServiceID"]);



        //        string strType = ODLServiceTypeSearch1.ServiceTypeID.ToString().Trim();
        //        if (strType == "")
        //            strType = grdServiceSearch.Data.Rows[intDataItemIndex]["ServiceTypeID"].ToString().Trim();
        //        string[] strArrSeprator = new string[] { "||" };
        //        string multi = Base.GetMultilingualText("Service", "Menu");
        //        string[] strArrResourceText = multi.Split(strArrSeprator, StringSplitOptions.None);
        //        string pagename = strArrResourceText[0] + ": " + grdServiceSearch.Data.Rows[intDataItemIndex]["ServiceLongName"].ToString().Trim();

        //    }


        //    grdServiceSearch.DeletedRows.Clear();

        //    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "AjustGridHeight", "AjustGridHeight('false');", true);//Harshad(32)

        //    AuditManager.AuditManager.Log("Pages.Services.ServiceSearch.aspx.cs : grdServiceSearch_RowCommand", "Error", AuditManager.AuditManager.AuditType.Debug, AuditManager.AuditManager.ApplicationLayer.Website);
        //}
        //catch (Exception ex)
        //{
        //    string popupScript = "alert('" + ex.Message + "')";
        //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "clientScript", popupScript, true);
        //    AuditManager.AuditManager.Log("Pages.Services.ServiceSearch.aspx.cs : grdServiceSearch_RowCommand", "Error", AuditManager.AuditManager.AuditType.Debug, AuditManager.AuditManager.ApplicationLayer.Website);
        //} 
        #endregion
    }

    protected void btnSearchService_Click(object sender, EventArgs e)
    {

        SearchService();

    }

    /// <summary>
    /// Searches Services
    /// </summary>
    private void SearchService()
    {
        

    }

    /// <summary>
    /// Method to Load Java Script Messages
    /// </summary>
    protected void LoadJavaScriptMessages()
    {
        Hashtable objHashtable = null;

        objHashtable = new Hashtable();
        objHashtable.Add("1001", "Please select a Service Type and Rating Type.");

        ViewState["JSMessages"] = Base.CreateHiddenMessageList(this, objHashtable, Convert.ToString(ViewState["JSMessages"]));
    }



    protected void ddlFooterPageResults_SelectedIndexChanged(object sender, EventArgs e)
    {
        #region footer selected index changed
        //if (grdServiceSearch.Rows.Count > 0)
        //{

        //    if (ddlFooterPageResults.SelectedValue == "All")
        //    {
        //        grdServiceSearch.PageSize = grdServiceSearch.Data.Rows.Count;
        //        lblHeaderResult.Text = string.Format("{0} {1} {2}-{3}", grdServiceSearch.Data.Rows.Count, sStringData, 1, grdServiceSearch.Data.Rows.Count);
        //        lblFooterResults.Text = lblHeaderResult.Text;

        //    }
        //    else
        //    {
        //        grdServiceSearch.PageSize = Convert.ToInt32(ddlFooterPageResults.SelectedValue);
        //        SearchResults();
        //    }

        //    grdServiceSearch.DataSource = grdServiceSearch.Data;
        //    grdServiceSearch.DataBind();
        //    ddlHeaderResultsPage.SelectedValue = ddlFooterPageResults.SelectedValue;
        //    updPnlSearchService.Update();
        //}
        //else
        //{
        //    ddlHeaderResultsPage.SelectedValue = ddlFooterPageResults.SelectedValue;
        //} 
        #endregion
    }

    protected void ddlHeaderResultsPage_SelectedIndexChanged(object sender, EventArgs e)
    {
        #region header selected index changed
        //if (grdServiceSearch.Rows.Count > 0)
        //{

        //    if (ddlHeaderResultsPage.SelectedValue == "All")
        //    {
        //        grdServiceSearch.PageSize = grdServiceSearch.Data.Rows.Count;
        //        lblHeaderResult.Text = string.Format("{0} {1} {2}-{3}", grdServiceSearch.Data.Rows.Count, sStringData, 1, grdServiceSearch.Data.Rows.Count);
        //        lblFooterResults.Text = lblHeaderResult.Text;

        //    }
        //    else
        //    {
        //        grdServiceSearch.PageSize = Convert.ToInt32(ddlHeaderResultsPage.SelectedValue);
        //        SearchResults();
        //    }
        //    grdServiceSearch.DataSource = grdServiceSearch.Data;
        //    grdServiceSearch.DataBind();
        //    ddlFooterPageResults.SelectedValue = ddlHeaderResultsPage.SelectedValue;
        //    updPnlSearchService.Update();
        //}
        //else
        //{
        //    ddlFooterPageResults.SelectedValue = ddlHeaderResultsPage.SelectedValue;
        //} 
        #endregion
    }
}