﻿/*--------------------------------------------------------------------------------------------------------------------------------------------------
   Module      :   usrctl_mainmenu.ascx.cs
   Created By  :   Armstronno D'costa
   Created On  :   07 July 2009   
   Description :   This is top menu control.which will display menu to the user on the login user rights.

   Modification History
   Sr.No.	    Who		    Date				Description
   ----	        -------	    ---------			-----------
 * 1            Armstronno  10 Sept 2009        Added Rules page Link under System Menu. [System-->Rules]
 * 2            Sriker      20 Apr 2010         Corrected the User right for Messaging Settings
 * 3           Naadia Khan  4th August 2010     Added Package Search link under Booking menu [Booking-->Package Search]
 * 4           Naadia Khan  27th August 2010    Added Service Search link under Booking menu [Booking-->Service Search]
 * 5           Prasad       08 November 2010    Changes done in routine to add Menu items so that to fix the display problems with other language files.
 * 6           Ashfaq       27 june 2011        new menu changes
 * 7           Nagesh       29 June 2011        Added missing Yield Rule Setup and Query tool in the new menu changes
 * 8            Sriker      14 Jul 2011         Replaced GetUserName call with session variable
 * 9            Harshad     23 Aug 2011         Made CreateTempMenu method public so that other user controls can also call this method
 *                                              [issue:After postback menu disappears]
 * 10           Sriker      14 Sep 2011         Bug Fixes for Turkish culture
 * 11           Shivanand   16 Nov 2011         Added Instalment Discounts and Batch Instalment Generator [Client : ETS || Spec: ETS-04]
 * 12           Kedar       16 Nov 2011         Added Banked Receipts [Client : ETS | CR : ETS-11]
 * 13           Virag D.    16 Nov 2011         Added Currency.
 * 14           Sarika      18 Nov 2011         Added Exchange Rate under Finance tab of the menu.
 * 15           Sudeep      26 Nov 2011         Added Bank Profiles Under Accounts Menu [Client : ETS | CR : ETS-20]
 * 16           Deepa       22 Dec 2011         Added Agent Portal Settings Under Client.
 * 17           Jayesh      17 Jan 2012         Flights Menu
 * 18           Sarika      24 Jan 2012         Replication of Reset Cache fuctionality implementation
 * 19           Harshad     1 Feb  2012         Added Batch Invoice Creation under Finance tab of the menu.
 * 20           Silvia      15 Feb 2012         Created a Function to check permission of all report groups as repots are shown on one page
 * 21           Abhijit L.  16 Feb 2012         Added FrameLikn to Menu Link 
 * 22           Kedar       03 Apr 2012         Added "Availability Updater" [Client : ETS | CR : ETS-40]
 * 23           Wayne       16 Apr 2012         Added Special Requests under Flights tab.
 * 24           Harshad     20 Apr  2012        Added Purchase Invoice Creation/Reprint Invoices under Finance tab of the menu.
 * 25           SiddheshPrb 08 May 2012         Added Check Commission Payments under Finance menu, Commission Payment Approval under Booking menu
 * 26           Wayne       08 May 2012         Added Terms & Conditions under Flights tab.
 * 27           Ravish      25 Apr 2012         Added Batch Voucher Close sub menu for under Finance menu.
 * 28           Deepa       09 May 2012         Added Create GL Accounts under Finance tab.
 * 29           Sarika      10 May 2012         Added Tax Codes sub menu for under Finance menu.
 * 30           Silvia      17 May 2012         Changed Related to function name change in User manager for Option,Extra,Facilities & rating type
 * 31           Sriker      29 May 2012         Commented call to release licence {As per instructions from Savio}
 * 32           Aparna      01 Jun 2012         Passed SecurityConstantID to GetMenuAccessRights()
 * 33           Abhijit L.  01 Jun 2012         Added Task Manager under Booking
 * 34           Silvia      04 Jun 2012         Enabled Booked service search menu 
 * 35           Wayne       05 Jun 2012         Added "About" under System.
 * 36           Sarika      20 Jul 2012         Made changes.. shifted logout button and its code behind to TSV2Home page.
 * 37           Jayesh      20 Jul 2012         New Service Search
 * 38           Savira      08 July 2012        Logout button Issue Fix.
 * 39           Vanessa     17 Sep 2012         Added Batch Selling Price Generator under product menu
 * 40           Abhijit L.  04 Oct 2012         Changes done to show menu items in sorted order
 * 41           Kalpi       10 Jan 2013         Replicating changes for "Flight Service Fees" [Client:ETS || CR: ETS-77](Replicated on behalf of Kedar)
					Note: when adding new MenuItems, keep "enum" key, "switch - case" condition within GetPagePermissions() func, "multilingual name" same.
					for addition of MenuItem refer to "Agent_Group" Menu Item..
 * 42          Sandip Pawar  25 Jan 2012        Added Location under System TAb 
 * 43           Ravish       25 Jan 2013         Added Booking Flight Search      
 * 44           Harshad      13 Mar 2013         Added Export Financial Details
 * 45           Wayne        01 Apr 2013         Added Package main menu and New Package sub menu under Packages.
 * 46           Lorraine M   01 Apr 2013        Added Package Find
 * 47           Reema        13 May 2013        Added menu for CR TCA001-Farerulesconfiguration
 * 50           Sandip P.    08 May 2013        Added Fare Increase Decrease Handling
 * 55           Ashley       14 Nov 2014        ETS-95 Service Fee Enhancement
 * 49           Reema        24 May 2013        Added menu for CR TCA001 - Air Fare MarkUp Rules(Prioritizing Rules)
 * 53           Reema        5 Aug 2013         TCA001 : Chnage in menu name for Markuprule priorities.
 * 54           Harshad      15 oct 2013        39853-Promotional Package functionality
 * 57           Sarika       02 Jan 2014        Implemented Auto Login functionality
 * 53           Clerance     02 May 2015        Added menu for CR TCAASIA151B - Bulk Contract Maintainance

 * 58           kartheek     19 MAR 2014        Added Menu Items New Enquiry,Enquiry Search under Booking menu - CR : AUD78 - Enquiry [Client : Audley]
 * 60           Sarika       24 Apr 2014        Fixed issue: QATSVTWO-505/Clicking on Logout link does not redirect to login page when auto login is ON 
 * 61           Vimlesh      26 May 2014        Fixed Issue: QATSVTWO-555 Menu items are displayed irrespective of security permission selected at user manager level
 * 62           Debasis      26 Dec 2014        Added Task Lists under System Tab for CR MIKI-43 [CLIENT-MIKI]

 * 59           Vimlesh      07 Apr 2014        Implemented Mandatory/Discount Services
 * 60           Pradnya      07 Oct 2014        QATSVTWO-1185
 * 61           Amey.R       17 Apr 2015        CR : DT-109 (Sub Task : DT-157, Batch Receipts UI Changes)
 * 62           Gautami      29 Apr 2015        CR : DT-109 (Sub Task : DT-157, Batch Receipts UI Changes) Fixed issue:QATSVTWO-2200 Spelling mistake in the menu option 'Batch Reciepts Entry'.
 * 71           Poornima     16 Apr 2015        CR# TSVTWO-2023 Rail Search Menu
 * 58           Vikrant      04 Feb 2015        ETUR:151 Supplier Service Document
 * 59           Vikrant      14 May 2015        ETUR-202 Batch Sell price log
 * 59			Vrundavani   23 Jun 2015		CR : TSVTWO-880 (Sub Task : TSVTWO-2196 [Package Allocation UI Changes ])  
 * 62           Pranav       12 Jan 2015         Added Menu Invoice Daily Exchange Rate under Accounts [Client-DIETHELM : CR#DT-44]
 * 63			Vimlesh		 02 Apr 2015		DT-44 Added new field FileTypeid while creating menu
 * 63           Harshad      09 Jan 2015        MIKI-99
 * 64           Rejeena      12 Jan 2014        Miki-43 Section 7.5.2 (Security Considerations for Task Lists )
 * 64			Myrtle		 21 Oct 2015		Changes for STRAT-47
 * 65			Pradnya		 29 Jan 2015		MIKI-82 Sec 5.2(New Report Schedule Screen)
 * 66           Rupali       12 Feb 2015        #59537 Logging in as user without permissions there are some items still available in the Menu.
 * 63           Shruti       22 Oct 2015        CR : TSVTWO-861 (Package Waitlist Maintenance)
 * 51           Ravish       17 Jul 2013        Added menu for CR TCAASIA011 - Purchase Space Management
 * 52           Ravish       30 Jul 2013        CR TCAASIA011 - Purchase Space Management(updated SecurityConstantID - 403060)
 * 60           Poonam       20 Aug 2013        CR : TSVTOw-2330 
 * 60			Harshad      21 Aug 2015		TSVTWO-2330 - Dynamic Packaging - Flight & Hotel Search
 * 67			Shradha	 04	Feb 2016		Added changes for CR GSR-008 integration into CCWS for pensioner validation [CR: GSR-8 || Client : GSR]
 * 68           Devadree     25 Apr 2016        Fixed Issue QATS-3959
 * 67           Candida      7 april 2016       STRAT 69 Channel Manager  Configuration Menu Added Under System
 * 54           Sujata       19 Jun 2015        Added menu for CR TCAASIA151A - Bulk Contract Maintainance
 * 65           Dejalin      16 Nov 2015        CR : DA-16 section 7.1.2 User Security
 * 72           Nasia       21 July 2016       CR:TB-1: Applying Security permissions across#region ACCOUNTS SUB MENU Travel Builder - Flights,System
 * 73           Nasia        04 Aug 2016       CR TB-3:Sub Task TB-12: Change Existing Inline CSS and Subtask TB-16 Changes
 * 74           Nagesh       09 Nov 2016        CR TSVTWO-1021 -> Reports>Failed Messages
 * 75           Sunil        07 Dec 2016        CR TSVTWO-1021 -> Added acces permission.
 * 73           Nagesh       04 Nov 2016        CR RS-1 -> Handled User Permissions for Pricing Analysis item under Package menu
 * 76           Sneha S.     21 Dec 2016        CR RS-1 -> Handled Organisation setting flag
 * 80			Amrapali	 12 Jul 2017		CR:TSVTWO-1021,TSVTWO-1043 - Fixed SonarQube Issues
 * 77           Anshul      10 May 2017         CR: RS-26(RS-250) Added Submenu 'Purchase Invoice Import'.
 * 74           Tejas        25 March 2017       CR PER-17:Manage Train Delays
 * 78           PNaik        24 May 2017        CR: TSVTWO-3102 TSVTWO-3110 - Development Changes
 * 75			Harshad      17 Jan 2017		CR : DSO-99; Subtask -DSO-186 - New Menu/User Rights [Client: Emirates]
 * 74			Ravish		 29 Dec 2016		CR:DSO 100, Fixed Issue: QATSVTWO-6606 Menu Item name under Products not changed to 'Batch Service Sell Price Generator
 * 76			Clerance     13 Feb 2017		CR : DSO-237 : Migrate Extranet Settings window from TSv1 to TSv2 [Client: Emirates]
 * 79			Bipul		 06 Jul 2017	    CR: RS-29 BOF - Automated payments (without invoice) to vendors 
 * 80           Omkar N.     15 Dec 2017        CR: TSVTWO-979 Migrate Expiring Options screen
 * 81           Savira        27 Dec 2017        CR: TSVTWO-3727 New Booking Itinerary builder
 * 75           Sahil        21 Aug 2017         CR: DH-17 Air Cache | Sub Task ~ DH-331 - Integration of website pages in TSV2.
 * 82           Vaishakhi    09 Jan 2018        CR: TSVTWO-3727 New Booking Itinerary builder
 * 82           Vaishakhi    09 Jan 2018        CR: TSVTWO-3727 New Booking Itinerary builder
 * 83           Madhu        16 March 2018      CR: TSVTWO-3728 New Document Template Builder
 * 84           Rajesh       16 March 2018      CR: TSVTWO-3728 New Document Section Builder
 * 80           Sunil        22 Feb 2018        CR : TSVTWO-1040
 * 74           Siddhi B     3 May 2017         CR-Sub Task DH-75 -Added Schedule Change Manager under flight menu
 * 75           Pranav       02 Jun 2017       CR DH-25: Amadeus Schedule Changes
 * 81           Suchina      05 Jul 2018        CR: RS-9 - Code Review Comments
 * 84           Sajjan.H     02 Feb 2018        CR : PER-20 SUNAT Series numbers.* 
 * 84           Anita        08 Feb 2018        CR : PER-52 Select Organisation on login or pop-up
 * 86           Vismita      28 Aug 2018        ICR~PER-990 : Rail package search default
 * 70           Utkarsha     30 Dec 2017      CR:Added changes for ABA Refunds Export [Client:GSR, GSR-39]
 * 66           Dejalin      16 Nov 2015        CR : DA-16 section 7.1.2 User Security
 * 67		    Lorraine	 27 Jan 2017	    DA-3 Create a message code that displays the Exchange rates used to generate an invoice. 
 * 68           Bhaskar      07 Jan 2019        QATSVTWO-10594 : Can't access Products - Rail Manager

 * 85           Anish Thali  29 Nov 2018        Fixed Issue:98208:Company logo(top bar)- 90 x 23 pixels not loading correctly under Org/General..
 * 82  			Poonam 		 14 Dec 2017		CR: TSVTWO-3130 Migrate "End of Shift Reconciliation" (Receipt Reconciliation)
 * 82  			Poonam 		 14 Dec 2017		CR: TSVTWO-3130 Migrate "End of Shift Reconciliation" (Receipt Reconciliation)
 * 73           Amrapali     01 Dec 2016        CR: PCV-5 SMS Gateway Integration(Subtask: PCV-178)
 * 73           Purva        21 Nov 2016       SMS Gateway Integration. [CR : PCV-5 | Client : PCV]
 * 82           Wayne        23 Nov 2018        Changes for RS-1655 - Update departures optimisation (92830) [RS-1667].
 * 81           Omkar N.     25 Sept 2017       TSVTWO-887 Migrate ability to set up Discounts
--------------------------------------------------------------------------------------------------------------------------------------------------*/


using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Resources;
using System.Drawing;
using System.Globalization;
using SecurityManager;
using MultilingualManager;
using TSBrowser.Base;
using System.Collections.Generic;
//BOC Vimlesh(63)
using ServiceProxyManager.ProxyClasses.SystemSetup;
using ServiceProxyManager.ProxyClasses.Finance;
//EOC Vimlesh(63)
using System.IO;
using System.Data.SqlClient;
using System.Web.Script.Serialization;
using ODL.CommonFunctions.ViewModel;

public partial class usrctl_mainmenu : System.Web.UI.UserControl
{
	private class AppInfoJS
	{
		public string userName { get; set; }
		public string userId { get; set; }
		public string clientName { get; set; }
		public string clientLogoUrl { get; set; }
		public string databaseName { get; set; }
		public string organisationId { get; set; }
		public int? loginAccountId { get; set; }
		public List<DataClasses.SecurityClasses.UserRight> userPermissions { get; set; }
		public bool autoLogin { get; set; }
		public string uniqueId { get; set; }

		public AppInfoJS()
		{

		}

	}

	public int FileTypeID { get; set; }//Vimlesh(63)
	public string aboutTabString; //Nasia(73)
	public string AppInfo { get; set; }    
	public string MenuInfo { get; set; }
	public List<DataClasses.SecurityClasses.UserRight> userRights { get; set; }
  
	private Dictionary<string, VmMenuItem> _menu;
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			CommonFunctions.LoadApplicationSpecificStyle(this.Page);//Nasia(73)
			List<System.Web.UI.WebControls.LinkButton> lstLinkButton = new List<System.Web.UI.WebControls.LinkButton>();
			//lstLinkButton.Add(btnHome);
			//BOC Nasia(73)
			bool isTravelBuilderSet = SessionManager.TSBSession.IsTravelBuilder==null ? false : Convert.ToBoolean(SessionManager.TSBSession.IsTravelBuilder);
			isTravelBuilder.Value = isTravelBuilderSet.ToString();

			if (isTravelBuilderSet)
			{
				aboutTabString = "About_TB";
				Image1.ImageUrl = "~/Masters/Images/tblogo.png";
				//BOC Anish Thali(85)
				if (File.Exists(Server.MapPath("~/Masters/Images/client_Logo_90x23_1_tb.png")))
				{
					imgMicrosoftLogo.ImageUrl = "~/Masters/Images/client_Logo_90x23_1_tb.png";
				}
				else
				{
				imgMicrosoftLogo.ImageUrl = "~/Masters/Images/Client_Logo_90x23_tb.png";
			}
				//EOC Anish Thali(85)
			}
			else
			{
				aboutTabString = "About";
				Image1.ImageUrl = "~/Masters/Images/tslogo.png";
				if (File.Exists(Server.MapPath("~/Masters/Images/client_Logo_90x23_1.png")))
				{
					imgMicrosoftLogo.ImageUrl = "~/Masters/Images/client_Logo_90x23_1.png";
				}
				else
				{
					imgMicrosoftLogo.ImageUrl = "~/Masters/Images/Client_Logo_90x23.png";
				}
			}
			//EOC Nasia(73)
			lstLinkButton.Add(btnLogout);    //Sarika(36)
			//BOC Sriker(08)
			//GetUserName();//Added by Naadia Khan(01) Commented
			LnkUserName.Text = SessionManager.TSBSession.UserFullName;
		 //   LoginUser = SessionManager.TSBSession.UserFullName;
			//BOC Anita(84)
			string typeName = !string.IsNullOrEmpty(SessionManager.TSBSession.PointOfTransactionTypeName)? "("+ SessionManager.TSBSession.PointOfTransactionTypeName + ")":string.Empty;
			LnkPointOfTransactionType.Text = typeName;
			LnkPointOfTransactionType.ToolTip = SessionManager.TSBSession.PointOfTransactionTypeName;
			//EOC Anita(84)
			string databaseName = GetDatabaseName();
			string trimDatabaseName = "";
			if (databaseName.Length > 30)
			{
				trimDatabaseName = databaseName.Substring(0, 27) + "...";
			}
			lblDatabaseName.Text = IsDisplayDatabaseName() ? string.IsNullOrEmpty(trimDatabaseName) ? databaseName : trimDatabaseName : "";
			lblDatabaseName.ToolTip = databaseName;
			userRights = new List<DataClasses.SecurityClasses.UserRight>();

			userRights.AddRange(SessionManager.TSBSession.UserRights.Where(a => a.SecurityFunctionID == 21010 || a.SecurityFunctionID == 22050 || a.SecurityFunctionID == 27100).Select(q => q));
			var  appInfo = new AppInfoJS
			{
				userName = SessionManager.TSBSession.UserFullName,
				userId = SessionManager.TSBSession.UserID,
				clientName = SessionManager.TSBSession.ClientName,
				clientLogoUrl = imgMicrosoftLogo.ImageUrl,
				databaseName = lblDatabaseName.Text,
				organisationId = SessionManager.TSBSession.UserOrganisationID,
				loginAccountId = SessionManager.TSBSession.LoginAccountID,
				userPermissions = userRights,
				autoLogin = Convert.ToBoolean(Session["AutoLogin"]) ? true : false,
				uniqueId = SessionManager.TSBSession.SecurityKey
			};
			AppInfo = (new JavaScriptSerializer()).Serialize(appInfo);
   
			LnkUserName.ToolTip = SessionManager.TSBSession.UserName;
			//BOC Myrtle(64)
			if (!string.IsNullOrEmpty(SessionManager.TSBSession.LicensingMessage))
			{
				UnlicenseVersion.Style.Add("display", "block");
			}
			else
			{
				UnlicenseVersion.Style.Add("display", "none");
			}
			//EOC Myrtle(64)        
			//EOC Sriker(08)
			//TSBrowser.Base.Base.AssignPageControlText(lstLinkButton, null, Page.Master, null); //Commented by Abhijit L.(21)
			TSBrowser.Base.Base.AssignPageControlText(lstLinkButton, null, null, this); //Abhijit L.(21)  //Sarika(36)
			//BOC Vimlesh(63)
			string strfiletypeid = ValidateSystemWideSettings();//Vimlesh(63)
			if (strfiletypeid != "")
			{
				FileTypeID = Convert.ToInt32(strfiletypeid);
			}
			//BOC Vimlesh(63)
			CreateTempMenu();
			MenuInfo = (new JavaScriptSerializer()).Serialize(_menu.Values);
			var myScript = "var btnLogoutId =" + btnLogout.ClientID + ";";
			Page.ClientScript.RegisterStartupScript(this.GetType(), "RegisterStartupScript", myScript, true);
			//CreateMenuCollection1();
		}
	}

	private void AddToMenu(string menuId, HtmlAnchor aTag)
	{
		var subMenu = new VmMenuItem
		{
			Label = aTag.Title,
			DisplayLabel = aTag.InnerText,//aTag.Title,
			Url = aTag.HRef
		};

		var menuItem = _menu[menuId];
		if (menuItem.SubMenu == null)
			menuItem.SubMenu = new List<VmMenuItem> { subMenu };
		else
			((List<VmMenuItem>)menuItem.SubMenu).Add(subMenu);

	}
	//BOC Vimlesh(63)
	private string ValidateSystemWideSettings()
	{
		string RetVal = "0";
		GetSystemWideSettingsRequest ObjRequest = new GetSystemWideSettingsRequest();
		ObjRequest.GetSystemWideSettingsRequestData = new GetSystemWideSettingsRequestData();
		ObjRequest.GetSystemWideSettingsRequestData.SystemType = SystemTypes.Accounts;

		List<string> GenSettingsName = new List<string>();
		GenSettingsName.Add(AccountsSettingsName.AcctExportFileType.ToString());

		ObjRequest.GetSystemWideSettingsRequestData.ColumnNames = GenSettingsName;
		GetSystemWideSettingsResponse ObjResponse = new GetSystemWideSettingsResponse();
		ServiceProxyManager.Factory.SystemSetup.OrganisationFactory ObjFac = new ServiceProxyManager.Factory.SystemSetup.OrganisationFactory();
		ObjResponse = ObjFac.GetSystemWideSettings(ObjRequest);
		if (ObjResponse != null)
		{
			Hashtable ObjHshTbl = new Hashtable();
			foreach (GetSystemWideSettingsResponseData Objres in ObjResponse.GetSystemWideSettingResponseData)
			{
				ObjHshTbl.Add(Objres.FieldName, Objres.FieldValue);

			}
			RetVal = ObjHshTbl[AccountsSettingsName.AcctExportFileType.ToString()] == null ? "0" : Convert.ToString(ObjHshTbl[AccountsSettingsName.AcctExportFileType.ToString()]);


		}
		return RetVal;
	}
	//EOC Vimlesh(63)

	private bool IsDisplayDatabaseName()
	{
		bool displayDatabaseName = true;
		GetSystemWideSettingsRequest ObjRequest = new GetSystemWideSettingsRequest();
		ObjRequest.GetSystemWideSettingsRequestData = new GetSystemWideSettingsRequestData();
		ObjRequest.GetSystemWideSettingsRequestData.SystemType = SystemTypes.General;

		List<string> GenSettingsName = new List<string>();
		GenSettingsName.Add(GeneralSettingsColumnNames.DisplayDatabaseName.ToString());
		ObjRequest.GetSystemWideSettingsRequestData.ColumnNames = GenSettingsName;
		ServiceProxyManager.Factory.SystemSetup.OrganisationFactory ObjFac = new ServiceProxyManager.Factory.SystemSetup.OrganisationFactory();
		var ObjResponse = ObjFac.GetSystemWideSettings(ObjRequest);
		if (ObjResponse != null)
		{
			string fieldValue = ObjResponse.GetSystemWideSettingResponseData.Select(setting => setting.FieldValue).DefaultIfEmpty("false").First();
			displayDatabaseName = string.IsNullOrEmpty(fieldValue) ? false : Convert.ToBoolean(fieldValue);
		}

		return displayDatabaseName;


	}

	//BOC Vismita(86)
	protected bool IsOldPackageSearchUI()
	{
		GetSystemWideSettingsRequest ObjRequest = new GetSystemWideSettingsRequest();
		ObjRequest.GetSystemWideSettingsRequestData = new GetSystemWideSettingsRequestData();
		ObjRequest.GetSystemWideSettingsRequestData.SystemType = SystemTypes.Package;

		List<string> PackageSettingsName = new List<string>();
		PackageSettingsName.Add(PackageSettingColumnNames.UseOldPackageSearchUI.ToString());
		ObjRequest.GetSystemWideSettingsRequestData.ColumnNames = PackageSettingsName;
		GetSystemWideSettingsResponse ObjResponse = new GetSystemWideSettingsResponse();
		ServiceProxyManager.Factory.SystemSetup.OrganisationFactory ObjFac = new ServiceProxyManager.Factory.SystemSetup.OrganisationFactory();
		ObjResponse = ObjFac.GetSystemWideSettings(ObjRequest);
		if (ObjResponse != null)
		{
			string fieldValue = ObjResponse.GetSystemWideSettingResponseData.Select(setting => setting.FieldValue).DefaultIfEmpty("false").First();
			if (fieldValue == "True" || fieldValue == "1")
			{
				return true;
			}
			else
			{
				return false;
			}            
		}

		return false;

	}
	//EOC Vismita(86)

	protected void CreateMenuCollection()
	{
		//WHEN UPDATING THE URLS ALSO REMEMBER TO UPDATE THE WEB.SITEMAP FILE

		#region MAIN MENU

		Hashtable objMenuHashtable = new Hashtable();
		//objMenuHashtable.Add("Training", "Training");
		objMenuHashtable.Add("System", "System");
		objMenuHashtable.Add("Booking", "Booking");
		objMenuHashtable.Add("Quotes", "Quotes");
		objMenuHashtable.Add("Package", "Package");
		objMenuHashtable.Add("Clients", "Clients");
		objMenuHashtable.Add("Products", "Products");
		objMenuHashtable.Add("Flights", "Flights");
		objMenuHashtable.Add("Programs", "Programs");
		objMenuHashtable.Add("Reports Groups", "Reports");
		objMenuHashtable.Add("Accounts", "Accounts");
		objMenuHashtable.Add("Fulfillment", "Fulfillment");
		objMenuHashtable.Add("Setup", "Setup");

		objMenuHashtable = Base.GetMultilingualMessageList("Menu", objMenuHashtable);

		AddNewMenuItem(objMenuHashtable["Training"].ToString(), "Training", "Training");
		AddNewMenuItem(objMenuHashtable["System"].ToString(), "System", "system");
		AddNewMenuItem(objMenuHashtable["Booking"].ToString(), "Booking", "booking");
		AddNewMenuItem(objMenuHashtable["Quotes"].ToString(), "Quotes", "quotes");
		AddNewMenuItem(objMenuHashtable["Package"].ToString(), "Package", "Package");
		AddNewMenuItem(objMenuHashtable["Clients"].ToString(), "Clients", "clients");
		AddNewMenuItem(objMenuHashtable["Products"].ToString(), "Products", "product");
		AddNewMenuItem(objMenuHashtable["Flights"].ToString(), "Flights", "Flight");
		AddNewMenuItem(objMenuHashtable["Programs"].ToString(), "Programs", "Programs");
		AddNewMenuItem(objMenuHashtable["Reports Groups"].ToString(), "Reports Groups", "Reports");
		AddNewMenuItem(objMenuHashtable["Accounts"].ToString(), "Accounts", "Accounts");
		AddNewMenuItem(objMenuHashtable["Fulfillment"].ToString(), "Fullfillment", "Fullfillments");
		AddNewMenuItem(objMenuHashtable["Setup"].ToString(), "Setup", "Setup");

		#endregion Top Visisble Menus Items

		#region SUB MENUS

		#region SYSTEM SUB MENU
		//System Menu
		//Hashtable for System menu
		Hashtable systemHashtable = new Hashtable();
		systemHashtable.Add("GeoTree", "Geo Tree");
		systemHashtable.Add("Country", "Country");
		systemHashtable.Add("Statuses", "Statuses");
		systemHashtable.Add("Types", "Types");
		systemHashtable.Add("Charging Duration", "Charging Duration");
		systemHashtable.Add("Charging Policy", "Charging Policy");
		systemHashtable.Add("Image", "Image");
		systemHashtable.Add("Meal Plan", "Meal Plan");
		systemHashtable.Add("Meal Plan1", "Meal Plan1");
		systemHashtable.Add("Message Editor", "Message Editor");
		systemHashtable.Add("Rules", "Rules");
		systemHashtable.Add("User Manager", "User Manager");
		systemHashtable.Add("Organisation", "Organisation");
		systemHashtable.Add("Mileage Map", "Mileage Map");
		systemHashtable.Add("Commission Maintenance", "Commission Maintenance");
		systemHashtable.Add("Default Booking Tasks", "Default Booking Task");
		systemHashtable.Add("Messaging Settings", "Messaging Settings");
		systemHashtable.Add("End Point Configuration", "End Point Configuration");
		systemHashtable.Add("Import External Services", "Import External Services");
		systemHashtable.Add("QA Scripts", "QA Scripts");
		systemHashtable.Add("Reset Cache", "Reset Cache");    //Sarika(18)
		systemHashtable.Add(aboutTabString, aboutTabString); //Wayne(35) //Nasia(73)
		systemHashtable.Add("Location", "Location"); //Sandip P.(42)
		systemHashtable.Add("Price Update Status", "Price Update Status"); //Vikrant(59)
		systemHashtable.Add("Task Lists", "Task Lists");//Debasis(62)
		systemHashtable.Add("Channel Manager Configuration", "Channel Manager Configuration");//Candida(67)
		systemHashtable.Add("Register Widgets", "Register Widgets");
		systemHashtable.Add("Supplier Extranet Settings", "Supplier Extranet Settings"); //Clerance(76)
		systemHashtable.Add("Areas", "Areas"); //Vaishakhi(82)
		systemHashtable.Add("Document Template Library", "Document Template Library"); //Madhu(83)
		systemHashtable.Add("Document Component Section Library", "Document Component Section Library"); //Rajesh(84)
		systemHashtable.Add("Pricing Estimation Default", "Pricing Estimation Default");
		systemHashtable.Add("Queue Status", "Queue Status"); //Wayne(82)

		//systemHashtable.Add("Geotree3", "Geotree - Asp controls");
		systemHashtable = Base.GetMultilingualMessageList("Menu", systemHashtable);

		//AddNewSubMenuItem(systemHashtable["GeoTree"].ToString(), "GeoTree", MenuKeyIndex.System, "../Pages/System/GeoTree.aspx");
		AddNewSubMenuItem(systemHashtable["GeoTree"].ToString(), "GeoTree", MenuKeyIndex.System, "../Pages/System/GeoTree.aspx");
		AddNewSubMenuItem(systemHashtable["Country"].ToString(), "Country", MenuKeyIndex.System, "../Pages/System/Country.aspx");
		AddNewSubMenuItem(systemHashtable["Statuses"].ToString(), "Status Maintenance", MenuKeyIndex.System, "../Pages/Product/Status.aspx");
		AddNewSubMenuItem(systemHashtable["Types"].ToString(), "Types Maintenance", MenuKeyIndex.System, "../Pages/Product/Types.aspx");
		AddNewSubMenuItem(systemHashtable["Charging Duration"].ToString(), "Charging Duration", MenuKeyIndex.System, "../Pages/Product/ChargingDuration.aspx");
		AddNewSubMenuItem(systemHashtable["Charging Policy"].ToString(), "Charging Policy", MenuKeyIndex.System, "../Pages/Product/ChargingPolicy.aspx");
		AddNewSubMenuItem(systemHashtable["Image"].ToString(), "Image", MenuKeyIndex.System, "../Pages/Product/ImageSearch.aspx");
		AddNewSubMenuItem(systemHashtable["Meal Plan"].ToString(), "Meal Plan", MenuKeyIndex.System, "../Pages/Product/MealPlan.aspx");
		AddNewSubMenuItem(systemHashtable["Message Editor"].ToString(), "Messaging", MenuKeyIndex.System, "");
		AddNewSubMenuItem(systemHashtable["Rules"].ToString(), "Rules", MenuKeyIndex.System, "../Pages/Product/Rules.aspx");
		AddNewSubMenuItem(systemHashtable["User Manager"].ToString(), "User Manager", MenuKeyIndex.System, "../Pages/System/UserManager.aspx");
		AddNewSubMenuItem(systemHashtable["Organisation"].ToString(), "Organisation", MenuKeyIndex.System, "../Pages/Organisation/Organisation.aspx");
		AddNewSubMenuItem(systemHashtable["Mileage Map"].ToString(), "Mileage Map", MenuKeyIndex.System, "../Pages/System/MileageMap.aspx");
		AddNewSubMenuItem(systemHashtable["Commission Maintenance"].ToString(), "Commission Maintenance", MenuKeyIndex.System, "../Pages/Product/CommisionScheme.aspx");
		AddNewSubMenuItem(systemHashtable["Default Booking Tasks"].ToString(), "Default Booking Task", MenuKeyIndex.System, "");
		AddNewSubMenuItem(systemHashtable["Messaging Settings"].ToString(), "Auto Messaging", MenuKeyIndex.System, "../Pages/Messaging/TSWeb.aspx");
		AddNewSubMenuItem(systemHashtable["End Point Configuration"].ToString(), "End Point Configuration", MenuKeyIndex.System, "");
		AddNewSubMenuItem(systemHashtable["Import External Services"].ToString(), "Import External Services", MenuKeyIndex.System, "");
		AddNewSubMenuItem(systemHashtable["QA Scripts"].ToString(), "QA Scripts", MenuKeyIndex.System, "../Pages/System/QAScripts.aspx");
		AddNewSubMenuItem(systemHashtable["Reset Cache"].ToString(), "Reset Cache", MenuKeyIndex.System, "~/Home.aspx?ResetSystemCache=true");//Sarika(18)
		AddNewSubMenuItem(systemHashtable[aboutTabString].ToString(),aboutTabString, MenuKeyIndex.System, "../Pages/System/About.aspx"); //Nasia(73)
		AddNewSubMenuItem(systemHashtable["Location"].ToString(), "Location", MenuKeyIndex.System, "../Pages/System/Location.aspx"); //Sandip P.(42)
		AddNewSubMenuItem(systemHashtable["Price Update Status"].ToString(), "Price Update Status", MenuKeyIndex.System, "../Pages/System/PriceUpdateStatus.aspx"); //Vikrant(59)
		AddNewSubMenuItem(systemHashtable["Task Lists"].ToString(), "Task Lists", MenuKeyIndex.System, "DefaultTasks/DefaultTasks");//Debasis(62)
		//AddNewSubMenuItem(systemHashtable["Geotree3"].ToString(), "GeoTree", MenuKeyIndex.System, "../Pages/System/GeoTreeWithOutSyncTab.aspx");
		AddNewSubMenuItem(systemHashtable["Channel Manager Configuration"].ToString(), "Channel Manager Configuration", MenuKeyIndex.System, "../Pages/System/ChannelManagerConfiguration.aspx");//Candida(67)
		AddNewSubMenuItem(systemHashtable["Register Widgets"].ToString(), "Register Widgets", MenuKeyIndex.System, "RegisterWidget/RegisterWidgets");
		AddNewSubMenuItem(systemHashtable["Supplier Extranet Settings"].ToString(), "Supplier Extranet Settings", MenuKeyIndex.System, "../Pages/System/SupplierExtranetSettings.aspx");//Clerance(76)
		AddNewSubMenuItem(systemHashtable["Areas"].ToString(), "Areas", MenuKeyIndex.System, "Areas/Areas"); //Vaishakhi(82)
		AddNewSubMenuItem(systemHashtable["Document Template Library"].ToString(), "Document Template Library", MenuKeyIndex.System, "TemplateBuilder/TemplateBuilder"); //Madhu(83)
		AddNewSubMenuItem(systemHashtable["Document Component Section Library"].ToString(), "Document Component Section Library", MenuKeyIndex.System, "DocumentSectionBuilder/DocumentSectionBuilder"); //Rajesh(84)
		AddNewSubMenuItem(systemHashtable["Pricing Estimation Default"].ToString(), "Pricing Estimation Default", MenuKeyIndex.System, "PricingEstimationDefault/PricingEstimationDefault");

		
		AddNewSubMenuItem(systemHashtable["Queue Status"].ToString(), "Queue Status", MenuKeyIndex.System, "||../QueueStatus/QueueStatus"); //Wayne(82)
		#endregion

		#region BOOKING SUB MENU

		//Hash Table for Booking Sub Menu
		Hashtable bookingHashTable = new Hashtable();
		bookingHashTable.Add("New Booking", "New Booking");
		bookingHashTable.Add("Booking Find", "Booking Search");
		bookingHashTable.Add("Replicate Bookings", "Replicate Bookings");
		bookingHashTable.Add("Package Search", "Package Search");
		bookingHashTable.Add("Passenger Maint.", "Passenger Maintenance");
		bookingHashTable.Add("Commission Payment Approval", "Comm. Payment Appr.");
		bookingHashTable.Add("PNR Shadow List", "PNR Shadow List");
		bookingHashTable.Add("Change Booking Expiry Date", "Expired Options");
		bookingHashTable.Add("Villa Booking", "Villa Search");
		bookingHashTable.Add("Service Search", "Service Search");
		bookingHashTable.Add("Booking Import", "Booking Import");
		bookingHashTable.Add("Rail Search", "Rail Search");
		bookingHashTable.Add("NCOA Address Export", "NCOA Address Export");
		bookingHashTable.Add("Bulk Service Replacement", "Bulk Service Replacement");
		bookingHashTable.Add("Booked Service Search", "Booked Service Search");
		bookingHashTable.Add("Batch Status Update", "Batch Status Update");
		bookingHashTable.Add("Flight Search", "Search / Book Flight.");
		bookingHashTable.Add("Task Manager", "Task Manager"); //Abhijit L.(33)
		bookingHashTable.Add("Book Promotional Package", "Book Promotional Package"); //Harshad(54)
		bookingHashTable.Add("New Enquiry", "New Enquiry");        //kartheek(58)
		bookingHashTable.Add("Enquiry Search", "Enquiry Search");  //kartheek(58)
		bookingHashTable.Add("Purchase Space Management", "Purchase Space Management"); //Ravish(51)
		bookingHashTable.Add("Flight & Hotel Search", "Flight & Hotel Search");  //Harshad(60)
		bookingHashTable.Add("Generate XMLs", "Generate XMLs");  //Shradha(67)
		// bookingHashTable = Base.GetMultilingualMessageList("Menu", bookingHashTable);
		bookingHashTable.Add("Operations Module", "Operations Module"); //Dejalin(65)
		bookingHashTable.Add("Rail Check In", "Rail Check In");//Tejas(74)
		bookingHashTable.Add("Dynamic Package Search", "Dynamic Package Search");  //Harshad(75)
		bookingHashTable.Add("Expiring Options", "Expiring Options");//Omkar N.(80)
		bookingHashTable.Add("Batch Message Generation", "Batch Message Generation");
		//Priya
		bookingHashTable.Add("Batch Booking Task Generation", "Batch Booking Task Generation");         //Purva(73)

		//Booking Menu
		AddNewSubMenuItem(bookingHashTable["New Booking"].ToString(), "New Booking", MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable["Booking Find"].ToString(), "Booking Find", MenuKeyIndex.Bookings, "../Pages/Booking/BookingSearchResults.aspx");
		AddNewSubMenuItem(bookingHashTable["Replicate Bookings"].ToString(), "Replicate Bookings", MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable["Package Search"].ToString(), "Package Search", MenuKeyIndex.Bookings, "../Pages/Booking/BookingPackageSearch.aspx");
		//BOC Vismita(86)
		if (IsOldPackageSearchUI())
		{
			AddNewSubMenuItem(bookingHashTable["Package Search"].ToString(), "Package Search", MenuKeyIndex.Bookings, "../Pages/Booking/BookingPackageSearch.aspx");
		}
		else
		{
			AddNewSubMenuItem(bookingHashTable["Package Search"].ToString(), "Advanced Package Search", MenuKeyIndex.Bookings, "../Pages/Booking/BookingPackageSearch.aspx");
		}
		//EOC Vismita(86)       
		AddNewSubMenuItem(bookingHashTable["Passenger Maint."].ToString(), "Passenger Maint.", MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable["Commission Payment Approval"].ToString(), "Commission Payment Approval", MenuKeyIndex.Bookings, "../Pages/Booking/CommissionPaymentsApproval.aspx");    //SiddheshPrb(25)
		AddNewSubMenuItem(bookingHashTable["PNR Shadow List"].ToString(), "PNR Shadow List", MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable["Change Booking Expiry Date"].ToString(), "Change Booking Expiry Date", MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable["Villa Booking"].ToString(), "Villa Booking", MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable["Service Search"].ToString(), "Service Search", MenuKeyIndex.Bookings, "../Pages/ServiceSearch/TSServiceSearch.aspx");   //Jayesh(37)
		AddNewSubMenuItem(bookingHashTable["Booking Import"].ToString(), "Booking Import", MenuKeyIndex.Bookings, "");
		//Check for display rail flag from organization settings to enable below menu for Rail
		AddNewSubMenuItem(bookingHashTable["Rail Search"].ToString(), "Rail Search", MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable["NCOA Address Export"].ToString(), "NCOA Address Export", MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable["Bulk Service Replacement"].ToString(), "Bulk Service Replacement", MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable["Booked Service Search"].ToString(), "Booked Service Search", MenuKeyIndex.Bookings, "../Pages/Booking/BookedServiceSearch.aspx");//Ravish(34)
		AddNewSubMenuItem(bookingHashTable["Batch Status Update"].ToString(), "Batch Status Update", MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable["Flight Search"].ToString(), "Flight Search", MenuKeyIndex.Bookings, "../Pages/Booking/FlightSearch.aspx");//Ravish(43)
		AddNewSubMenuItem(bookingHashTable["Task Manager"].ToString(), "Task Manager", MenuKeyIndex.Bookings, "../Pages/Booking/TaskManager.aspx"); //Abhijit L.(33)
		AddNewSubMenuItem(bookingHashTable["Book Promotional Package"].ToString(), "Book Promotional Package", MenuKeyIndex.Bookings, "../Pages/Packages/PromotionalPackageSearch.aspx"); //Harshad(54)
		AddNewSubMenuItem(bookingHashTable["New Enquiry"].ToString(), "New Enquiry", MenuKeyIndex.Bookings, "ItineraryBuilder/ItineraryBuilder");              //kartheek(58)//Savira(81)
		AddNewSubMenuItem(bookingHashTable["Enquiry Search"].ToString(), "Enquiry Search", MenuKeyIndex.Bookings, "../Pages/Booking/EnquirySearch.aspx");  //kartheek(58)
		AddNewSubMenuItem(bookingHashTable["Purchase Space Managemen"].ToString(), "Purchase Space Management", MenuKeyIndex.Bookings, "../Pages/Booking/PurchaseSpaceManagement.aspx"); //Ravish(51)
		AddNewSubMenuItem(bookingHashTable["Flight & Hotel Search"].ToString(), "Flight & Hotel Search", MenuKeyIndex.Bookings, "../Pages/Booking/FlightHotelSearch.aspx"); //Harshad(60)       
		AddNewSubMenuItem(bookingHashTable["Generate XMLs"].ToString(), "Generate XMLs", MenuKeyIndex.Bookings, "../Pages/Booking/GenerateXml.aspx");  //Shradha(67)
		AddNewSubMenuItem(bookingHashTable["Operations Module"].ToString(), "Operations Module", MenuKeyIndex.Bookings, "../Pages/Booking/OperationsModule.aspx"); //Dejalin(65)
		AddNewSubMenuItem(bookingHashTable["Rail Check In"].ToString(), "Rail Check In", MenuKeyIndex.Bookings, ""); //Tejas(74)
		AddNewSubMenuItem(bookingHashTable["Dynamic Package Search"].ToString(), "Dynamic Package Search", MenuKeyIndex.Bookings, "../Pages/Booking/DynamicPackageSearch.aspx"); //Harshad(75)
		AddNewSubMenuItem(bookingHashTable["Expiring Options"].ToString(), "Expiring Options", MenuKeyIndex.Bookings, "ExpiringOptions/ExpiringOptionsContainer"); //Omkar N.(80)
		AddNewSubMenuItem(bookingHashTable["Batch Message Generation"].ToString(), "Batch Message Generation", MenuKeyIndex.Bookings, "../Messages/BatchMessageGeneration"); ////Priya
		AddNewSubMenuItem(bookingHashTable["Batch Booking Task Generation"].ToString(), "Batch Booking Task Generation", MenuKeyIndex.Bookings, "../Pages/Booking/BatchBookingTaskGeneration.aspx");        //Purva(73)
		#endregion

		#region QUOTES SUB MENU
		//Hashtable for Quote menu
		Hashtable quoteHashtable = new Hashtable();
		quoteHashtable.Add("New Quote", "New Quote");
		quoteHashtable.Add("Quote Search", "Quote Search");
		quoteHashtable.Add("Quote Default", "Quote Default");

		//    quoteHashtable = Base.GetMultilingualMessageList("Menu", quoteHashtable);

		//Quote Menu
		AddNewSubMenuItem(quoteHashtable["New Quote"].ToString(), "New Quote", MenuKeyIndex.Quotes, "");
		AddNewSubMenuItem(quoteHashtable["Quote Search"].ToString(), "Quote Search", MenuKeyIndex.Quotes, "");
		AddNewSubMenuItem(quoteHashtable["Quote Default"].ToString(), "Quote Default", MenuKeyIndex.Quotes, "");

		#endregion

		#region PACKAGE SUB MENU
		//Package Hashtable
		Hashtable packageHashtable = new Hashtable();
		packageHashtable.Add("New Package", "New Package");
		packageHashtable.Add("Package Find", "Package Find");
		packageHashtable.Add("Package Maintenance", "Departure Maintenance");
		packageHashtable.Add("Package Data", "Package Data");
		packageHashtable.Add("Package Brochure", "Package Brochure");
		packageHashtable.Add("Waitlist Maintenance", "Waitlist Maintenance");
		packageHashtable.Add("Batch Package Sell Price Creation", "Batch Pkg Sell Price Creation");
		packageHashtable.Add("Package Facilities", "Package Facilities");
		packageHashtable.Add("Pattern Splitting Wizard", "Pattern Splitting Wizard");
		packageHashtable.Add("Batch Service Details Update", "Batch Service Details Update");
		//Check for  if edit right of package for below menu
		packageHashtable.Add("Update Departure Cost", "Update Departure Cost");
		packageHashtable.Add("Package Inventory", "Package Inventory");

		//    packageHashtable = Base.GetMultilingualMessageList("Menu", packageHashtable);

		//Package Menu
		AddNewSubMenuItem(packageHashtable["New Package"].ToString(), "New Package", MenuKeyIndex.Package, "PackageBuilder/NewPackageRedirection");    //Wayne(45)
		AddNewSubMenuItem(packageHashtable["Package Find"].ToString(), "Package Find", MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable["Package Maintenance"].ToString(), "Package Maintenance", MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable["Package Data"].ToString(), "Package Data", MenuKeyIndex.Package, "../Pages/Packages/PackageData.aspx"); //Vrundavani(59)
		AddNewSubMenuItem(packageHashtable["Package Brochure"].ToString(), "Package Brochure", MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable["Waitlist Maintenance"].ToString(), "Waitlist Maintenance", MenuKeyIndex.Package, "../Pages/Packages/WaitlistMaintenance.aspx");//Shruti(63)
		AddNewSubMenuItem(packageHashtable["Batch Package Sell Price Creation"].ToString(), "Batch Package Sell Price Creation", MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable["Package Facilities"].ToString(), "Package Facilities", MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable["Pattern Splitting Wizard"].ToString(), "Pattern Splitting Wizard", MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable["Batch Service Details Update"].ToString(), "Batch Service Details Update", MenuKeyIndex.Package, "");
		//Check for  if edit right of package for below menu
		AddNewSubMenuItem(packageHashtable["Update Departure Cost"].ToString(), "New Package", MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable["Package Inventory"].ToString(), "Package Inventory", MenuKeyIndex.Package, "");
		#endregion

		#region CLIENTS SUB MENU

		Hashtable clientsHashtable = new Hashtable();
		clientsHashtable.Add("Client", "Agent");
		clientsHashtable.Add("Client Group", "Agent Group");
		clientsHashtable.Add("Agent Group Commission Update", "Agent Group Commission Update");
		clientsHashtable.Add("Agent Import", "Agents Import");
		clientsHashtable.Add("New Client Credit", "New Client Credit");
		clientsHashtable.Add("Access To Client Credits Interface", "Search Client Credit");
		clientsHashtable.Add("Default Price Type", "Price Type Default");
		clientsHashtable.Add("Merge Passenger Bookings", "Merge Passenger Bookings");
		clientsHashtable.Add("Passenger", "Passenger Maintenance");
		clientsHashtable.Add("Marketing Survey Import", "Marketing Survey Import");
		clientsHashtable.Add("Passenger Maintenance", "Passenger Maintenance");
		clientsHashtable.Add("Agent Portal Settings", "Agent Portal Settings"); //Deepa(16)

		//clientsHashtable = Base.GetMultilingualMessageList("Menu", clientsHashtable);

		//Clients Menu
		AddNewSubMenuItem(clientsHashtable["Client"].ToString(), "Client", MenuKeyIndex.Clients, "../Pages/Client/AgentSearch.aspx");
		AddNewSubMenuItem(clientsHashtable["Client Group"].ToString(), "Client Group", MenuKeyIndex.Clients, "../Pages/Client/AgentGroup.aspx");
		if (GetAgentGroupCommissionFlag())
			AddNewSubMenuItem(clientsHashtable["Agent Group Commission Update"].ToString(), "Agent Group Commission Update", MenuKeyIndex.Clients, "../Pages/Client/AgentGroupCommission.aspx");
		AddNewSubMenuItem(clientsHashtable["Agent Import"].ToString(), "Agent Import", MenuKeyIndex.Clients, "");
		AddNewSubMenuItem(clientsHashtable["New Client Credit"].ToString(), "Agent Import", MenuKeyIndex.Clients, "../Pages/Client/NewClientCredit.aspx");
		AddNewSubMenuItem(clientsHashtable["Access To Client Credits Interface"].ToString(), "Access To Client Credits Interface", MenuKeyIndex.Clients, "../Pages/Client/SearchClientCredit.aspx");
		AddNewSubMenuItem(clientsHashtable["Default Price Type"].ToString(), "Default Price Type", MenuKeyIndex.Clients, "../Pages/Client/PriceTypeDefault.aspx");
		AddNewSubMenuItem(clientsHashtable["Merge Passenger Bookings"].ToString(), "Merge Passenger Bookings", MenuKeyIndex.Clients, "");
		AddNewSubMenuItem(clientsHashtable["Passenger"].ToString(), "Passenger Maint.", MenuKeyIndex.Clients, "../Pages/Client/PassengerSearch.aspx");
		AddNewSubMenuItem(clientsHashtable["Marketing Survey Import"].ToString(), "Marketing Survey Import", MenuKeyIndex.Clients, "");
		AddNewSubMenuItem(clientsHashtable["Agent Portal Settings"].ToString(), "Agent Portal Settings", MenuKeyIndex.Clients, "../Pages/Client/AgentPortalSettings.aspx");//Deepa(16)


		#endregion

		#region PRODUCTS SUB MENU

		Hashtable productsHashtable = new Hashtable();
		productsHashtable.Add("Supplier", "Supplier");
		productsHashtable.Add("Service", "Service");
		productsHashtable.Add("Contract", "Contract");
		productsHashtable.Add("Villa Group", "Villa Group");
		productsHashtable.Add("ST Option", "Option");
		productsHashtable.Add("ST Extra", "Extra");
		productsHashtable.Add("ST Facilities", "Facilities");
		productsHashtable.Add("ST Type Rating", "Rating");
		productsHashtable.Add("Child Policy", "Child Policy");
		productsHashtable.Add("Supplier Group", "Supplier Group");
		productsHashtable.Add("Batch Selling Price Creation", "Batch Selling Price Creation");
		productsHashtable.Add("Batch Price Type Associator", "Batch Price Type Associator");
		productsHashtable.Add("Batch Rule Generation", "Batch Rule Generator");
		//Check for display rail flag from organization settings to enable below menu for Rail
		productsHashtable.Add("Rail Manager", "Rail Manager");
		productsHashtable.Add("Allocation Name", "Allocation Name");
		productsHashtable.Add("Web Passenger Questions", "Web Passenger Questions");
		productsHashtable.Add("Service Type Questions", "Service Type Questions");
		productsHashtable.Add("Cancellation Policies", "Cancellation Policies");
		productsHashtable.Add("Service Pricing", "Service Pricing");
		//productsHashtable.Add("Access to Mandatory Services", "Mandatory/Discount Services");//Vimlesh(59)
		productsHashtable.Add("Mandatory Services Access", "Mandatory/Discount Services");//Vimlesh(59)
		productsHashtable.Add("Service Export Import", "Service Export Import");
		productsHashtable.Add("Villa Room Name", "Villa Room Name");
		productsHashtable.Add("Update Booking Costs", "Update Booking Costs");
		productsHashtable.Add("Supplier Extranet Messages", "Supplier Extranet Messages");
		productsHashtable.Add("Yield Rule Setup", "Yield Rule Setup");
		productsHashtable.Add("Query Tool", "Query Tool");
		productsHashtable.Add("Instalment Discounts", "Instalment Discounts");//Shivanand(11)
		productsHashtable.Add("Batch Instalment Generator", "Batch Instalment Generator");//Shivanand(11)
		productsHashtable.Add("Availability Updater", "Availability Updater"); //Kedar(22)
		productsHashtable.Add("Supplier Service Document", "Supplier Service Document");//Vikrant(58)
		//  productsHashtable = Base.GetMultilingualMessageList("Menu", productsHashtable);
		productsHashtable.Add("Bulk Contract Maintainance", "Bulk Contract Maintenance"); //Clerance(53)
		productsHashtable.Add("Bulk Contract Maintainance History", "Bulk Contract Maintenance History"); //Clerance(53)        //  productsHashtable = Base.GetMultilingualMessageList("Menu", productsHashtable);
		productsHashtable.Add("Offline Price Editor", "Offline Price Editor"); //Sujata(54)
		productsHashtable.Add("Discount", "Discount"); //Omkar N.(81)

		//Products Menu
		AddNewSubMenuItem(productsHashtable["Supplier"].ToString(), "Supplier", MenuKeyIndex.Products, "../Pages/Client/SupplierSearch.aspx");
		AddNewSubMenuItem(productsHashtable["Service"].ToString(), "Service", MenuKeyIndex.Products, "../Pages/Services/ServiceSearch.aspx");
		AddNewSubMenuItem(productsHashtable["Contract"].ToString(), "Contract", MenuKeyIndex.Products, "../Pages/Product/Contracts.aspx");
		AddNewSubMenuItem(productsHashtable["Villa Group"].ToString(), "Villa Group", MenuKeyIndex.Products, "../Pages/Product/VillaGroup.aspx");
		AddNewSubMenuItem(productsHashtable["ST Option"].ToString(), "ST Option", MenuKeyIndex.Products, "../Pages/Product/Option.aspx");
		AddNewSubMenuItem(productsHashtable["ST Extra"].ToString(), "ST Extra", MenuKeyIndex.Products, "../Pages/Product/Extra.aspx");
		AddNewSubMenuItem(productsHashtable["ST Facilities"].ToString(), "ST Facilities", MenuKeyIndex.Products, "../Pages/Product/Facilities.aspx");
		AddNewSubMenuItem(productsHashtable["ST Type Rating"].ToString(), "ST Type Rating", MenuKeyIndex.Products, "../Pages/Product/Ratings.aspx");
		AddNewSubMenuItem(productsHashtable["Child Policy"].ToString(), "Child Policy", MenuKeyIndex.Products, "../Pages/Product/ChildPolicy.aspx");
		AddNewSubMenuItem(productsHashtable["Supplier Group"].ToString(), "Supplier Group", MenuKeyIndex.Products, "../Pages/Product/SupplierGroups.aspx");
		AddNewSubMenuItem(productsHashtable["Batch Selling Price Creation"].ToString(), "Batch Selling Price Creation", MenuKeyIndex.Products, "../Pages/Product/BatchSellingPriceGenerator.aspx");
		AddNewSubMenuItem(productsHashtable["Batch Price Type Associator"].ToString(), "Batch Price Type Associator", MenuKeyIndex.Products, "");
		AddNewSubMenuItem(productsHashtable["Batch Rule Generation"].ToString(), "Batch Rule Generation", MenuKeyIndex.Products, "../Pages/Product/BatchRuleGenerator.aspx");
		//Check for display rail flag from organization settings to enable below menu for Rail
		AddNewSubMenuItem(productsHashtable["Rail Manager"].ToString(), "Rail Manager", MenuKeyIndex.Products, "");
		AddNewSubMenuItem(productsHashtable["Allocation Name"].ToString(), "Allocation Name", MenuKeyIndex.Products, "../Pages/Product/AllocationName.aspx");
		AddNewSubMenuItem(productsHashtable["Web Passenger Questions"].ToString(), "Web Passenger Questions", MenuKeyIndex.Products, "../Pages/Product/WebPassengerQuestions.aspx");
		AddNewSubMenuItem(productsHashtable["Service Type Questions"].ToString(), "Service Type Questions", MenuKeyIndex.Products, "../Pages/Product/ServiceTypeQuestions.aspx");
		AddNewSubMenuItem(productsHashtable["Cancellation Policies"].ToString(), "Cancellation Policies", MenuKeyIndex.Products, "../Pages/Product/CancellationPolicy.aspx");
		AddNewSubMenuItem(productsHashtable["Service Pricing"].ToString(), "Service Pricing", MenuKeyIndex.Products, "");
		//AddNewSubMenuItem(productsHashtable["Access to Mandatory Services"].ToString(), "Access to Mandatory Services", MenuKeyIndex.Products, "");//Vimlesh(58)
		AddNewSubMenuItem(productsHashtable["Mandatory Services Access"].ToString(), "Mandatory Services Access", MenuKeyIndex.Products, "../Pages/Product/MandatoryServices.aspx");//Vimlesh(58)
		AddNewSubMenuItem(productsHashtable["Service Export Import"].ToString(), "Service Export Import", MenuKeyIndex.Products, "");
		AddNewSubMenuItem(productsHashtable["Villa Room Name"].ToString(), "Villa Room Name", MenuKeyIndex.Products, "../Pages/Product/VillaRoomName.aspx");
		AddNewSubMenuItem(productsHashtable["Update Booking Costs"].ToString(), "Update Booking Costs", MenuKeyIndex.Products, "");
		AddNewSubMenuItem(productsHashtable["Supplier Extranet Messages"].ToString(), "Supplier Extranet Messages", MenuKeyIndex.Products, "../Pages/Product/SupplierExtranetMessage.aspx");
		AddNewSubMenuItem(productsHashtable["Yield Rule Setup"].ToString(), "Yield Rule Setup", MenuKeyIndex.Products, "../Pages/Product/YieldRules.aspx");
		AddNewSubMenuItem(productsHashtable["Query Tool"].ToString(), "Query Tool", MenuKeyIndex.Products, "../Pages/Product/QueryTool.aspx");
		AddNewSubMenuItem(productsHashtable["Instalment Discounts"].ToString(), "Instalment Discounts", MenuKeyIndex.Products, "../Pages/Product/InstalmentDiscounts.aspx");//Shivanand(11)
		AddNewSubMenuItem(productsHashtable["Batch Instalment Generator"].ToString(), "Batch Instalment Generator", MenuKeyIndex.Products, "../Pages/Product/BatchInstalmentGenerator.aspx");//Shivanand(11)
		AddNewSubMenuItem(productsHashtable["Availability Updater"].ToString(), "Availability Updater", MenuKeyIndex.Products, "../Pages/Product/AvailabilityUpdater.aspx");//Kedar(22)
		AddNewSubMenuItem(productsHashtable["Supplier Service Document"].ToString(), "Supplier Service Document", MenuKeyIndex.Products, "..Pages/Product/SupplierServiceDocument.aspx");//Vikrant(58)`
		AddNewSubMenuItem(productsHashtable["Bulk Contract Maintainance"].ToString(), "Bulk Contract Maintainance", MenuKeyIndex.Products, "../Pages/Product/BulkContractMaintainance.aspx"); //Clerance(53)
		AddNewSubMenuItem(productsHashtable["Bulk Contract Maintainance History"].ToString(), "Bulk Contract Maintainance History", MenuKeyIndex.Products, "../Pages/Product/BulkContractMaintainanceHistory.aspx"); //Clerance(53)
		AddNewSubMenuItem(productsHashtable["Offline Price Editor"].ToString(), "Offline Price Editor", MenuKeyIndex.Products, "../Pages/Product/OfflinePriceEditor.aspx"); //Sujata(54)
		AddNewSubMenuItem(productsHashtable["Discount"].ToString(), "Discount", MenuKeyIndex.Products, ""); //Omkar N.(81)

		#endregion

		#region FLIGHTS SUB MENU
		//Hashtabel for flights menu
		Hashtable flightHashtable = new Hashtable();
		flightHashtable.Add("Airlines", "Airlines");
		flightHashtable.Add("Airports", "Airports"); //Poonam(60)
		flightHashtable.Add("Flight Cities", "Flight Cities");
		flightHashtable.Add("Special Requests", "Special Requests");
		flightHashtable.Add("Schedule Change Manager", "Schedule Change Manager"); //Siddhi B(74)
		flightHashtable.Add("Flight Schedule Utility", "Flight Schedule Change Utility");
		flightHashtable.Add("Update FSDT Flight Booking Details", "Update FSDT Flight Booking Details");
		flightHashtable.Add("Terms & Conditions", "Terms & Conditions");
		flightHashtable.Add("Flight Service Fees", "Flight Service Fees"); //Kalpi(41)
		flightHashtable.Add("Fare Rules Configuration", "Fare Rules Configuration"); //Reema(47)
		flightHashtable.Add("Markup Rule Priorities", "Markup Rule Priorities"); //Reema(49)  Reema (53)
		flightHashtable.Add("Fare Increase/Decrease Handling", "Fare Increase/Decrease Handling"); //Sandip P.(50)
		flightHashtable.Add("Agent Markup on Service Fee", "Agent Markup on Service Fee"); //Ashley(55)
		flightHashtable.Add("Agent Flights Commission", "Agent Flights Commission"); //Rejeena

		//  flightHashtable = Base.GetMultilingualMessageList("Menu", flightHashtable);

		//Flight Menu
		AddNewSubMenuItem(flightHashtable["Airlines"].ToString(), "Airlines", MenuKeyIndex.Flights, "");
		AddNewSubMenuItem(flightHashtable["Airports"].ToString(), "Airports", MenuKeyIndex.Flights, ""); //Poonam(60)
		AddNewSubMenuItem(flightHashtable["Flight Cities"].ToString(), "Flight Cities", MenuKeyIndex.Flights, "");
		AddNewSubMenuItem(flightHashtable["Special Requests"].ToString(), "Special Requests", MenuKeyIndex.Flights, "");
		AddNewSubMenuItem(flightHashtable["Schedule Change Manager"].ToString(), "Schedule Change Manager", MenuKeyIndex.Flights, "");//Siddhi B(74)
		AddNewSubMenuItem(flightHashtable["Flight Schedule Utility"].ToString(), "Flight Schedule Utility", MenuKeyIndex.Flights, "");
		AddNewSubMenuItem(flightHashtable["Update FSDT Flight Booking Details"].ToString(), "Update FSDT Flight Booking Details", MenuKeyIndex.Flights, "");
		AddNewSubMenuItem(flightHashtable["Terms & Conditions"].ToString(), "Terms & Conditions", MenuKeyIndex.Flights, "..Pages/Product/TermsAndConditions.aspx"); //Wayne(26)
		AddNewSubMenuItem(flightHashtable["Special Requests"].ToString(), "Special Requests", MenuKeyIndex.Flights, "..Pages/Product/SpecialRequests.aspx"); //Wayne(23)
		AddNewSubMenuItem(flightHashtable["Flight Service Fees"].ToString(), "Flight Service Fees", MenuKeyIndex.Flights, "..Pages/Product/FlightServiceFees.aspx"); //Kalpi(41)
		AddNewSubMenuItem(flightHashtable["Fare Rules Configuration"].ToString(), "Fare Rules Configuration", MenuKeyIndex.Flights, "..Pages/Product/FareRulesConfiguration.aspx"); //Reema(47)
		AddNewSubMenuItem(flightHashtable["Markup Rule Priorities"].ToString(), "Markup Rule Priorities", MenuKeyIndex.Flights, "..Pages/Product/MarkUpRulePriorities.aspx"); //Reema(49)  Reema(53)
		AddNewSubMenuItem(flightHashtable["Fare Increase/Decrease Handling"].ToString(), "Fare Increase/Decrease Handling", MenuKeyIndex.Flights, "..Pages/Product/FareIncreaseDecreaseHandling.aspx"); //Sandip P.(50)
		AddNewSubMenuItem(flightHashtable["Agent Markup on Service Fee"].ToString(), "Agent Markup on Service Fee", MenuKeyIndex.Flights, "..Pages/Product/AgentMarkuponServiceFee.aspx"); //Ashley(55)
		AddNewSubMenuItem(flightHashtable["Agent Flights Commission"].ToString(), "Agent Flights Commission", MenuKeyIndex.Flights, "..Pages/Product/AgentFlightsCommission.aspx"); //Rejeena
		#endregion

		#region PROGRAMS SUB MENU
		//hashtable 
		Hashtable programHashtable = new Hashtable();
		programHashtable.Add("Calculator", "Calculator");
		programHashtable.Add("Notepad", "Notepad");
		programHashtable.Add("Task Manager", "Task Manager");
		programHashtable.Add("Word", "Word");
		programHashtable.Add("Excel", "Excel");
		programHashtable.Add("Internet Explorer", "Internet Explorer");

		//   programHashtable = Base.GetMultilingualMessageList("Menu", programHashtable);

		//Programs Menu
		AddNewSubMenuItem(programHashtable["Calculator"].ToString(), "", MenuKeyIndex.Programs, "");
		AddNewSubMenuItem(programHashtable["Notepad"].ToString(), "", MenuKeyIndex.Programs, "");
		AddNewSubMenuItem(programHashtable["Task Manager"].ToString(), "Task Manager", MenuKeyIndex.Programs, "");
		AddNewSubMenuItem(programHashtable["Word"].ToString(), "", MenuKeyIndex.Programs, "");
		AddNewSubMenuItem(programHashtable["Excel"].ToString(), "", MenuKeyIndex.Programs, "");
		AddNewSubMenuItem(programHashtable["Internet Explorer"].ToString(), "", MenuKeyIndex.Programs, "");
		#endregion

		#region REPORTS SUB MENU
		Hashtable reportHashtable = new Hashtable();
		reportHashtable.Add("Booking Report Screen", "Booking Report");
		reportHashtable.Add("Service Report Screen", "Service Report");
		reportHashtable.Add("Supplier Report Screen", "Supplier Report");
		reportHashtable.Add("Tariff Export Report Screen", "Tariff Report");
		reportHashtable.Add("Finance Report Screen", "Finance Report");
		reportHashtable.Add("Quote Reports Screen", "Quote Reports");
		reportHashtable.Add("Booking Notes Report Screen", "Booking Notes Report");
		reportHashtable.Add("Report Group", "Report Group");
		reportHashtable.Add("Report Registration", "Report Registration");
		reportHashtable.Add("Package Report Screen", "Package Report");
		reportHashtable.Add("Flight Report Screen", "Flight Report");
		reportHashtable.Add("Allocation Usage Graph Report Screen", "Allocation Usage Graph");
		reportHashtable.Add("AutoMessaging Failed Messages", "Failed Messages Report");
		reportHashtable.Add("Agent Report Options Screen", "Agent Report Options");
		reportHashtable.Add("Rail Report Screen", "Rail Report Options");
		reportHashtable.Add("Unsent Messages", "Unsent Messages");//Amrapali(73)
		//   reportHashtable = Base.GetMultilingualMessageList("Menu", reportHashtable);

		//Reports Menu
		AddNewSubMenuItem(reportHashtable["Booking Report Screen"].ToString(), "Booking Report Screen", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Service Report Screen"].ToString(), "Service Report Screen", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Supplier Report Screen"].ToString(), "Supplier Report Screen", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Tariff Export Report Screen"].ToString(), "Tariff Export Report Screen", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Finance Report Screen"].ToString(), "Finance Report Screen", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Quote Reports Screen"].ToString(), "Quote Reports Screen", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Booking Notes Report Screen"].ToString(), "Booking Notes Report Screen", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Report Group"].ToString(), "Report Group", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Report Registration"].ToString(), "Report Registration", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Package Report Screen"].ToString(), "Package Report Screen", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Flight Report Screen"].ToString(), "Flight Report Screen", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Allocation Usage Graph Report Screen"].ToString(), "Allocation Usage Graph Report Screen", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["AutoMessaging Failed Messages"].ToString(), "AutoMessaging Failed Messages", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Agent Report Options Screen"].ToString(), "", MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable["Rail Report Screen"].ToString(), "Rail Report Screen", MenuKeyIndex.Reports, "");


		#endregion

		#region ACCOUNTS SUB MENU
		Hashtable accountsHashtable = new Hashtable();
		accountsHashtable.Add("Export Financial Details", "Export Financial Details");
		accountsHashtable.Add("Batch Invoice Creation", "Batch Invoice Creation");
		accountsHashtable.Add("Purchase Invoice Creation", "Purchase Invoice Creation");
		accountsHashtable.Add("Purchase Invoice Import", "Purchase Invoice Import");//Anshul(77)
		accountsHashtable.Add("Reprint Invoices", "Reprint Invoices");
		accountsHashtable.Add("Batch Voucher Close", "Batch Voucher Close");
		accountsHashtable.Add("Exchange Rates", "Exchange Rate");
		accountsHashtable.Add("Batch Receipts Entry", "Batch Receipts Entry");//Amey.R(61) //Gautami(62)
		accountsHashtable.Add("Tax Codes", "Tax Codes");
		accountsHashtable.Add("Currency", "Currency");
		accountsHashtable.Add("Create GL Accounts", "Create GL Accounts");
		accountsHashtable.Add("Check Commission Payments", "Check Comm. Payment");
		accountsHashtable.Add("Access to Commission Margin Setup", "Commission Margin Setup");
		accountsHashtable.Add("TIC Insurance Export", "TIC Insurance Export");
		accountsHashtable.Add("Suppliers Invoice Submission", "Suppliers Invoice Submission");
		accountsHashtable.Add("Banked Receipts", "Banked Receipts");//Kedar(12) 
		accountsHashtable.Add("Bank Profiles", "Bank Profiles");//Sudeep(15)
		accountsHashtable.Add("Invoice Daily Exchange Rates", "Invoice Daily Exchange Rate");//Pranav(62)
		//  accountsHashtable = Base.GetMultilingualMessageList("Menu", accountsHashtable);

		//Accounts Menu
		AddNewSubMenuItem(accountsHashtable["Export Financial Details"].ToString(), "Export Financial Details", MenuKeyIndex.Accounts, "");
		AddNewSubMenuItem(accountsHashtable["Batch Invoice Creation"].ToString(), "Batch Invoice Creation,", MenuKeyIndex.Accounts, "../Pages/Finance/BatchInvoiceCreation.aspx");//Harshad(19)");
		//AddNewSubMenuItem(accountsHashtable["Purchase Invoice Creation"].ToString(), "Purchase Invoice Creation", MenuKeyIndex.Accounts, " ../Pages/Finance/PurchaseInvoiceCreation.aspx");//Harshad(24)"); //Bipul(79)
		AddNewSubMenuItem(accountsHashtable["Purchase Invoice Creation"].ToString(), "Purchase Invoice Creation", MenuKeyIndex.Accounts, " ../Pages/Finance/PurchaseInvoiceCreationNew.aspx");//Bipul(79)
		AddNewSubMenuItem(accountsHashtable["Purchase Invoice Import"].ToString(), "Purchase Invoice Import", MenuKeyIndex.Accounts, "../PurchaseInvoiceImport/PurchaseInvoice");//Anshul(77)
		AddNewSubMenuItem(accountsHashtable["Reprint Invoices"].ToString(), "Reprint Invoices", MenuKeyIndex.Accounts, "");
		AddNewSubMenuItem(accountsHashtable["Batch Voucher Close"].ToString(), "Batch Voucher Close", MenuKeyIndex.Accounts, "../Pages/Finance/BatchVoucherClose.aspx");//Ravish(27)
		AddNewSubMenuItem(accountsHashtable["Batch Voucher Close"].ToString(), "Batch Voucher Close", MenuKeyIndex.Accounts, "../BatchVoucherClose/BatchVoucherClose");//Ravish(27)//Sunil(80)
		AddNewSubMenuItem(accountsHashtable["Exchange Rates"].ToString(), "Exchange Rates", MenuKeyIndex.Accounts, "../Pages/Product/ExchangeRates.aspx");//Sarika(14)
		AddNewSubMenuItem(accountsHashtable["Batch Receipts Entry"].ToString(), "Batch Receipts Entry", MenuKeyIndex.Accounts, "../Pages/Finance/BatchReceiptsEntry.aspx");//Amey.R(61) //Gautami(62)
		AddNewSubMenuItem(accountsHashtable["Tax Codes"].ToString(), "Tax Codes", MenuKeyIndex.Accounts, "../Pages/Finance/TaxCodes.aspx");//Sarika(29)
		AddNewSubMenuItem(accountsHashtable["Currency"].ToString(), "Currency", MenuKeyIndex.Accounts, "../Pages/Product/Currencies.aspx"); //Virag
		AddNewSubMenuItem(accountsHashtable["Create GL Accounts"].ToString(), "Create GL Accounts", MenuKeyIndex.Accounts, "../Pages/Product/GLAccounts.aspx"); //Deepa(28)
		AddNewSubMenuItem(accountsHashtable["Check Commission Payments"].ToString(), "Check Commission Payments", MenuKeyIndex.Accounts, "../Pages/Finance/CheckCommissionPayments.aspx");  //SiddheshPrb(25)
		AddNewSubMenuItem(accountsHashtable["Access to Commission Margin Setup"].ToString(), "Access to Commission Margin Setup", MenuKeyIndex.Accounts, "");
		AddNewSubMenuItem(accountsHashtable["TIC Insurance Export"].ToString(), "TIC Insurance Export", MenuKeyIndex.Accounts, "");
		AddNewSubMenuItem(accountsHashtable["Suppliers Invoice Submission"].ToString(), "Suppliers Invoice Submission", MenuKeyIndex.Accounts, "");
		AddNewSubMenuItem(accountsHashtable["Banked Receipts"].ToString(), "Banked Receipts", MenuKeyIndex.Accounts, "../Pages/Finance/BankedReceipt.aspx"); //Kedar(12)
		AddNewSubMenuItem(accountsHashtable["Bank Profiles"].ToString(), "Bank Profiles", MenuKeyIndex.Accounts, "../Pages/Finance/BankProfiles.aspx"); //Sudeep(15)
		AddNewSubMenuItem(accountsHashtable["Invoice Daily Exchange Rates"].ToString(), "InvoiceDailyExchange Rates", MenuKeyIndex.Accounts, "../Pages/Product/InvoiceDailyExchangeRates.aspx");//Pranav(62)
		AddNewSubMenuItem(accountsHashtable["Receipts Reconciliation"].ToString(), "Receipts Reconciliation", MenuKeyIndex.Accounts, "../ReceiptsReconciliation/ReceiptsReconciliation");//Poonam(82)
		#endregion

		#region FULFILLMENT SUB MENU

		//hashtable for Fullfillment
		Hashtable fulfillmentHashtable = new Hashtable();
		fulfillmentHashtable.Add("Create Document Packages", "Create Document Pkgs");
		fulfillmentHashtable.Add("Print Document Packages", "Print Document Packages");
		fulfillmentHashtable.Add("MessageEditor", "Message Editor");
		fulfillmentHashtable.Add("Mail Shot", "Mail Shot");
		fulfillmentHashtable.Add("Batch Message Generation", "Batch Message Generation");
		fulfillmentHashtable.Add("Manual Manifest Generation", "Manual Manifest Generation");

		//  fulfillmentHashtable = Base.GetMultilingualMessageList("Menu", fulfillmentHashtable);

		//Fullfillment Menu(Marketing)
		AddNewSubMenuItem(fulfillmentHashtable["Create Document Packages"].ToString(), "Create Document Packages", MenuKeyIndex.Fulfillment, "");
		AddNewSubMenuItem(fulfillmentHashtable["Print Document Packages"].ToString(), "Print Document Packages", MenuKeyIndex.Fulfillment, "");
		AddNewSubMenuItem(fulfillmentHashtable["MessageEditor"].ToString(), "Message Editor", MenuKeyIndex.Fulfillment, "");
		AddNewSubMenuItem(fulfillmentHashtable["Mail Shot"].ToString(), "Mail Shot", MenuKeyIndex.Fulfillment, "");
		AddNewSubMenuItem(fulfillmentHashtable["Batch Message Generation"].ToString(), "Batch Message Generation", MenuKeyIndex.Fulfillment, "");
		AddNewSubMenuItem(fulfillmentHashtable["Manual Manifest Generation"].ToString(), "Manual Manifest Generation", MenuKeyIndex.Fulfillment, "");
		#endregion

		#region SETUP SUB MENU

		//Create Hashtable for setup
		Hashtable setupHashtable = new Hashtable();
		setupHashtable.Add("Server Setup", "Setup Server");
		setupHashtable.Add("Web Server Setup", "Setup Web Server");
		setupHashtable.Add("Setup Debug Mode", "Setup Debug Mode");

		//  setupHashtable = Base.GetMultilingualMessageList("Menu", setupHashtable);

		//Setup Menu
		//AddNewSubMenuItem(setupHashtable["Server Setup"].ToString(), "Server Setup", MenuKeyIndex.Setup, "");
		//AddNewSubMenuItem(setupHashtable["Web Server Setup"].ToString(), "Web Server Setup", MenuKeyIndex.Setup, "");
		//AddNewSubMenuItem(setupHashtable["Setup Debug Mode"].ToString(), "", MenuKeyIndex.Setup, "");
		#endregion

		#endregion Sub Menus
	}
	//BOC Prasad(05)
	protected void CreateMenuCollection1()
	{
		//WHEN UPDATING THE URLS ALSO REMEMBER TO UPDATE THE WEB.SITEMAP FILE

		#region MAIN MENU

		Hashtable objMenuHashtable = new Hashtable();
		objMenuHashtable.Add(MenuKeyIndex.System.ToString(), "System");
		objMenuHashtable.Add(MenuKeyIndex.Bookings.ToString(), "Booking");
		objMenuHashtable.Add(MenuKeyIndex.Quotes.ToString(), "Quotes");
		objMenuHashtable.Add(MenuKeyIndex.Package.ToString(), "Package");
		objMenuHashtable.Add(MenuKeyIndex.Clients.ToString(), "Clients");
		objMenuHashtable.Add(MenuKeyIndex.Products.ToString(), "Products");
		objMenuHashtable.Add(MenuKeyIndex.Flights.ToString(), "Flights");
		objMenuHashtable.Add(MenuKeyIndex.Programs.ToString(), "Programs");
		objMenuHashtable.Add(MenuKeyIndex.Reports.ToString(), "Reports");
		objMenuHashtable.Add(MenuKeyIndex.Accounts.ToString(), "Accounts");
		objMenuHashtable.Add(MenuKeyIndex.Fulfillment.ToString(), "Fulfillment");
		objMenuHashtable.Add(MenuKeyIndex.Setup.ToString(), "Setup");

		objMenuHashtable = Base.GetMultilingualMessageList("Menu", objMenuHashtable);

		AddNewMenuItem(objMenuHashtable[MenuKeyIndex.System.ToString()].ToString(), MenuKeyIndex.System.ToString(), "system");
		AddNewMenuItem(objMenuHashtable[MenuKeyIndex.Bookings.ToString()].ToString(), MenuKeyIndex.Bookings.ToString(), "booking");
		AddNewMenuItem(objMenuHashtable[MenuKeyIndex.Quotes.ToString()].ToString(), MenuKeyIndex.Quotes.ToString(), "quotes");
		AddNewMenuItem(objMenuHashtable[MenuKeyIndex.Package.ToString()].ToString(), MenuKeyIndex.Package.ToString(), "Package");
		AddNewMenuItem(objMenuHashtable[MenuKeyIndex.Clients.ToString()].ToString(), MenuKeyIndex.Clients.ToString(), "clients");
		AddNewMenuItem(objMenuHashtable[MenuKeyIndex.Products.ToString()].ToString(), MenuKeyIndex.Products.ToString(), "product");
		AddNewMenuItem(objMenuHashtable[MenuKeyIndex.Flights.ToString()].ToString(), MenuKeyIndex.Flights.ToString(), "Flight");
		AddNewMenuItem(objMenuHashtable[MenuKeyIndex.Programs.ToString()].ToString(), MenuKeyIndex.Programs.ToString(), "Programs");

		AddNewMenuItem(objMenuHashtable[MenuKeyIndex.Reports.ToString()].ToString(), MenuKeyIndex.Reports.ToString(), "Reports");//Prasad(05)
		AddNewMenuItem(objMenuHashtable[MenuKeyIndex.Accounts.ToString()].ToString(), MenuKeyIndex.Accounts.ToString(), "Accounts");
		AddNewMenuItem(objMenuHashtable[MenuKeyIndex.Fulfillment.ToString()].ToString(), MenuKeyIndex.Fulfillment.ToString(), "Fullfillments");
		AddNewMenuItem(objMenuHashtable[MenuKeyIndex.Setup.ToString()].ToString(), MenuKeyIndex.Setup.ToString(), "Setup");

		#endregion Top Visisble Menus Items

		#region SUB MENUS

		#region SYSTEM SUB MENU
		//System Menu
		//Hashtable for System menu
		Hashtable systemHashtable = new Hashtable();
		systemHashtable.Add(SubMenuKeySystem.GeoTree.ToString(), "Geo Tree");
		systemHashtable.Add(SubMenuKeySystem.Country.ToString(), "Country");
		systemHashtable.Add(SubMenuKeySystem.Statuses.ToString(), "Statuses");
		systemHashtable.Add(SubMenuKeySystem.Types.ToString(), "Types");
		systemHashtable.Add(SubMenuKeySystem.Charging_Duration.ToString(), "Charging Duration");
		systemHashtable.Add(SubMenuKeySystem.Charging_Policy.ToString(), "Charging Policy");
		systemHashtable.Add(SubMenuKeySystem.Image.ToString(), "Image");
		systemHashtable.Add(SubMenuKeySystem.Meal_Plan.ToString(), "Meal Plan");
		//  systemHashtable.Add(SubMenuKeySystem.Meal_Plan1.ToString(), "Meal Plan1");
		systemHashtable.Add(SubMenuKeySystem.Message_Editor.ToString(), "Message Editor");
		systemHashtable.Add(SubMenuKeySystem.Rules.ToString(), "Rules");
		systemHashtable.Add(SubMenuKeySystem.User_Manager.ToString(), "User Manager");
		systemHashtable.Add(SubMenuKeySystem.Organisation.ToString(), "Organisation");
		systemHashtable.Add(SubMenuKeySystem.Mileage_Map.ToString(), "Mileage Map");
		systemHashtable.Add(SubMenuKeySystem.Commission_Maintenance.ToString(), "Commission Maintenance");
		systemHashtable.Add(SubMenuKeySystem.Default_Booking_Tasks.ToString(), "Default Booking Task");
		systemHashtable.Add(SubMenuKeySystem.Messaging_Settings.ToString(), "Messaging Settings");
		systemHashtable.Add(SubMenuKeySystem.End_Point_Configuration.ToString(), "End Point Configuration");
		systemHashtable.Add(SubMenuKeySystem.Import_External_Services.ToString(), "Import External Services");
		systemHashtable.Add(SubMenuKeySystem.QA_Scripts.ToString(), "QA Scripts");
		systemHashtable.Add(SubMenuKeySystem.Reset_Cache.ToString(), "Reset Cache"); //Sarika(18)
		systemHashtable.Add(aboutTabString,aboutTabString); //Wayne(35) //Nasia(73)
		systemHashtable.Add(SubMenuKeySystem.Location.ToString(), "Location");  //Added by Sandip P.(42) 
		systemHashtable.Add(SubMenuKeySystem.Price_Update_Status.ToString(), "Price Update Status");  //Vikrant(59)
		systemHashtable.Add(SubMenuKeySystem.Task_Lists.ToString(), "Task Lists");//Debasis(62)
		systemHashtable.Add(SubMenuKeySystem.ChannelManagerConfiguration.ToString(), "Channel Manager Configuration");//candida (67)
		systemHashtable.Add(SubMenuKeySystem.RegisterWidgets.ToString(), "Register Widgets");//PNaik(xx)
		systemHashtable.Add(SubMenuKeySystem.Supplier_Extranet_Settings.ToString(), "Supplier Extranet Settings");//Clerance(76)
		systemHashtable.Add(SubMenuKeySystem.Areas.ToString(), "Areas"); //Vaishakhi(82)
		systemHashtable.Add(SubMenuKeySystem.Document_Template_Library.ToString(), "Document Template Library"); //Madhu(83)
		systemHashtable.Add(SubMenuKeySystem.Document_Component_Section_Library.ToString(), "Document Component Section Library"); //Rajesh(84)
		systemHashtable.Add(SubMenuKeySystem.PricingEstimationDefault.ToString(), "Pricing Estimation Default");
		systemHashtable.Add(SubMenuKeySystem.Queue_Status.ToString(), "Queue Status");//Wayne(82)
		//systemHashtable.Add("Geotree3", "Geotree - Asp controls");
		systemHashtable = Base.GetMultilingualMessageList("Menu", systemHashtable);

		//AddNewSubMenuItem(systemHashtable["GeoTree"].ToString(), "GeoTree", MenuKeyIndex.System, "../Pages/System/GeoTree.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.GeoTree.ToString()].ToString(), SubMenuKeySystem.GeoTree.ToString(), MenuKeyIndex.System, "../Pages/System/GeoTree.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Country.ToString()].ToString(), SubMenuKeySystem.Country.ToString(), MenuKeyIndex.System, "../Pages/System/Country.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Statuses.ToString()].ToString(), SubMenuKeySystem.Statuses.ToString(), MenuKeyIndex.System, "../Pages/Product/Status.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Types.ToString()].ToString(), SubMenuKeySystem.Types.ToString(), MenuKeyIndex.System, "../Pages/Product/Types.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Charging_Duration.ToString()].ToString(), SubMenuKeySystem.Charging_Duration.ToString(), MenuKeyIndex.System, "../Pages/Product/ChargingDuration.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Charging_Policy.ToString()].ToString(), SubMenuKeySystem.Charging_Policy.ToString(), MenuKeyIndex.System, "../Pages/Product/ChargingPolicy.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Image.ToString()].ToString(), SubMenuKeySystem.Image.ToString(), MenuKeyIndex.System, "../Pages/Product/ImageSearch.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Meal_Plan.ToString()].ToString(), SubMenuKeySystem.Meal_Plan.ToString(), MenuKeyIndex.System, "../Pages/Product/MealPlan.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Message_Editor.ToString()].ToString(), SubMenuKeySystem.Message_Editor.ToString(), MenuKeyIndex.System, "");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Rules.ToString()].ToString(), SubMenuKeySystem.Rules.ToString(), MenuKeyIndex.System, "../Pages/Product/Rules.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.User_Manager.ToString()].ToString(), SubMenuKeySystem.User_Manager.ToString(), MenuKeyIndex.System, "../Pages/System/UserManager.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Organisation.ToString()].ToString(), SubMenuKeySystem.Organisation.ToString(), MenuKeyIndex.System, "../Pages/Organisation/Organisation.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Mileage_Map.ToString()].ToString(), SubMenuKeySystem.Mileage_Map.ToString(), MenuKeyIndex.System, "../Pages/System/MileageMap.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Commission_Maintenance.ToString()].ToString(), SubMenuKeySystem.Commission_Maintenance.ToString(), MenuKeyIndex.System, "../Pages/Product/CommisionScheme.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Default_Booking_Tasks.ToString()].ToString(), SubMenuKeySystem.Default_Booking_Tasks.ToString(), MenuKeyIndex.System, "");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Messaging_Settings.ToString()].ToString(), SubMenuKeySystem.Auto_Messaging.ToString(), MenuKeyIndex.System, "../Pages/Messaging/TSWeb.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.End_Point_Configuration.ToString()].ToString(), SubMenuKeySystem.End_Point_Configuration.ToString(), MenuKeyIndex.System, "");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Import_External_Services.ToString()].ToString(), SubMenuKeySystem.Import_External_Services.ToString(), MenuKeyIndex.System, "");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.QA_Scripts.ToString()].ToString(), SubMenuKeySystem.QA_Scripts.ToString(), MenuKeyIndex.System, "../Pages/System/QAScripts.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Reset_Cache.ToString()].ToString(), SubMenuKeySystem.Reset_Cache.ToString(), MenuKeyIndex.System, "~/Home.aspx?ResetSystemCache=true"); //Sarika(18)
		AddNewSubMenuItem(aboutTabString, aboutTabString, MenuKeyIndex.System, "../Pages/System/About.aspx");//Nasia(73)
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Location.ToString()].ToString(), SubMenuKeySystem.Location.ToString(), MenuKeyIndex.System, "../Pages/System/Location.aspx"); //Sandip P.(42)
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Price_Update_Status.ToString()].ToString(), SubMenuKeySystem.Price_Update_Status.ToString(), MenuKeyIndex.System, "../Pages/System/PriceUpdateStatus.aspx"); //Vikrant(59)
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Task_Lists.ToString()].ToString(), SubMenuKeySystem.Task_Lists.ToString(), MenuKeyIndex.System, "../DefaultTasks/DefaultTasks");//Debasis(62)
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.ChannelManagerConfiguration.ToString()].ToString(), SubMenuKeySystem.ChannelManagerConfiguration.ToString(), MenuKeyIndex.System, "../Pages/System/ChannelManagerConfiguration.aspx");//candida (67)
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.RegisterWidgets.ToString()].ToString(), SubMenuKeySystem.RegisterWidgets.ToString(), MenuKeyIndex.System, "RegisterWidget/RegisterWidgets");//candida (67)
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Supplier_Extranet_Settings.ToString()].ToString(), SubMenuKeySystem.Supplier_Extranet_Settings.ToString(), MenuKeyIndex.System, "../Pages/System/SupplierExtranetSettings.aspx");//Clerance (76)
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Areas.ToString()].ToString(), SubMenuKeySystem.Areas.ToString(), MenuKeyIndex.System, "../Areas/Areas");//Vaishaki
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Document_Template_Library.ToString()].ToString(), SubMenuKeySystem.Document_Template_Library.ToString(), MenuKeyIndex.System, "../TemplateBuilder/TemplateBuilder");//Madhu(83)
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Document_Component_Section_Library.ToString()].ToString(), SubMenuKeySystem.Document_Component_Section_Library.ToString(), MenuKeyIndex.System, "DocumentSectionBuilder/DocumentSectionBuilder");//Rajesh(84)
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Queue_Status.ToString()].ToString(), SubMenuKeySystem.Queue_Status.ToString(), MenuKeyIndex.System, "QueueStatus/QueueStatus"); //Wayne(82)
		//AddNewSubMenuItem(systemHashtable["Geotree3"].ToString(), "GeoTree", MenuKeyIndex.System, "../Pages/System/GeoTreeWithOutSyncTab.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.PricingEstimationDefault.ToString()].ToString(), SubMenuKeySystem.PricingEstimationDefault.ToString(), MenuKeyIndex.System, "PricingEstimationDefault/PricingEstimationDefault");

		#endregion  

		#region BOOKING SUB MENU

		//Hash Table for Booking Sub Menu
		Hashtable bookingHashTable = new Hashtable();
		bookingHashTable.Add(SubMenuKeyBookings.New_Booking.ToString(), "New Booking");
		bookingHashTable.Add(SubMenuKeyBookings.Booking_Find.ToString(), "Booking Search");
		bookingHashTable.Add(SubMenuKeyBookings.Replicate_Bookings.ToString(), "Replicate Bookings");
		bookingHashTable.Add(SubMenuKeyBookings.Package_Search.ToString(), "Package Search");
		bookingHashTable.Add(SubMenuKeyBookings.Passenger_Maint.ToString(), "Passenger Maintenance");
		bookingHashTable.Add(SubMenuKeyBookings.Commission_Payment_Approval.ToString(), "Comm. Payment Appr.");
		bookingHashTable.Add(SubMenuKeyBookings.PNR_Shadow_List.ToString(), "PNR Shadow List");
		bookingHashTable.Add(SubMenuKeyBookings.Expired_Options.ToString(), "Expired Options");
		bookingHashTable.Add(SubMenuKeyBookings.Villa_Booking.ToString(), "Villa Search");
		bookingHashTable.Add(SubMenuKeyBookings.Service_Search.ToString(), "Service Search");
		bookingHashTable.Add(SubMenuKeyBookings.Booking_Import.ToString(), "Booking Import");
		bookingHashTable.Add(SubMenuKeyBookings.Rail_Search.ToString(), "Rail Search");
		bookingHashTable.Add(SubMenuKeyBookings.NCOA_Address_Export.ToString(), "NCOA Address Export");
		bookingHashTable.Add(SubMenuKeyBookings.Bulk_Service_Replacement.ToString(), "Bulk Service Replacement");
		bookingHashTable.Add(SubMenuKeyBookings.Booked_Service_Search.ToString(), "Booked Service Search");
		bookingHashTable.Add(SubMenuKeyBookings.Batch_Status_Update.ToString(), "Batch Status Update");
		bookingHashTable.Add(SubMenuKeyBookings.Flight_Search.ToString(), "Search / Book Flight.");
		bookingHashTable.Add(SubMenuKeyBookings.Task_Manager.ToString(), "Task Manager"); //Abhijit L.(33)
		bookingHashTable.Add(SubMenuKeyBookings.Book_Promotional_Package.ToString(), "Book Promotional Package"); //Harshad(54)
		bookingHashTable.Add(SubMenuKeyBookings.New_Enquiry.ToString(), "New Enquiry");        //kartheek(58)
		bookingHashTable.Add(SubMenuKeyBookings.Enquiry_Search.ToString(), "Enquiry Search");  //kartheek(58)
		bookingHashTable.Add(SubMenuKeyBookings.Purchase_Space_Management.ToString(), "Purchase Space Management"); //Ravish(51)
		bookingHashTable.Add(SubMenuKeyBookings.Flight_Hotel_Search.ToString(), "Flight & Hotel Search");  //Harshad(60)
		bookingHashTable.Add(SubMenuKeyBookings.Dynamic_Package_Search.ToString(), "Dynamic Package Search");  //Harshad(75)
		bookingHashTable.Add(SubMenuKeyBookings.Generate_Xml.ToString(), "Generate XMLs");  //Shradha(67)
		bookingHashTable.Add(SubMenuKeyBookings.Operations_Module.ToString(), "Operations Module"); //Dejalin(65)        
		bookingHashTable.Add(SubMenuKeyBookings.Batch_Booking_Task_Generation.ToString(), "Batch Booking Task Generation");     //Purva(73)
		bookingHashTable.Add(SubMenuKeyBookings.Rail_CheckIn.ToString(), "Rail Check-In");//Tejas(74)
		bookingHashTable.Add(SubMenuKeyBookings.Expiring_Options.ToString(), "Expiring Options");//Omkar N.(80)
		bookingHashTable.Add(SubMenuKeyBookings.Batch_Message_Generation.ToString(), "Batch Message Generation");  //Priya
		bookingHashTable = Base.GetMultilingualMessageList("Menu", bookingHashTable);

		//Booking Menu
		//BOC Prasad(05)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.New_Booking.ToString()].ToString(), SubMenuKeyBookings.New_Booking.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/NewBooking.aspx");
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Booking_Find.ToString()].ToString(), SubMenuKeyBookings.Booking_Find.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/BookingSearchResults.aspx");
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Replicate_Bookings.ToString()].ToString(), SubMenuKeyBookings.Replicate_Bookings.ToString(), MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Package_Search.ToString()].ToString(), SubMenuKeyBookings.Package_Search.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/BookingPackageSearch.aspx");
		//BOC Vismita(86)
		if (IsOldPackageSearchUI())
		{
			AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Package_Search.ToString()].ToString(), SubMenuKeyBookings.Package_Search.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/BookingPackageSearch.aspx"); 
		}
		else
		{
			AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Package_Search.ToString()].ToString(), SubMenuKeyBookings.Package_Search.ToString(), MenuKeyIndex.Bookings, "PackageSearch/PackageSearchContainer");
		}
		//EOC Vismita(86)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Passenger_Maint.ToString()].ToString(), SubMenuKeyBookings.Passenger_Maint.ToString(), MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Commission_Payment_Approval.ToString()].ToString(), "Commission Payment Approval", MenuKeyIndex.Bookings, "../Pages/Booking/CommissionPaymentsApproval.aspx"); //SiddheshPrb(25)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.PNR_Shadow_List.ToString()].ToString(), SubMenuKeyBookings.PNR_Shadow_List.ToString(), MenuKeyIndex.Bookings, "");
		//  AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Change_Booking_Expiry_Date.ToString()].ToString(), "Change Booking Expiry Date", MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Villa_Booking.ToString()].ToString(), SubMenuKeyBookings.Villa_Booking.ToString(), MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Service_Search.ToString()].ToString(), SubMenuKeyBookings.Service_Search.ToString(), MenuKeyIndex.Bookings, "../Pages/ServiceSearch/TSServiceSearch.aspx");   //Jayesh(37)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Booking_Import.ToString()].ToString(), SubMenuKeyBookings.Booking_Import.ToString(), MenuKeyIndex.Bookings, "");
		//Check for display rail flag from organization settings to enable below menu for Rail
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Rail_Search.ToString()].ToString(), SubMenuKeyBookings.Rail_Search.ToString(), MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.NCOA_Address_Export.ToString()].ToString(), SubMenuKeyBookings.NCOA_Address_Export.ToString(), MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Bulk_Service_Replacement.ToString()].ToString(), SubMenuKeyBookings.Bulk_Service_Replacement.ToString(), MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Booked_Service_Search.ToString()].ToString(), SubMenuKeyBookings.Booked_Service_Search.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/BookedServiceSearch.aspx");
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Batch_Status_Update.ToString()].ToString(), SubMenuKeyBookings.Batch_Status_Update.ToString(), MenuKeyIndex.Bookings, "");
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Flight_Search.ToString()].ToString(), SubMenuKeyBookings.Flight_Search.ToString(), MenuKeyIndex.Bookings, "");
		//EOC Prasad(05)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Task_Manager.ToString()].ToString(), SubMenuKeyBookings.Task_Manager.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/TaskManager.aspx"); //Abhijit L.(33)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Flight_Search.ToString()].ToString(), SubMenuKeyBookings.Flight_Search.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/FlightSearch.aspx");//Ravish(43)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Book_Promotional_Package.ToString()].ToString(), SubMenuKeyBookings.Book_Promotional_Package.ToString(), MenuKeyIndex.Bookings, "../Pages/Packages/PromotionalPackageSearch.aspx");//Harshad(54)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.New_Enquiry.ToString()].ToString(), SubMenuKeyBookings.New_Enquiry.ToString(), MenuKeyIndex.Bookings, "ItineraryBuilder/ItineraryBuilder");              //kartheek(58) //Savira(81)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Enquiry_Search.ToString()].ToString(), SubMenuKeyBookings.Enquiry_Search.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/EnquirySearch.aspx");  //kartheek(58)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Purchase_Space_Management.ToString()].ToString(), SubMenuKeyBookings.Purchase_Space_Management.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/PurchaseSpaceManagement.aspx");//Ravish(51)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Flight_Hotel_Search.ToString()].ToString(), SubMenuKeyBookings.Flight_Hotel_Search.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/FlightHotelSearch.aspx");  //Harshad(60)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Generate_Xml.ToString()].ToString(), SubMenuKeyBookings.Generate_Xml.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/GenerateXml.aspx");  //Shradha(67)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Operations_Module.ToString()].ToString(), SubMenuKeyBookings.Operations_Module.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/OperationsModule.aspx"); //Dejalin(65)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Rail_CheckIn.ToString()].ToString(), SubMenuKeyBookings.Rail_CheckIn.ToString(), MenuKeyIndex.Bookings, "/RailCheckIn/RailCheckIn");//Tejas(74)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Dynamic_Package_Search.ToString()].ToString(), SubMenuKeyBookings.Dynamic_Package_Search.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/DynamicPackageSearch.aspx");  //Harshad(75)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Expiring_Options.ToString()].ToString(), SubMenuKeyBookings.Expiring_Options.ToString(), MenuKeyIndex.Bookings, "ExpiringOptions/ExpiringOptionsContainer");  //Omkar N.(80)
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Batch_Message_Generation.ToString()].ToString(), SubMenuKeyBookings.Batch_Message_Generation.ToString(), MenuKeyIndex.Bookings, "../Messages/BatchMessageGeneration");//Priya  
		AddNewSubMenuItem(bookingHashTable[SubMenuKeyBookings.Batch_Booking_Task_Generation.ToString()].ToString(), SubMenuKeyBookings.Batch_Booking_Task_Generation.ToString(), MenuKeyIndex.Bookings, "../Pages/Booking/BatchBookingTaskGeneration.aspx");      //Purva(73)
		#endregion

		#region QUOTES SUB MENU

		//Hashtable for Quote menu
		Hashtable quoteHashtable = new Hashtable();
		quoteHashtable.Add(SubMenuKeyQuotes.New_Quote.ToString(), "New Quote");
		quoteHashtable.Add(SubMenuKeyQuotes.Quote_Search.ToString(), "Quote Search");
		quoteHashtable.Add(SubMenuKeyQuotes.Quote_Default.ToString(), "Quote Default");

		quoteHashtable = Base.GetMultilingualMessageList("Menu", quoteHashtable);

		//Quote Menu
		AddNewSubMenuItem(quoteHashtable[SubMenuKeyQuotes.New_Quote.ToString()].ToString(), SubMenuKeyQuotes.New_Quote.ToString(), MenuKeyIndex.Quotes, "");
		AddNewSubMenuItem(quoteHashtable[SubMenuKeyQuotes.Quote_Search.ToString()].ToString(), SubMenuKeyQuotes.Quote_Search.ToString(), MenuKeyIndex.Quotes, "");
		AddNewSubMenuItem(quoteHashtable[SubMenuKeyQuotes.Quote_Default.ToString()].ToString(), SubMenuKeyQuotes.Quote_Default.ToString(), MenuKeyIndex.Quotes, "");

		#endregion

		#region PACKAGE SUB MENU

		//Package Hashtable
		Hashtable packageHashtable = new Hashtable();
		packageHashtable.Add(SubMenuKeyPackage.New_Package.ToString(), "New Package");
		packageHashtable.Add(SubMenuKeyPackage.Package_Find.ToString(), "Package Find");
		packageHashtable.Add(SubMenuKeyPackage.Package_Maintenance.ToString(), "Departure Maintenance");
		packageHashtable.Add(SubMenuKeyPackage.Package_Data.ToString(), "Package Data");
		packageHashtable.Add(SubMenuKeyPackage.Package_Brochure.ToString(), "Package Brochure");
		packageHashtable.Add(SubMenuKeyPackage.Waitlist_Maintenance.ToString(), "Waitlist Maintenance");
		packageHashtable.Add(SubMenuKeyPackage.Batch_Package_Sell_Price_Creation.ToString(), "Batch Pkg Sell Price Creation");
		packageHashtable.Add(SubMenuKeyPackage.Package_Facilities.ToString(), "Package Facilities");
		packageHashtable.Add(SubMenuKeyPackage.Pattern_Splitting_Wizard.ToString(), "Pattern Splitting Wizard");
		packageHashtable.Add(SubMenuKeyPackage.Batch_Service_Details_Update.ToString(), "Batch Service Details Update");
		//Check for  if edit right of package for below menu
		packageHashtable.Add(SubMenuKeyPackage.Update_Departure_Cost.ToString(), "Update Departure Cost");
		packageHashtable.Add(SubMenuKeyPackage.Package_Inventory.ToString(), "Package Inventory");
		packageHashtable.Add(SubMenuKeyPackage.Departure_Find.ToString(), "Departure Find");
		packageHashtable = Base.GetMultilingualMessageList("Menu", packageHashtable);

		//Package Menu
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.New_Package.ToString()].ToString(), SubMenuKeyPackage.New_Package.ToString(), MenuKeyIndex.Package, "PackageBuilder/NewPackageRedirection");  //Wayne(45)
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.Departure_Find.ToString()].ToString(), SubMenuKeyPackage.Departure_Find.ToString(), MenuKeyIndex.Package, "DepartureFind/DepartureFindContainer");
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.Package_Find.ToString()].ToString(), SubMenuKeyPackage.Package_Find.ToString(), MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.Package_Maintenance.ToString()].ToString(), SubMenuKeyPackage.Package_Maintenance.ToString(), MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.Package_Data.ToString()].ToString(), SubMenuKeyPackage.Package_Data.ToString(), MenuKeyIndex.Package, "../Pages/Packages/PackageData.aspx"); //Vrundavani(59)
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.Package_Brochure.ToString()].ToString(), SubMenuKeyPackage.Package_Brochure.ToString(), MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.Waitlist_Maintenance.ToString()].ToString(), SubMenuKeyPackage.Waitlist_Maintenance.ToString(), MenuKeyIndex.Package, "../Pages/Packages/WaitlistMaintenance.aspx");//Shruti(63)
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.Batch_Package_Sell_Price_Creation.ToString()].ToString(), SubMenuKeyPackage.Batch_Package_Sell_Price_Creation.ToString(), MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.Package_Facilities.ToString()].ToString(), SubMenuKeyPackage.Package_Facilities.ToString(), MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.Pattern_Splitting_Wizard.ToString()].ToString(), SubMenuKeyPackage.Pattern_Splitting_Wizard.ToString(), MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.Batch_Service_Details_Update.ToString()].ToString(), SubMenuKeyPackage.Batch_Service_Details_Update.ToString(), MenuKeyIndex.Package, "");
		//Check for  if edit right of package for below menu
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.Update_Departure_Cost.ToString()].ToString(), SubMenuKeyPackage.New_Package.ToString(), MenuKeyIndex.Package, "");
		AddNewSubMenuItem(packageHashtable[SubMenuKeyPackage.Package_Inventory.ToString()].ToString(), SubMenuKeyPackage.Package_Inventory.ToString(), MenuKeyIndex.Package, "");
		#endregion

		#region CLIENTS SUB MENU


		Hashtable clientsHashtable = new Hashtable();
		clientsHashtable.Add(SubMenuKeyClients.Agent.ToString(), "Agent");
		clientsHashtable.Add(SubMenuKeyClients.Agent_Group.ToString(), "Agent Group");
		clientsHashtable.Add(SubMenuKeyClients.Agent_Group_Commission_Update.ToString(), "Agent Group Commission Update");
		clientsHashtable.Add(SubMenuKeyClients.Agent_Import.ToString(), "Agents Import");
		clientsHashtable.Add(SubMenuKeyClients.New_Client_Credit.ToString(), "New Client Credit");
		clientsHashtable.Add(SubMenuKeyClients.Search_Client_Credit.ToString(), "Search Client Credit");
		clientsHashtable.Add(SubMenuKeyClients.Default_Price_Type.ToString(), "Price Type Default");
		clientsHashtable.Add(SubMenuKeyClients.Merge_Passenger_Bookings.ToString(), "Merge Passenger Bookings");
		clientsHashtable.Add(SubMenuKeyClients.Passenger.ToString(), "Passenger Maintenance");
		clientsHashtable.Add(SubMenuKeyClients.Marketing_Survey_Import.ToString(), "Marketing Survey Import");
		clientsHashtable.Add(SubMenuKeyClients.Passenger_Maintenance.ToString(), "Passenger Maintenance");
		clientsHashtable.Add(SubMenuKeyClients.Agent_Portal.ToString(), "Agent Portal Settings"); //Deepa(16)

		clientsHashtable = Base.GetMultilingualMessageList("Menu", clientsHashtable);

		//Clients Menu
		AddNewSubMenuItem(clientsHashtable[SubMenuKeyClients.Agent.ToString()].ToString(), SubMenuKeyClients.Agent.ToString(), MenuKeyIndex.Clients, "../Pages/Client/AgentSearch.aspx");
		AddNewSubMenuItem(clientsHashtable[SubMenuKeyClients.Agent_Group.ToString()].ToString(), SubMenuKeyClients.Agent_Group.ToString(), MenuKeyIndex.Clients, "../Pages/Client/AgentGroup.aspx");
		if (GetAgentGroupCommissionFlag())
			AddNewSubMenuItem(clientsHashtable[SubMenuKeyClients.Agent_Group_Commission_Update.ToString()].ToString(), SubMenuKeyClients.Agent_Group_Commission_Update.ToString(), MenuKeyIndex.Clients, "../Pages/Client/AgentGroupCommission.aspx");
		AddNewSubMenuItem(clientsHashtable[SubMenuKeyClients.Agent_Import.ToString()].ToString(), SubMenuKeyClients.Agent_Import.ToString(), MenuKeyIndex.Clients, "");
		AddNewSubMenuItem(clientsHashtable[SubMenuKeyClients.New_Client_Credit.ToString()].ToString(), SubMenuKeyClients.Agent_Import.ToString(), MenuKeyIndex.Clients, "../Pages/Client/NewClientCredit.aspx");
		AddNewSubMenuItem(clientsHashtable[SubMenuKeyClients.Search_Client_Credit.ToString()].ToString(), SubMenuKeyClients.Search_Client_Credit.ToString(), MenuKeyIndex.Clients, "../Pages/Client/SearchClientCredit.aspx");
		AddNewSubMenuItem(clientsHashtable[SubMenuKeyClients.Default_Price_Type.ToString()].ToString(), SubMenuKeyClients.Default_Price_Type.ToString(), MenuKeyIndex.Clients, "../Pages/Client/PriceTypeDefault.aspx");
		AddNewSubMenuItem(clientsHashtable[SubMenuKeyClients.Merge_Passenger_Bookings.ToString()].ToString(), SubMenuKeyClients.Merge_Passenger_Bookings.ToString(), MenuKeyIndex.Clients, "");
		AddNewSubMenuItem(clientsHashtable[SubMenuKeyClients.Passenger.ToString()].ToString(), SubMenuKeyClients.Passenger.ToString(), MenuKeyIndex.Clients, "../Pages/Client/PassengerSearch.aspx");
		AddNewSubMenuItem(clientsHashtable[SubMenuKeyClients.Marketing_Survey_Import.ToString()].ToString(), SubMenuKeyClients.Marketing_Survey_Import.ToString(), MenuKeyIndex.Clients, "");
		AddNewSubMenuItem(clientsHashtable[SubMenuKeyClients.Agent_Portal.ToString()].ToString(), SubMenuKeyClients.Agent_Portal.ToString(), MenuKeyIndex.Clients, "../Pages/Client/AgentPortalSettings.aspx");//Deepa(16)

		#endregion

		#region PRODUCTS SUB MENU

		Hashtable productsHashtable = new Hashtable();
		productsHashtable.Add(SubMenuKeyProduct.Supplier.ToString(), "Supplier");
		productsHashtable.Add(SubMenuKeyProduct.Service.ToString(), "Service");
		productsHashtable.Add(SubMenuKeyProduct.Contract.ToString(), "Contract");
		productsHashtable.Add(SubMenuKeyProduct.Villa_Group.ToString(), "Villa Group");
		productsHashtable.Add(SubMenuKeyProduct.Option.ToString(), "Option");
		productsHashtable.Add(SubMenuKeyProduct.Extra.ToString(), "Extra");
		productsHashtable.Add(SubMenuKeyProduct.Facilities.ToString(), "Facilities");
		productsHashtable.Add(SubMenuKeyProduct.Rating.ToString(), "Rating");
		productsHashtable.Add(SubMenuKeyProduct.Child_Policy.ToString(), "Child Policy");
		productsHashtable.Add(SubMenuKeyProduct.Supplier_Group.ToString(), "Supplier Group");
		productsHashtable.Add(SubMenuKeyProduct.Batch_Selling_Price_Creation.ToString(), "Batch Service Sell Price Generator");//Ravish(74)
		productsHashtable.Add(SubMenuKeyProduct.Batch_Price_Type_Associator.ToString(), "Batch Price Type Associator");
		productsHashtable.Add(SubMenuKeyProduct.Batch_Rule_Generation.ToString(), "Batch Rule Generator");
		//Check for display rail flag from organization settings to enable below menu for Rail
		productsHashtable.Add(SubMenuKeyProduct.Rail_Manager.ToString(), "Rail Manager");
		productsHashtable.Add(SubMenuKeyProduct.Allocation_Name.ToString(), "Allocation Name");
		productsHashtable.Add(SubMenuKeyProduct.Web_Passenger_Questions.ToString(), "Web Passenger Questions");
		productsHashtable.Add(SubMenuKeyProduct.Service_Type_Questions.ToString(), "Service Type Questions");
		productsHashtable.Add(SubMenuKeyProduct.Cancellation_Policies.ToString(), "Cancellation Policies");
		productsHashtable.Add(SubMenuKeyProduct.Service_Pricing.ToString(), "Service Pricing");
		//productsHashtable.Add(SubMenuKeyProduct.Access_to_Mandatory_Services.ToString(), "Mandatory/Discount Services");//Vimlesh(59)
		productsHashtable.Add(SubMenuKeyProduct.Mandatory_Services_Access.ToString(), "Mandatory Services");//Vimlesh(59)	//Nikita()
		//productsHashtable.Add(SubMenuKeyProduct.Service_Export_Import.ToString(), "Service Export Import");//Pradnya(60)Commented
		productsHashtable.Add(SubMenuKeyProduct.Villa_Room_Name.ToString(), "Villa Room Name");
		productsHashtable.Add(SubMenuKeyProduct.Update_Booking_Costs.ToString(), "Update Booking Costs");
		productsHashtable.Add(SubMenuKeyProduct.Supplier_Extranet_Messages.ToString(), "Supplier Extranet Messages");
		productsHashtable.Add(SubMenuKeyProduct.Yield_Rule_Setup.ToString(), "Yield Rule Setup");
		productsHashtable.Add(SubMenuKeyProduct.Query_Tool.ToString(), "Query Tool");
		productsHashtable.Add(SubMenuKeyProduct.Instalment_Discounts.ToString(), "Instalment Discounts");//Shivanand(11)
		productsHashtable.Add(SubMenuKeyProduct.Batch_Instalment_Generator.ToString(), "Batch Instalment Generator");//Shivanand(11)
		productsHashtable.Add(SubMenuKeyProduct.Availability_Updater.ToString(), "Availability Updater"); //Kedar(22)
		productsHashtable.Add(SubMenuKeyProduct.Supplier_Servcie_Document.ToString(), "Supplier Service Document");//Vikrant(58)
		productsHashtable.Add(SubMenuKeyProduct.Bulk_Contract_Maintenance.ToString(), "Bulk Contract Maintenance"); //Clerance(53)
		productsHashtable.Add(SubMenuKeyProduct.Bulk_Contract_Maintenance_History.ToString(), "Bulk Contract Maintenance History"); //Clerance(53)
		productsHashtable.Add(SubMenuKeyProduct.Offline_Price_Editor.ToString(), "Offline Price Editor"); //Sujata(54)
		productsHashtable.Add(SubMenuKeyProduct.Discount.ToString(), "Discount"); //Omkar N.(81)
		productsHashtable = Base.GetMultilingualMessageList("Menu", productsHashtable);

		//Products Menu
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Supplier.ToString()].ToString(), SubMenuKeyProduct.Supplier.ToString(), MenuKeyIndex.Products, "../Pages/Client/SupplierSearch.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Service.ToString()].ToString(), SubMenuKeyProduct.Service.ToString(), MenuKeyIndex.Products, "../Pages/Services/ServiceSearch.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Contract.ToString()].ToString(), SubMenuKeyProduct.Contract.ToString(), MenuKeyIndex.Products, "../Pages/Product/Contracts.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Villa_Group.ToString()].ToString(), SubMenuKeyProduct.Villa_Group.ToString(), MenuKeyIndex.Products, "../Pages/Product/VillaGroup.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Option.ToString()].ToString(), SubMenuKeyProduct.Option.ToString(), MenuKeyIndex.Products, "../Pages/Product/Option.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Extra.ToString()].ToString(), SubMenuKeyProduct.Extra.ToString(), MenuKeyIndex.Products, "../Pages/Product/Extra.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Facilities.ToString()].ToString(), SubMenuKeyProduct.Facilities.ToString(), MenuKeyIndex.Products, "../Pages/Product/Facilities.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Rating.ToString()].ToString(), SubMenuKeyProduct.Rating.ToString(), MenuKeyIndex.Products, "../Pages/Product/Ratings.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Child_Policy.ToString()].ToString(), SubMenuKeyProduct.Child_Policy.ToString(), MenuKeyIndex.Products, "../Pages/Product/ChildPolicy.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Supplier_Group.ToString()].ToString(), SubMenuKeyProduct.Supplier_Group.ToString(), MenuKeyIndex.Products, "../Pages/Product/SupplierGroups.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Batch_Selling_Price_Creation.ToString()].ToString(), SubMenuKeyProduct.Batch_Selling_Price_Creation.ToString(), MenuKeyIndex.Products, "../Pages/Product/BatchSellingPriceGenerator.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Batch_Price_Type_Associator.ToString()].ToString(), SubMenuKeyProduct.Batch_Price_Type_Associator.ToString(), MenuKeyIndex.Products, "");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Batch_Rule_Generation.ToString()].ToString(), SubMenuKeyProduct.Batch_Rule_Generation.ToString(), MenuKeyIndex.Products, "../Pages/Product/BatchRuleGenerator.aspx");
		//Check for display rail flag from organization settings to enable below menu for Rail
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Rail_Manager.ToString()].ToString(), SubMenuKeyProduct.Rail_Manager.ToString(), MenuKeyIndex.Products, "RailManager/LoadRailManager");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Allocation_Name.ToString()].ToString(), SubMenuKeyProduct.Allocation_Name.ToString(), MenuKeyIndex.Products, "../Pages/Product/AllocationName.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Web_Passenger_Questions.ToString()].ToString(), SubMenuKeyProduct.Web_Passenger_Questions.ToString(), MenuKeyIndex.Products, "../Pages/Product/WebPassengerQuestions.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Service_Type_Questions.ToString()].ToString(), SubMenuKeyProduct.Service_Type_Questions.ToString(), MenuKeyIndex.Products, "../Pages/Product/ServiceTypeQuestions.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Cancellation_Policies.ToString()].ToString(), SubMenuKeyProduct.Cancellation_Policies.ToString(), MenuKeyIndex.Products, "../Pages/Product/CancellationPolicy.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Service_Pricing.ToString()].ToString(), SubMenuKeyProduct.Service_Pricing.ToString(), MenuKeyIndex.Products, "");
		//AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Access_to_Mandatory_Services.ToString()].ToString(), SubMenuKeyProduct.Access_to_Mandatory_Services.ToString(), MenuKeyIndex.Products, "");//Vimlesh(59)
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Mandatory_Services_Access.ToString()].ToString(), SubMenuKeyProduct.Mandatory_Services_Access.ToString(), MenuKeyIndex.Products, "../Pages/Product/MandatoryServices.aspx");//Vimlesh(59)
		//AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Service_Export_Import.ToString()].ToString(), SubMenuKeyProduct.Service_Export_Import.ToString(), MenuKeyIndex.Products, "");//Pradnya(60)Commented
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Villa_Room_Name.ToString()].ToString(), SubMenuKeyProduct.Villa_Room_Name.ToString(), MenuKeyIndex.Products, "../Pages/Product/VillaRoomName.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Update_Booking_Costs.ToString()].ToString(), SubMenuKeyProduct.Update_Booking_Costs.ToString(), MenuKeyIndex.Products, "");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Supplier_Extranet_Messages.ToString()].ToString(), SubMenuKeyProduct.Supplier_Extranet_Messages.ToString(), MenuKeyIndex.Products, "../Pages/Product/SupplierExtranetMessage.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Yield_Rule_Setup.ToString()].ToString(), SubMenuKeyProduct.Yield_Rule_Setup.ToString(), MenuKeyIndex.Products, "../Pages/Product/YieldRules.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Query_Tool.ToString()].ToString(), SubMenuKeyProduct.Query_Tool.ToString(), MenuKeyIndex.Products, "../Pages/Product/QueryTool.aspx");
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Instalment_Discounts.ToString()].ToString(), SubMenuKeyProduct.Instalment_Discounts.ToString(), MenuKeyIndex.Products, "../Pages/Product/InstalmentDiscounts.aspx");//Shivanand(11)
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Batch_Instalment_Generator.ToString()].ToString(), SubMenuKeyProduct.Batch_Instalment_Generator.ToString(), MenuKeyIndex.Products, "../Pages/Product/BatchInstalmentGenerator.aspx");//Shivanand(11)
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Availability_Updater.ToString()].ToString(), SubMenuKeyProduct.Availability_Updater.ToString(), MenuKeyIndex.Products, "../Pages/Product/AvailabilityUpdater.aspx");//Kedar(22)
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Supplier_Servcie_Document.ToString()].ToString(), SubMenuKeyProduct.Supplier_Servcie_Document.ToString(), MenuKeyIndex.Products, "..Pages/Product/SupplierServiceDocument.aspx");//Vikrant(58)
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Bulk_Contract_Maintenance.ToString()].ToString(), SubMenuKeyProduct.Bulk_Contract_Maintenance.ToString(), MenuKeyIndex.Products, "../Pages/Product/BulkContractMaintenance.aspx"); //Clerance(53)
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Bulk_Contract_Maintenance_History.ToString()].ToString(), SubMenuKeyProduct.Bulk_Contract_Maintenance_History.ToString(), MenuKeyIndex.Products, "../Pages/Product/BulkContractMaintenanceHistory.aspx"); //Clerance(53)
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Offline_Price_Editor.ToString()].ToString(), SubMenuKeyProduct.Offline_Price_Editor.ToString(), MenuKeyIndex.Products, "../Pages/Product/OfflinePriceEditor.aspx"); //Sujata(54)
		AddNewSubMenuItem(productsHashtable[SubMenuKeyProduct.Discount.ToString()].ToString(), SubMenuKeyProduct.Discount.ToString(), MenuKeyIndex.Products, "DiscountSearch/DiscountSearchContainer"); //Omkar N.(81)
		#endregion

		#region FLIGHTS SUB MENU

		//Hashtabel for flights menu
		Hashtable flightHashtable = new Hashtable();
		flightHashtable.Add(SubMenuKeyFlights.Airlines.ToString(), "Airlines");
		flightHashtable.Add(SubMenuKeyFlights.Airports.ToString(), "Airports"); //Poonam(60)
		flightHashtable.Add(SubMenuKeyFlights.Flight_Cities.ToString(), "Flight Cities");
		flightHashtable.Add(SubMenuKeyFlights.Special_Requests.ToString(), "Special Requests");
		flightHashtable.Add(SubMenuKeyFlights.Schedule_Change_Manager.ToString(), "Schedule Change Manager");// siddhi B (74)		
		flightHashtable.Add(SubMenuKeyFlights.Flight_Schedule_Utility.ToString(), "Flight Schedule Change Utility");
		flightHashtable.Add(SubMenuKeyFlights.Update_FSDT_Flight_Booking_Details.ToString(), "Update FSDT Flight Booking Details");
		flightHashtable.Add(SubMenuKeyFlights.TermsAndConditions.ToString(), "Terms & Conditions");
		flightHashtable.Add(SubMenuKeyFlights.Flight_Service_Fees.ToString(), "Flight Service Fees"); //Kalpi(41)
		flightHashtable.Add(SubMenuKeyFlights.Fare_Rules_Configuration.ToString(), "Fare Rules Configuration"); //Reema(47)
		flightHashtable.Add(SubMenuKeyFlights.MarkUp_Rule_Priorities.ToString(), "Markup Rule Priorities"); //Reema(49)(53)
		flightHashtable.Add(SubMenuKeyFlights.Fare_Increase_Decrease_Handling.ToString(), "Fare Increase/Decrease Handling"); //Sandip P.(50)
		flightHashtable.Add(SubMenuKeyFlights.Agent_MarkUp_On_Service_Fee.ToString(), "Agent Markup on Service Fee"); //Ashley
		flightHashtable.Add(SubMenuKeyFlights.Agent_Flights_Commission.ToString(), "Agent Flights Commission "); //Rejeena


		flightHashtable = Base.GetMultilingualMessageList("Menu", flightHashtable);

		//Flight Menu
		AddNewSubMenuItem(flightHashtable[SubMenuKeyFlights.Airlines.ToString()].ToString(), SubMenuKeyFlights.Airlines.ToString(), MenuKeyIndex.Flights, "");
		AddNewSubMenuItem(flightHashtable[SubMenuKeyFlights.Airports.ToString()].ToString(), SubMenuKeyFlights.Airports.ToString(), MenuKeyIndex.Flights, ""); //Poonam(60)
		AddNewSubMenuItem(flightHashtable[SubMenuKeyFlights.Flight_Cities.ToString()].ToString(), SubMenuKeyFlights.Flight_Cities.ToString(), MenuKeyIndex.Flights, "");
		AddNewSubMenuItem(flightHashtable[SubMenuKeyFlights.Special_Requests.ToString()].ToString(), SubMenuKeyFlights.Airlines.ToString(), MenuKeyIndex.Flights, "");
		AddNewSubMenuItem(flightHashtable[SubMenuKeyFlights.Flight_Schedule_Utility.ToString()].ToString(), SubMenuKeyFlights.Flight_Schedule_Utility.ToString(), MenuKeyIndex.Flights, "");
		AddNewSubMenuItem(flightHashtable[SubMenuKeyFlights.Update_FSDT_Flight_Booking_Details.ToString()].ToString(), SubMenuKeyFlights.Update_FSDT_Flight_Booking_Details.ToString(), MenuKeyIndex.Flights, "");
		AddNewSubMenuItem(flightHashtable[SubMenuKeyFlights.TermsAndConditions.ToString()].ToString(), SubMenuKeyFlights.TermsAndConditions.ToString(), MenuKeyIndex.Flights, "");
		AddNewSubMenuItem(flightHashtable[SubMenuKeyFlights.Special_Requests.ToString()].ToString(), SubMenuKeyFlights.Special_Requests.ToString(), MenuKeyIndex.Flights, ""); //Wayne(23)
		AddNewSubMenuItem(flightHashtable[SubMenuKeyFlights.Schedule_Change_Manager.ToString()].ToString(), SubMenuKeyFlights.Schedule_Change_Manager.ToString(), MenuKeyIndex.Flights, "FlightSCM/FlightSCMContainer"); //Siddhi B (74) //Pranav(75)     		
		AddNewSubMenuItem(flightHashtable[SubMenuKeyFlights.Flight_Service_Fees.ToString()].ToString(), SubMenuKeyFlights.Flight_Service_Fees.ToString(), MenuKeyIndex.Flights, ""); //Kalpi(41)
		AddNewSubMenuItem(flightHashtable[SubMenuKeyFlights.Fare_Increase_Decrease_Handling.ToString()].ToString(), SubMenuKeyFlights.Fare_Increase_Decrease_Handling.ToString(), MenuKeyIndex.Flights, ""); //Sandip P.(50)
		AddNewSubMenuItem(flightHashtable[SubMenuKeyFlights.Agent_MarkUp_On_Service_Fee.ToString()].ToString(), SubMenuKeyFlights.Agent_MarkUp_On_Service_Fee.ToString(), MenuKeyIndex.Flights, ""); //Ashley(55)
		#endregion

		#region PROGRAMS SUB MENU

		//hashtable 
		Hashtable programHashtable = new Hashtable();
		programHashtable.Add(SubMenuKeyProgram.Calculator.ToString(), "Calculator");
		programHashtable.Add(SubMenuKeyProgram.Notepad.ToString(), "Notepad");
		programHashtable.Add(SubMenuKeyProgram.Task_Manager.ToString(), "Task Manager");
		programHashtable.Add(SubMenuKeyProgram.Word.ToString(), "Word");
		programHashtable.Add(SubMenuKeyProgram.Excel.ToString(), "Excel");
		programHashtable.Add(SubMenuKeyProgram.Internet_Explorer.ToString(), "Internet Explorer");

		programHashtable = Base.GetMultilingualMessageList("Menu", programHashtable);

		//Programs Menu
		AddNewSubMenuItem(programHashtable[SubMenuKeyProgram.Calculator.ToString()].ToString(), SubMenuKeyProgram.Calculator.ToString(), MenuKeyIndex.Programs, "");
		AddNewSubMenuItem(programHashtable[SubMenuKeyProgram.Notepad.ToString()].ToString(), SubMenuKeyProgram.Notepad.ToString(), MenuKeyIndex.Programs, "");
		AddNewSubMenuItem(programHashtable[SubMenuKeyProgram.Task_Manager.ToString()].ToString(), SubMenuKeyProgram.Task_Manager.ToString(), MenuKeyIndex.Programs, "");
		AddNewSubMenuItem(programHashtable[SubMenuKeyProgram.Word.ToString()].ToString(), SubMenuKeyProgram.Word.ToString(), MenuKeyIndex.Programs, "");
		AddNewSubMenuItem(programHashtable[SubMenuKeyProgram.Excel.ToString()].ToString(), SubMenuKeyProgram.Excel.ToString(), MenuKeyIndex.Programs, "");
		AddNewSubMenuItem(programHashtable[SubMenuKeyProgram.Internet_Explorer.ToString()].ToString(), SubMenuKeyProgram.Internet_Explorer.ToString(), MenuKeyIndex.Programs, "");
		#endregion

		#region REPORTS SUB MENU

		Hashtable reportHashtable = new Hashtable();
		reportHashtable.Add(SubMenuKeyReport.Booking_Report_Screen.ToString(), "Booking Report");
		reportHashtable.Add(SubMenuKeyReport.Service_Report_Screen.ToString(), "Service Report");
		reportHashtable.Add(SubMenuKeyReport.Supplier_Report_Screen.ToString(), "Supplier Report");
		reportHashtable.Add(SubMenuKeyReport.Tariff_Export_Report_Screen.ToString(), "Tariff Report");
		reportHashtable.Add(SubMenuKeyReport.Finance_Report_Screen.ToString(), "Finance Report");
		reportHashtable.Add(SubMenuKeyReport.Quote_Reports_Screen.ToString(), "Quote Reports");
		reportHashtable.Add(SubMenuKeyReport.Booking_Notes_Report_Screen.ToString(), "Booking Notes Report");
		reportHashtable.Add(SubMenuKeyReport.Report_Group.ToString(), "Report Group");
		reportHashtable.Add(SubMenuKeyReport.Report_Registration.ToString(), "Report Registration");
		reportHashtable.Add(SubMenuKeyReport.Package_Report_Screen.ToString(), "Package Report");
		reportHashtable.Add(SubMenuKeyReport.Flight_Report_Screen.ToString(), "Flight Report");
		reportHashtable.Add(SubMenuKeyReport.Allocation_Usage_Graph_Report_Screen.ToString(), "Allocation Usage Graph");
		reportHashtable.Add(SubMenuKeyReport.AutoMessaging_Failed_Messages.ToString(), "Failed Messages Report");
		reportHashtable.Add(SubMenuKeyReport.Agent_Report_Options_Screen.ToString(), "Agent Report Options");
		reportHashtable.Add(SubMenuKeyReport.Rail_Report_Screen.ToString(), "Rail Report Options");
		reportHashtable.Add(SubMenuKeyReport.Unsent_Messages.ToString(), "Failed Messages");//Amrapali(73)

		reportHashtable = Base.GetMultilingualMessageList("Menu", reportHashtable);

		//Reports Menu
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Booking_Report_Screen.ToString()].ToString(), SubMenuKeyReport.Booking_Report_Screen.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Service_Report_Screen.ToString()].ToString(), SubMenuKeyReport.Service_Report_Screen.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Supplier_Report_Screen.ToString()].ToString(), SubMenuKeyReport.Supplier_Report_Screen.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Tariff_Export_Report_Screen.ToString()].ToString(), SubMenuKeyReport.Tariff_Export_Report_Screen.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Finance_Report_Screen.ToString()].ToString(), SubMenuKeyReport.Finance_Report_Screen.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Quote_Reports_Screen.ToString()].ToString(), SubMenuKeyReport.Quote_Reports_Screen.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Booking_Notes_Report_Screen.ToString()].ToString(), SubMenuKeyReport.Booking_Notes_Report_Screen.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Report_Group.ToString()].ToString(), SubMenuKeyReport.Report_Group.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Report_Registration.ToString()].ToString(), SubMenuKeyReport.Report_Registration.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Package_Report_Screen.ToString()].ToString(), SubMenuKeyReport.Package_Report_Screen.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Flight_Report_Screen.ToString()].ToString(), SubMenuKeyReport.Flight_Report_Screen.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Allocation_Usage_Graph_Report_Screen.ToString()].ToString(), SubMenuKeyReport.Allocation_Usage_Graph_Report_Screen.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.AutoMessaging_Failed_Messages.ToString()].ToString(), SubMenuKeyReport.AutoMessaging_Failed_Messages.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Agent_Report_Options_Screen.ToString()].ToString(), SubMenuKeyReport.Agent_Report_Options_Screen.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Rail_Report_Screen.ToString()].ToString(), SubMenuKeyReport.Rail_Report_Screen.ToString(), MenuKeyIndex.Reports, "");
		AddNewSubMenuItem(reportHashtable[SubMenuKeyReport.Unsent_Messages.ToString()].ToString(), SubMenuKeyReport.Unsent_Messages.ToString(), MenuKeyIndex.Reports, "");//Amrapali(73)
		#endregion

		#region ACCOUNTS SUB MENU

		Hashtable accountsHashtable = new Hashtable();
		accountsHashtable.Add(SubMenuKeyAccount.Export_Financial_Details.ToString(), "Export Financial Details");
		accountsHashtable.Add(SubMenuKeyAccount.Batch_Invoice_Creation.ToString(), "Batch Invoice Creation");
		accountsHashtable.Add(SubMenuKeyAccount.Purchase_Invoice_Creation.ToString(), "Purchase Invoice Creation");
		accountsHashtable.Add(SubMenuKeyAccount.Purchase_Invoice_Import.ToString(), "Purchase Invoice Import");//Anshul(77)
		accountsHashtable.Add(SubMenuKeyAccount.Reprint_Invoices.ToString(), "Reprint Invoices");
		accountsHashtable.Add(SubMenuKeyAccount.Batch_Voucher_Close.ToString(), "Batch Voucher Close");
		accountsHashtable.Add(SubMenuKeyAccount.Exchange_Rates.ToString(), "Exchange Rate");
		accountsHashtable.Add(SubMenuKeyAccount.Batch_Receipts_Entry.ToString(), "Batch Receipts Entry");//Amey.R(61) //Gautami(62)
		accountsHashtable.Add(SubMenuKeyAccount.Tax_Codes.ToString(), "Tax Codes");
		accountsHashtable.Add(SubMenuKeyAccount.Currency.ToString(), "Currency");
		accountsHashtable.Add(SubMenuKeyAccount.Create_GL_Accounts.ToString(), "Create GL Accounts");
		accountsHashtable.Add(SubMenuKeyAccount.Check_Commission_Payments.ToString(), "Check Comm. Payment");
		accountsHashtable.Add(SubMenuKeyAccount.Access_to_Commission_Margin_Setup.ToString(), "Commission Margin Setup");
		accountsHashtable.Add(SubMenuKeyAccount.TIC_Insurance_Export.ToString(), "TIC Insurance Export");
		accountsHashtable.Add(SubMenuKeyAccount.Suppliers_Invoice_Submission.ToString(), "Suppliers Invoice Submission");
		accountsHashtable.Add(SubMenuKeyAccount.Banked_Receipts.ToString(), "Banked Receipts"); //Kedar(12)
		accountsHashtable.Add(SubMenuKeyAccount.Bank_Profiles.ToString(), "Bank Profiles");//Sudeep(15)
		accountsHashtable.Add(SubMenuKeyAccount.Invoice_Daily_Exchange_Rates.ToString(), "Invoice Daily Exchange Rate");//Pranav(62)
		accountsHashtable.Add(SubMenuKeyAccount.Receipts_Reconciliation.ToString(), "Receipts Reconciliation");//Poonam(82)

		accountsHashtable = Base.GetMultilingualMessageList("Menu", accountsHashtable);

		//Accounts Menu
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Export_Financial_Details.ToString()].ToString(), SubMenuKeyAccount.Export_Financial_Details.ToString(), MenuKeyIndex.Accounts, "");
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Batch_Invoice_Creation.ToString()].ToString(), SubMenuKeyAccount.Batch_Invoice_Creation.ToString(), MenuKeyIndex.Accounts, "Batch Invoice Creation");//Harshad(19)
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Purchase_Invoice_Creation.ToString()].ToString(), SubMenuKeyAccount.Purchase_Invoice_Creation.ToString(), MenuKeyIndex.Accounts, "Purchase Invoice Creation");//Harshad(24)
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Purchase_Invoice_Import.ToString()].ToString(), SubMenuKeyAccount.Purchase_Invoice_Import.ToString(), MenuKeyIndex.Accounts, "Purchase Invoice Import");//Anshul(77)
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Reprint_Invoices.ToString()].ToString(), SubMenuKeyAccount.Reprint_Invoices.ToString(), MenuKeyIndex.Accounts, "");
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Batch_Voucher_Close.ToString()].ToString(), SubMenuKeyAccount.Batch_Voucher_Close.ToString(), MenuKeyIndex.Accounts, "Batch Voucher Close");//Ravish(27)//Sunil(80)
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Exchange_Rates.ToString()].ToString(), SubMenuKeyAccount.Exchange_Rates.ToString(), MenuKeyIndex.Accounts, "");
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Batch_Receipts_Entry.ToString()].ToString(), SubMenuKeyAccount.Batch_Receipts_Entry.ToString(), MenuKeyIndex.Accounts, "../Pages/Finance/BatchReceiptsEntry.aspx");//Amey.R(61) //Gautami(62)
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Tax_Codes.ToString()].ToString(), SubMenuKeyAccount.Tax_Codes.ToString(), MenuKeyIndex.Accounts, "../Pages/Finance/TaxCodes.aspx");//Sarika(29)
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Currency.ToString()].ToString(), SubMenuKeyAccount.Currency.ToString(), MenuKeyIndex.Accounts, "../Pages/Product/Currencies.aspx"); //Virag
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Create_GL_Accounts.ToString()].ToString(), SubMenuKeyAccount.Create_GL_Accounts.ToString(), MenuKeyIndex.Accounts, "../Pages/Product/GLAccounts.aspx");//Deepa(28)
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Check_Commission_Payments.ToString()].ToString(), SubMenuKeyAccount.Check_Commission_Payments.ToString(), MenuKeyIndex.Accounts, "../Pages/Finance/CheckCommissionPayments.aspx");  //SiddheshPrb(25)
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Access_to_Commission_Margin_Setup.ToString()].ToString(), SubMenuKeyAccount.Access_to_Commission_Margin_Setup.ToString(), MenuKeyIndex.Accounts, "");
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.TIC_Insurance_Export.ToString()].ToString(), SubMenuKeyAccount.TIC_Insurance_Export.ToString(), MenuKeyIndex.Accounts, "");
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Suppliers_Invoice_Submission.ToString()].ToString(), SubMenuKeyAccount.Suppliers_Invoice_Submission.ToString(), MenuKeyIndex.Accounts, "");
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Banked_Receipts.ToString()].ToString(), SubMenuKeyAccount.Banked_Receipts.ToString(), MenuKeyIndex.Accounts, ""); //Kedar(12)
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Bank_Profiles.ToString()].ToString(), SubMenuKeyAccount.Bank_Profiles.ToString(), MenuKeyIndex.Accounts, "../Pages/Finance/BankProfiles.aspx"); //Sudeep(15)
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Invoice_Daily_Exchange_Rates.ToString()].ToString(), SubMenuKeyAccount.Invoice_Daily_Exchange_Rates.ToString(), MenuKeyIndex.Accounts, "");//Pranav(62)
		AddNewSubMenuItem(accountsHashtable[SubMenuKeyAccount.Receipts_Reconciliation.ToString()].ToString(), SubMenuKeyAccount.Receipts_Reconciliation.ToString(), MenuKeyIndex.Accounts, "../Pages/Finance/ReceiptsReconciliation.aspx"); //Sudeep(15)
	   
		#endregion

		#region FULFILLMENT SUB MENU

		//hashtable for Fullfillment
		Hashtable fulfillmentHashtable = new Hashtable();
		fulfillmentHashtable.Add(SubMenuKeyFulfillment.Create_Document_Packages.ToString(), "Create Document Pkgs");
		fulfillmentHashtable.Add(SubMenuKeyFulfillment.Print_Document_Packages.ToString(), "Print Document Packages");
		fulfillmentHashtable.Add(SubMenuKeyFulfillment.MessageEditor.ToString(), "Message Editor");
		fulfillmentHashtable.Add(SubMenuKeyFulfillment.Mail_Shot.ToString(), "Mail Shot");
		fulfillmentHashtable.Add(SubMenuKeyFulfillment.Batch_Message_Generation.ToString(), "Batch Message Generation");
		fulfillmentHashtable.Add(SubMenuKeyFulfillment.Manual_Manifest_Generation.ToString(), "Manual Manifest Generation");

		fulfillmentHashtable = Base.GetMultilingualMessageList("Menu", fulfillmentHashtable);

		//Fullfillment Menu(Marketing)
		AddNewSubMenuItem(fulfillmentHashtable[SubMenuKeyFulfillment.Create_Document_Packages.ToString()].ToString(), SubMenuKeyFulfillment.Create_Document_Packages.ToString(), MenuKeyIndex.Fulfillment, "");
		AddNewSubMenuItem(fulfillmentHashtable[SubMenuKeyFulfillment.Print_Document_Packages.ToString()].ToString(), SubMenuKeyFulfillment.Print_Document_Packages.ToString(), MenuKeyIndex.Fulfillment, "");
		AddNewSubMenuItem(fulfillmentHashtable[SubMenuKeyFulfillment.MessageEditor.ToString()].ToString(), SubMenuKeyFulfillment.MessageEditor.ToString(), MenuKeyIndex.Fulfillment, "");
		AddNewSubMenuItem(fulfillmentHashtable[SubMenuKeyFulfillment.Mail_Shot.ToString()].ToString(), SubMenuKeyFulfillment.Mail_Shot.ToString(), MenuKeyIndex.Fulfillment, "");
		AddNewSubMenuItem(fulfillmentHashtable[SubMenuKeyFulfillment.Batch_Message_Generation.ToString()].ToString(), SubMenuKeyFulfillment.Batch_Message_Generation.ToString(), MenuKeyIndex.Fulfillment, "");
		AddNewSubMenuItem(fulfillmentHashtable[SubMenuKeyFulfillment.Manual_Manifest_Generation.ToString()].ToString(), SubMenuKeyFulfillment.Manual_Manifest_Generation.ToString(), MenuKeyIndex.Fulfillment, "");
		#endregion

		#region SETUP SUB MENU

		//Create Hashtable for setup
		Hashtable setupHashtable = new Hashtable();
		setupHashtable.Add(SubMenuKeySetup.Server_Setup.ToString(), "Setup Server");
		setupHashtable.Add(SubMenuKeySetup.Web_Server_Setup.ToString(), "Setup Web Server");
		setupHashtable.Add(SubMenuKeySetup.Setup_Debug_Mode.ToString(), "Setup Debug Mode");

		setupHashtable = Base.GetMultilingualMessageList("Menu", setupHashtable);

		//Setup Menu
		//AddNewSubMenuItem(setupHashtable["Server Setup"].ToString(), "Server Setup", MenuKeyIndex.Setup, "");
		//AddNewSubMenuItem(setupHashtable["Web Server Setup"].ToString(), "Web Server Setup", MenuKeyIndex.Setup, "");
		//AddNewSubMenuItem(setupHashtable["Setup Debug Mode"].ToString(), "", MenuKeyIndex.Setup, "");
		#endregion
		
		//BOC Sahil(75)
		#region CACHE
		Hashtable cacheHashtable = new Hashtable();
		cacheHashtable.Add(SubMenuKeyCache.Cache_Rules.ToString(), "Cache Rules");
		cacheHashtable.Add(SubMenuKeyCache.Cache_Search_Criteria.ToString(), "Cache Search Criteria");
		cacheHashtable.Add(SubMenuKeyCache.Remote_Services.ToString(), "Remote Services");
		cacheHashtable.Add(SubMenuKeyCache.Cache_Statistics.ToString(), "Cache Statistics");
		cacheHashtable = Base.GetMultilingualMessageList("Menu", cacheHashtable);

		AddNewSubMenuItem(cacheHashtable[SubMenuKeyCache.Cache_Rules.ToString()].ToString(), SubMenuKeyCache.Cache_Rules.ToString(), MenuKeyIndex.Cache, "CacheRules/CacheRulesContainer");
		AddNewSubMenuItem(cacheHashtable[SubMenuKeyCache.Cache_Search_Criteria.ToString()].ToString(), SubMenuKeyCache.Cache_Search_Criteria.ToString(), MenuKeyIndex.Cache, "FlightCacheSearchCriteria/FlightCacheSearchCriteriaContainer");
		AddNewSubMenuItem(cacheHashtable[SubMenuKeyCache.Remote_Services.ToString()].ToString(), SubMenuKeyCache.Remote_Services.ToString(), MenuKeyIndex.Cache, "RemoteServices/RemoteServicesContainer");
		AddNewSubMenuItem(cacheHashtable[SubMenuKeyCache.Cache_Statistics.ToString()].ToString(), SubMenuKeyCache.Cache_Statistics.ToString(), MenuKeyIndex.Cache, "CacheStatistics/CacheStatisticsContainer");
		#endregion CACHE
		//EOC Sahil(75)

		#endregion Sub Menus
	}

	//Add Header Menus that are visible
	protected void AddNewMenuItem(string MenuDisplayName, string MenuKey, string MenuImgName)
	{
		if (UserSecurity.GetMenuAccessRights(MenuKey, "", 0))//Aparna(32)
		{
			MenuItem ObjNewMenuItem = new MenuItem();
			ObjNewMenuItem.ImageUrl = "../Masters/Images/" + MenuImgName + ".png";

			string[] strSplitedMulitlingualText = GetTextWithToolTip(MenuDisplayName);
			MenuDisplayName = Convert.ToString(strSplitedMulitlingualText[0]);
			ObjNewMenuItem.Text = MenuDisplayName;
			if (strSplitedMulitlingualText.Length > 1)
				ObjNewMenuItem.ToolTip = Convert.ToString(strSplitedMulitlingualText[1]);

			//BOC Prasad(05)
			//  ObjNewMenuItem.Value =MenuDisplayName; // MenuKey.ToString(); 

			if (MenuKey != string.Empty)
				ObjNewMenuItem.Value = MenuKey.ToString();
			else
				ObjNewMenuItem.Value = MenuDisplayName.ToString();
			//EOC PRasad(05)
			ObjNewMenuItem.Selectable = false;

			//if (!mnu_TSBrowser.Items.Contains(ObjNewMenuItem))
			//{
			//    mnu_TSBrowser.Items.Add(ObjNewMenuItem);
			//}
		}
	}

	//BOC Sneha S.(76)
	#region Get Package Pricing Analysis Flag from System Settings Field
	protected bool GetPackagePricingAnalysisFlag()
	{
		try
		{
			AuditManager.AuditManager.Log("usrctl_mainmenu.ascx.cs:GetPackagePricingAnalysisFlag", "Start", AuditManager.AuditManager.AuditType.Debug, AuditManager.AuditManager.ApplicationLayer.Website);
			var enableThePackagePricingAnalysisModule = false;
			ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequest getSystemWideSettingsRequest = new ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequest();
			getSystemWideSettingsRequest.GetSystemWideSettingsRequestData = new ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequestData();
			getSystemWideSettingsRequest.GetSystemWideSettingsRequestData.SystemType = ServiceProxyManager.ProxyClasses.SystemSetup.SystemTypes.Package;
			getSystemWideSettingsRequest.GetSystemWideSettingsRequestData.ColumnNames = new List<string> { ServiceProxyManager.ProxyClasses.SystemSetup.PackageSettingColumnNames.EnableThePackagePricingAnalysisModule.ToString() };
			ServiceProxyManager.Factory.SystemSetup.OrganisationFactory organisationFactory = new ServiceProxyManager.Factory.SystemSetup.OrganisationFactory();
			var getSystemWideSettingsResponse = organisationFactory.GetSystemWideSettings(getSystemWideSettingsRequest);

			string flagValue = null;
			var flag = getSystemWideSettingsResponse.GetSystemWideSettingResponseData.Find(prop => prop.FieldName == ServiceProxyManager.ProxyClasses.SystemSetup.PackageSettingColumnNames.EnableThePackagePricingAnalysisModule.ToString());
			if (flag != null && flag.FieldValue != null)
				flagValue = flag.FieldValue.ToString();

			if (flagValue != null && (flagValue.Trim().ToLowerInvariant() == "true" || flagValue.Trim() == "1"))
				enableThePackagePricingAnalysisModule = true;
			else
				enableThePackagePricingAnalysisModule = false;

			AuditManager.AuditManager.Log("usrctl_mainmenu.ascx.cs:GetPackagePricingAnalysisFlag", "End", AuditManager.AuditManager.AuditType.Debug, AuditManager.AuditManager.ApplicationLayer.Website);

			return enableThePackagePricingAnalysisModule;
		}
		catch (Exception ex)
		{
			string popupScript = "alert(\"" + ex.Message + "\")";
			ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "clientScript", popupScript, true);
			return false;
		}

	}
	#endregion Get Package Pricing Analysis Flag from System Settings Field
	//EOC Sneha S.(76)

	//To Add Sub Menu to the Header menus
	protected void AddNewSubMenuItem(string MenuDisplayName, string MenuKey, MenuKeyIndex ParentMenuKey, string NavigateURL)
	{
		MenuItem SelectedMenuItem = new MenuItem();// ashfaq(6)mnu_TSBrowser.FindItem(ParentMenuKey.ToString());
		if (SelectedMenuItem != null)
		{
			if (GetPagePermissions(MenuKey))
			{
				MenuItem ObjNewMenuItem = new MenuItem();
				ObjNewMenuItem.ImageUrl = "";

				string[] strSplitedMulitlingualText = GetTextWithToolTip(MenuDisplayName);
				MenuDisplayName = Convert.ToString(strSplitedMulitlingualText[0]);
				ObjNewMenuItem.Text = MenuDisplayName; // Prasad(05)
				if (strSplitedMulitlingualText.Length > 1)
					ObjNewMenuItem.ToolTip = Convert.ToString(strSplitedMulitlingualText[1]);

				if (MenuKey != string.Empty)
					ObjNewMenuItem.Value = MenuKey.ToString();
				else
					ObjNewMenuItem.Value = MenuDisplayName.ToString();

				ObjNewMenuItem.NavigateUrl = NavigateURL;


				//select the menu visible menu item based on the index number
				if ((ParentMenuKey.ToString() != MenuKeyIndex.System.ToString()) &&
				   (ParentMenuKey.ToString() != MenuKeyIndex.Products.ToString()) &&
				   (ParentMenuKey.ToString() != MenuKeyIndex.Clients.ToString()) &&
				   (ParentMenuKey.ToString() != MenuKeyIndex.Bookings.ToString()))
				{
					ObjNewMenuItem.Enabled = false;

				}
				else if (ParentMenuKey.ToString() == MenuKeyIndex.System.ToString()) // "System") // Prasad(05)
				{
					if ((ObjNewMenuItem.Value == SubMenuKeySystem.Message_Editor.ToString())
					|| (ObjNewMenuItem.Value == SubMenuKeySystem.End_Point_Configuration.ToString())
					|| (ObjNewMenuItem.Value == SubMenuKeySystem.Default_Booking_Tasks.ToString())
					|| (ObjNewMenuItem.Value == SubMenuKeySystem.Import_External_Services.ToString()))
					{
						ObjNewMenuItem.Enabled = false;
					}
				}
				else if (ParentMenuKey.ToString() == MenuKeyIndex.Products.ToString()) //"Products") // Prasad(05)
				{
					if (
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Supplier.ToString()) &&
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Service.ToString()) && (ObjNewMenuItem.Value != SubMenuKeyProduct.Contract.ToString()) &&
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Villa_Room_Name.ToString()) && (ObjNewMenuItem.Value != SubMenuKeyProduct.Villa_Group.ToString()) &&
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Web_Passenger_Questions.ToString()) && (ObjNewMenuItem.Value != SubMenuKeyProduct.Service_Type_Questions.ToString()) &&
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Allocation_Name.ToString()) && (ObjNewMenuItem.Value != SubMenuKeyProduct.Supplier_Group.ToString()) && (ObjNewMenuItem.Value != SubMenuKeyProduct.Batch_Selling_Price_Creation.ToString()) && //Vanessa (39)
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Option.ToString()) && (ObjNewMenuItem.Value != SubMenuKeyProduct.Extra.ToString()) && (ObjNewMenuItem.Value != SubMenuKeyProduct.Facilities.ToString()) &&
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Child_Policy.ToString()) &&
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Cancellation_Policies.ToString()) &&
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Supplier_Extranet_Messages.ToString()) &&
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Batch_Rule_Generation.ToString()) &&
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Rating.ToString()) &&
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Yield_Rule_Setup.ToString()) &&
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Query_Tool.ToString()) &&
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Mandatory_Services_Access.ToString()) && //Vimlesh(59)
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Instalment_Discounts.ToString()) && //Shivanand(11)
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Batch_Instalment_Generator.ToString()) && //Shivanand(11)
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Supplier_Servcie_Document.ToString()) &&//Vikrant(58)
						(ObjNewMenuItem.Value != SubMenuKeyProduct.Rail_Manager.ToString())
						&&(ObjNewMenuItem.Value != SubMenuKeyProduct.Discount.ToString()) //Omkar N(81)
					   )
					{
						ObjNewMenuItem.Enabled = false;
					}

				}

				else if (ParentMenuKey.ToString() == MenuKeyIndex.Clients.ToString()) //"Clients") // Prasad(05)
				{
					if (
						(ObjNewMenuItem.Value != SubMenuKeyClients.Agent_Group.ToString())
						&&
					   (ObjNewMenuItem.Value != SubMenuKeyClients.Agent.ToString())
						&&
						(ObjNewMenuItem.Value != SubMenuKeyClients.Default_Price_Type.ToString())
						&&
						(ObjNewMenuItem.Value != SubMenuKeyClients.Agent_Group_Commission_Update.ToString())
						&& (ObjNewMenuItem.Value != SubMenuKeyClients.Passenger.ToString())
						 && (ObjNewMenuItem.Value != SubMenuKeyClients.New_Client_Credit.ToString())
						&& (ObjNewMenuItem.Value != SubMenuKeyClients.Search_Client_Credit.ToString())
						 && (ObjNewMenuItem.Value != SubMenuKeyClients.Agent_Portal.ToString())//Deepa(16)

					   )
					{
						ObjNewMenuItem.Enabled = false;
					}

				}
				else if (ParentMenuKey.ToString() == MenuKeyIndex.Bookings.ToString()) //  "Booking")  // Prasad(05)
				{
					if ((ObjNewMenuItem.Value != SubMenuKeyBookings.Booking_Find.ToString()) && (ObjNewMenuItem.Value != SubMenuKeyBookings.Package_Search.ToString()) && (ObjNewMenuItem.Value != SubMenuKeyBookings.Service_Search.ToString()) && (ObjNewMenuItem.Value != SubMenuKeyBookings.New_Booking.ToString()) && (ObjNewMenuItem.Value != SubMenuKeyBookings.Commission_Payment_Approval.ToString()) && (ObjNewMenuItem.Value != SubMenuKeyBookings.Task_Manager.ToString()))   //SiddheshPrb(25) //Abhijit L.(33)
					{
						ObjNewMenuItem.Enabled = false;
					}

				}


				//BOC Rejeena
				else if (ParentMenuKey.ToString() == MenuKeyIndex.Flights.ToString())
				{
					if ((ObjNewMenuItem.Value != SubMenuKeyFlights.Agent_Flights_Commission.ToString()))
					{
						ObjNewMenuItem.Enabled = false;
					}

					//BOC Sandip P.(50)
				else if (ParentMenuKey.ToString() == MenuKeyIndex.Flights.ToString())
				{
					if ((ObjNewMenuItem.Value != SubMenuKeyFlights.Fare_Increase_Decrease_Handling.ToString()))
					{
						ObjNewMenuItem.Enabled = false;
					}
					//EOC Sandip P.(50)
				}
				//EOC 

				}
				//EOC Sandip P.(50)
				////BOC Ritesh
				//else if (ParentMenuKey.ToString() == SubMenuKeyTraining.Search_Service.ToString())
				//{
				//        ObjNewMenuItem.Enabled = false;

				//}
				////EOC Ritsh

				//End code for WTM
				// Insert the submenu item in the ChildItems collection of the root menu item at index number.
				SelectedMenuItem.ChildItems.Add(ObjNewMenuItem);
			}
		}
	}

	/// <summary>
	/// Returns string array with strcture as follows 
	/// [0]=Text
	/// [1]=Tooltip
	/// [2]=Image URL OR Navigattion URL
	/// </summary>
	/// <param name="strResourceText"></param>
	/// <returns></returns>
	private static string[] GetTextWithToolTip(string strResourceText)
	{

		string[] strArrSeprator = new string[] { "||" };
		string[] strArrResourceText = strResourceText.Split(strArrSeprator, StringSplitOptions.None);
		return strArrResourceText;


	}
	protected bool GetAgentGroupCommissionFlag()
	{
		ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequest ObjReq = new ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequest();


		ObjReq.GetSystemWideSettingsRequestData = new ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequestData();

		ObjReq.GetSystemWideSettingsRequestData.SystemType = ServiceProxyManager.ProxyClasses.SystemSetup.SystemTypes.Agents_Passengers;

		System.Collections.Generic.List<string> FieldNames = new System.Collections.Generic.List<string>();
		FieldNames.Add(Convert.ToString(ServiceProxyManager.ProxyClasses.SystemSetup.AgentPassengerSettingColumnNames.AgentSplitCommission));
		ObjReq.GetSystemWideSettingsRequestData.ColumnNames = FieldNames;
		ServiceProxyManager.Factory.SystemSetup.OrganisationFactory ObjFactory = new ServiceProxyManager.Factory.SystemSetup.OrganisationFactory();
		ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsResponse ObjResp = ObjFactory.GetSystemWideSettings(ObjReq);
		if (ObjResp != null && ObjResp.GetSystemWideSettingResponseData.Count > 0)
		{
			return Convert.ToBoolean(ObjResp.GetSystemWideSettingResponseData.First().FieldValue);
		}
		else
			return false;
	}

	//BOC Poornima(71)
	protected bool GetRailDisplayFlag()
	{
		ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequest ObjReq = new ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequest();
		ObjReq.GetSystemWideSettingsRequestData = new ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequestData();
		ObjReq.GetSystemWideSettingsRequestData.SystemType = ServiceProxyManager.ProxyClasses.SystemSetup.SystemTypes.Rail;
		System.Collections.Generic.List<string> FieldNames = new System.Collections.Generic.List<string>();
		FieldNames.Add(Convert.ToString(ServiceProxyManager.ProxyClasses.SystemSetup.RailColumnNames.DISPLAYRAIL));
		ObjReq.GetSystemWideSettingsRequestData.ColumnNames = FieldNames;
		ServiceProxyManager.Factory.SystemSetup.OrganisationFactory ObjFactory = new ServiceProxyManager.Factory.SystemSetup.OrganisationFactory();
		ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsResponse ObjResp = ObjFactory.GetSystemWideSettings(ObjReq);
		if (ObjResp != null && ObjResp.GetSystemWideSettingResponseData.Count > 0)
		{
			return Convert.ToBoolean(ObjResp.GetSystemWideSettingResponseData.First().FieldValue);
		}
		else
			return false;
	}
	//EOC Poornima(71)

	//BOC Sahil(75)
	protected bool GetEnableCatalogCacheFlag()
	{
		ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequest objReq = new ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequest();
		objReq.GetSystemWideSettingsRequestData = new ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequestData();
		objReq.GetSystemWideSettingsRequestData.SystemType = ServiceProxyManager.ProxyClasses.SystemSetup.SystemTypes.General;
		System.Collections.Generic.List<string> FieldNames = new System.Collections.Generic.List<string>();
		FieldNames.Add(Convert.ToString(ServiceProxyManager.ProxyClasses.SystemSetup.GeneralSettingsColumnNames.EnableCatalogCache));
		objReq.GetSystemWideSettingsRequestData.ColumnNames = FieldNames;
		ServiceProxyManager.Factory.SystemSetup.OrganisationFactory ObjFactory = new ServiceProxyManager.Factory.SystemSetup.OrganisationFactory();
		var objResp = ObjFactory.GetSystemWideSettings(objReq, true);

		if (objResp != null && objResp.GetSystemWideSettingResponseData.Count > 0)
		{
			return Convert.ToBoolean(objResp.GetSystemWideSettingResponseData.First().FieldValue);
		}
		else
			return false;
	}
	//EOC Sahil(75)
	#region Main Menu Enums
	//These are the Top Viisble Menu Items
	public enum MenuKeyIndex
	{
		System = 0,
		Bookings = 1,
		Quotes = 2,
		Package = 3,
		Clients = 4,
		Products = 5,
		Flights = 6,
		Programs = 7,
		Reports = 8,
		Accounts = 9,
		Fulfillment = 10,
		Setup = 11,
		Perfomance_Test = 12,
		Cache = 13//Sahil(75)
	}
	#endregion
	//BOC Prasad(05)
	private bool GetPagePermissions(string MenuKey)
	{
		string strPageName = MenuKey;
		int SecurityConstantID = 0;   //Aparna(32) -Added SecurityConstantID to all the MenuKey
		switch (MenuKey)
		{
			#region System
			case "Auto_Messaging":
				strPageName = "Auto Messaging";
				SecurityConstantID = 28230;
				break;
			case "GeoTree":
				strPageName = "GeoTree";
				SecurityConstantID = 20000;
				break;
			case "Country":
				strPageName = "Country";
				SecurityConstantID = 20010;
				break;
			case "Charging_Duration":
				strPageName = "Charging Duration";
				SecurityConstantID = 20040;
				break;
			case "Image":
				strPageName = "Image";
				SecurityConstantID = 20070;
				break;
			case "Meal_Plan":
				strPageName = "Meal Plan";
				SecurityConstantID = 20080;
				break;
			case "Message_Editor":
				strPageName = "Message Editor";
				SecurityConstantID = 27120;
				break;
			case "Rules":
				strPageName = "Rules";
				SecurityConstantID = 22030;
				break;
			case "User_Manager":
				strPageName = "User Manager";
				SecurityConstantID = 22000;
				break;
			case "Organisation":
				strPageName = "Organisation";
				SecurityConstantID = 22060;
				break;
			case "Mileage_Map":
				strPageName = "Mileage Map";
				SecurityConstantID = 22040;
				break;
			case "Commission_Maintenance":
				strPageName = "Commission Maintenance";
				SecurityConstantID = 27050;
				break;
			case "Default_Booking_Tasks":
				strPageName = "Default Booking Task";
				SecurityConstantID = 27110;
				break;
			case "Messaging_Settings":
				strPageName = "Messaging Settings";
				break;
			case "End_Point_Configuration":
				strPageName = "End Point Configuration";
				SecurityConstantID = 301100;
				break;
			case "Import_External_Services":
				strPageName = "End Point Configuration@Import External Services";
				SecurityConstantID = 402110;
				break;
			case "QA_Scripts":
				strPageName = "QA Scripts";
				SecurityConstantID = 400461;
				break;
			case "Charging_Policy":
				strPageName = "Charging Policy";
				SecurityConstantID = 20050;
				break;
			case "Statuses":
				strPageName = "Status Maintenance";
				SecurityConstantID = 20020;
				break;
			case "Types":
				strPageName = "Types Maintenance";
				SecurityConstantID = 20030;
				break;
			case "Messaging":
				strPageName = "Messaging";
				SecurityConstantID = 20100;
				break;
			//BOC sarika(18)
			case "Reset_Cache":
				strPageName = "Reset Cache";
				SecurityConstantID = (int)enmSystemMenu.ResetCache; //Nasia(72)
				break;
			//EOC sarika(18)
			//BOC Wayne(35)
			case "About": case "About_TB":
				strPageName = "About";
				SecurityConstantID = (int)enmSystemMenu.About;//Nasia(72)
				break;
			//EOC Wayne(35)
			
			//BOC Sandip P.(42)
			case "Location":
				strPageName = "Location";
				SecurityConstantID = 402140;
				break;
			//EOC Sandip P.(42)
			//BOC Vikrant(59)
			case "Price_Update_Status":
				strPageName = "Price Update Status";
				SecurityConstantID = 28640;
				break;
			//EOC Vikrant(59)
			//BOC Debasis(62)
			case "Task_Lists":
				strPageName = "Task Lists";
				SecurityConstantID = 22070;
				break;
			//EOC Debasis(62)
		   //BOC CANDIDA(67)
			case "ChannelManagerConfiguration":
				strPageName = "Channel Manager Configuration";
				SecurityConstantID = 404840;//31456
				break;
			 //EOC CANDIDA(67)
			 //BOC PNaik(xx)
			case "RegisterWidgets":
				strPageName = "Register Widgets";
				SecurityConstantID = 406750;
				break;
			//EOC PNaik(xx)
			//BOC Clerance(76)
			case "Supplier_Extranet_Settings":
				strPageName = "Supplier Extranet Settings";
				SecurityConstantID = 28350;
				break;
			//BOC Clerance(76)
			//BOC Vaishakhi(82)
			case "Areas":
				strPageName = "Areas";
				SecurityConstantID = 28650;
				break;
			//BOC Vaishakhi(82)
			//BOC Wayne(82)
			case "Queue_Status":
				strPageName = "Queue Status";
				SecurityConstantID = 407250;
				break;
			//EOC Wayne(82)
			#endregion
		   
			//BOC Madhu(83)
			case "Document_Template_Library":
				strPageName = "Document Template Library";
				SecurityConstantID = 407120;
				break;
		   //EOC Madhu(83)
			//BOC Rajesh(84) 
			case "Document_Component_Section_Library":
				strPageName = "Document Component Section Library";
				SecurityConstantID = 407110;
				break;
			//EOC Rajesh(84)
	  
			case "PricingEstimationDefault":
				strPageName = "Pricing Estimation Default";
				SecurityConstantID = 407242;
				break;
	  
			#region Bookings
			case "New_Booking":
				strPageName = "New Booking";
				SecurityConstantID = 21000;
				break;
			case "Booking_Find":
				strPageName = "Booking Find";
				SecurityConstantID = 21010;
				break;
			case "Replicate_Bookings":
				strPageName = "Replicate Bookings";
				SecurityConstantID = 27040;
				break;
			case "Package_Search":
				strPageName = "Package Search";
				SecurityConstantID = 27060;
				break;
			case "Passenger_Maint":
				strPageName = "Passenger Maint.";
				SecurityConstantID = 27100;
				break;
			case "Commission_Payment_Approval":
				strPageName = "Commission Payment Approval";
				SecurityConstantID = 27090;
				break;
			case "PNR_Shadow_List":
				strPageName = "PNR Shadow List";
				SecurityConstantID = 28270;
				break;
			case "Expired_Options":
				strPageName = "Change Booking Expiry Date";
				SecurityConstantID = 28110;
				break;
			case "Villa_Booking":
				strPageName = "Villa Booking";
				SecurityConstantID = 28140;
				break;
			case "Service_Search":
				strPageName = "Service Search";
				SecurityConstantID = 301110;
				break;
			case "Booking_Import":
				strPageName = "Booking Import";
				SecurityConstantID = 28210;
				break;
			case "Rail_Search":
				strPageName = "Rail Search";
				SecurityConstantID = 400390;
				break;
			case "NCOA_Address_Export":
				strPageName = "NCOA Address Export";
				SecurityConstantID = 28260;
				break;
			case "Bulk_Service_Replacement":
				strPageName = "Bulk Service Replacement";
				SecurityConstantID = 400460;
				break;
			case "Batch_Status_Update":
				strPageName = "Batch Status Update";
				SecurityConstantID = 400600;
				break;
			case "Flight_Search":
				strPageName = "Flight Search";
				SecurityConstantID = 400690;
				break;
			case "Booked_Service_Search":
				strPageName = "Booked Service Search";
				SecurityConstantID = 400470;
				break;
			//BOC Harshad(54)
			case "Book_Promotional_Package":
				strPageName = "Book Promotional Package";
				SecurityConstantID = 402720;
				break;
			//EOC Harshad(54)
			//BOC kartheek(58)
			case "New_Enquiry":
				strPageName = "New Enquiry";
				SecurityConstantID = 402170;
				break;

			case "Enquiry_Search":
				strPageName = "Enquiry Search";
				SecurityConstantID = 402180;
				break;
			//EOC kartheek(58)
			//BOC Ravish(51)
			case "Purchase_Space_Management":
				strPageName = "Purchase Space Management";
				SecurityConstantID = 403060;
				break;
			//EOC Ravish(51)

			//BOC Harshad(60)
			case "Flight_Hotel_Search":
				strPageName = "Flight & Hotel Search";
				SecurityConstantID = 403650;
				break;
			//EOC Harshad(60)

			//BOC Shradha(67)
			case "Generate_Xml":
				strPageName = "Generate XMLs";
				SecurityConstantID = 21100;
				break;
			//EOC Shradha(67)
			//BOC Dejalin(65)
			case "Operations_Module":
				strPageName = "Operations Module";
				SecurityConstantID = 404920;
				break;
			//EOC Dejalin(65)
			//BOC Tejas(74)
			case "Rail_CheckIn":
				strPageName = "Rail Check In";
				SecurityConstantID = 28310;
				break;
			//EOC Tejas(74)

			//BOC Harshad(75)
			case "Dynamic_Package_Search":
				strPageName = "Dynamic Package Search";
				SecurityConstantID = 403750;
				break;
			//EOC Harshad(75)
			//BOC Omkar N.(80)
			case "Expiring_Options":
				strPageName = "Expiring Options";
				SecurityConstantID = 406930;
				break;
			//EOC Omkar N.(80)
			case "Batch_Message_Generation":
				strPageName = "Batch Message Generator";
				SecurityConstantID = 400480; //Priya
				break;

			//BOC Purva(73)
			case "Batch_Booking_Task_Generation":
				strPageName = "Batch Booking Task Generation";
				SecurityConstantID = 403580;
				break;
			//EOC Purva(73)
			#endregion
			#region Quotes
			case "New_Quote":
				strPageName = "New Quote";
				SecurityConstantID = 21020;
				break;
			case "Quote_Search":
				strPageName = "Quote Search";
				SecurityConstantID = 21030;
				break;
			case "Quote_Default":
				strPageName = "Quote Default";
				SecurityConstantID = 21040;
				break;
			#endregion
			#region Packages
			case "New_Package":
				strPageName = "New Package";
				SecurityConstantID = 21050;
				break;
			case "Package_Find":
				strPageName = "Package Find";
				SecurityConstantID = 21060;
				break;
			case "Package_Maintenance":
				strPageName = "Package Maintenance";
				break;
			case "Package_Data":
				strPageName = "Package Data";
				SecurityConstantID = 21090;
				break;
			case "Package_Brochure":
				strPageName = "Package Brochure";
				SecurityConstantID = 23140;
				break;
			case "Waitlist_Maintenance":
				strPageName = "Waitlist Maintenance";
				SecurityConstantID = 23160;
				break;
			case "Batch_Package_Sell_Price_Creation":
				strPageName = "Batch Package Sell Price Creation";
				SecurityConstantID = 23170;
				break;
			case "Package_Facilities":
				strPageName = "Package Facilities";
				SecurityConstantID = 23180;
				break;
			case "Pattern_Splitting_Wizard":
				strPageName = "Pattern Splitting Wizard";
				SecurityConstantID = 401630;
				break;
			case "Batch_Service_Details_Update":
				strPageName = "Batch Service Details Update";
				SecurityConstantID = 401640;
				break;
			case "Update_Departure_Cost":
				strPageName = "Update Departure Cost";
				break;
			case "Package_Inventory":
				strPageName = "Package Inventory";
				SecurityConstantID = 23190;
				break;
			case "Departure_Find":
				strPageName = "Departure Find";
				SecurityConstantID = 21070;
				break;

			case "Package_Pricing_Analysis_Module":
				strPageName = "Package Pricing Analysis Module";
				SecurityConstantID = 406070;//Nagesh(73)                  
				return CheckRights(new List<string> { strPageName }, new List<int> { SecurityConstantID }); //Sneha S.(76)
				break;
			//BOC Suchina(81)
			case "Bulk_Price_Adjustment":
				strPageName = "Bulk Price Adjustments";
				SecurityConstantID = 406960;                
				
				break;
			//EOC Suchina(81)
			#endregion
			#region Clients
			case "Agent":
				strPageName = "Client";
				SecurityConstantID = 23020;
				break;
			case "Agent_Group":
				strPageName = "Client Group";
				SecurityConstantID = 23100;
				break;
			case "Agent_Group_Commission_Update":
				strPageName = "Agent Group Commission Update";
				SecurityConstantID = 400420;
				break;
			case "Agent_Import":
				strPageName = "Agent Import";
				SecurityConstantID = 400430;
				break;
			case "New_Client_Credit":
				strPageName = "New Client Credit";
				break;
			case "Search_Client_Credit":
				strPageName = "Access To Client Credits Interface";
				SecurityConstantID = 400670;
				break;
			case "Default_Price_Type":
				strPageName = "Default Price Type";
				SecurityConstantID = 22020;
				break;
			case "Merge_Passenger_Bookings":
				strPageName = "Merge Passenger Bookings";
				SecurityConstantID = 400080;
				break;

			case "Passenger":
				strPageName = "Passenger Maint.";
				SecurityConstantID = 27100;
				break;
			case "Marketing_Survey_Import":
				strPageName = "Marketing Survey Import";
				SecurityConstantID = 401190;
				break;
			case "Passenger_Maintenance":
				strPageName = "Passenger Maint.";
				SecurityConstantID = 27100;
				break;

			case "Agent_Portal": //Deepa(16)Put under condition since Agent Portal Settings Page not use in TS
			  
				strPageName = "Agent_Portal";
				SecurityConstantID = (int)enmClientMenu.Agent_Portal_Settings;//EOC Nasia(72)
				if (strPageName == "Agent_Portal")
				{
					return true;
				}
				else
				{

					return UserSecurity.GetMenuAccessRights("", strPageName, SecurityConstantID);
				}
				break;

			#endregion
			#region Products
			case "Supplier":
				strPageName = "Supplier";
				SecurityConstantID = 23000;
				break;
			case "Service":
				strPageName = "Service";
				SecurityConstantID = 23010;
				break;
			case "Contract":
				strPageName = "Contract";
				SecurityConstantID = 23030;
				break;
			case "Villa_Group":
				strPageName = "Villa Group";
				SecurityConstantID = 28170;
				break;
			case "Option":
				strPageName = "Option"; //(30)
				SecurityConstantID = 23050;
				break;
			case "Extra":
				strPageName = "Extra"; //(30)
				SecurityConstantID = 23060;
				break;
			case "Facilities":
				strPageName = "Facilities";//(30)
				SecurityConstantID = 23070;
				break;
			case "Rating":
				strPageName = "Service Type Rating"; //(30)
				SecurityConstantID = 23080;
				break;
			case "Child_Policy":
				strPageName = "Child Policy";
				SecurityConstantID = 23040;
				break;
			case "Supplier_Group":
				strPageName = "Supplier Group";
				SecurityConstantID = 23090;
				break;
			case "Batch_Selling_Price_Creation":
				strPageName = "Batch Selling Price Creation";
				SecurityConstantID = 23110;
				break;
			case "Batch_Price_Type_Associator":
				strPageName = "Batch Price Type Associator";
				SecurityConstantID = 400030;
				break;
			case "Batch_Rule_Generation":
				strPageName = "Batch Rule Generation";
				SecurityConstantID = 400171;
				break;
			case "Rail_Manager":
				strPageName = "Rail Manager";
				SecurityConstantID = 400172;
				break;
			case "Allocation_Name":
				strPageName = "Allocation Name";
				SecurityConstantID = 20060;
				break;
			case "Web_Passenger_Questions":
				strPageName = "Web Passenger Questions";
				SecurityConstantID = 23120;
				break;
			case "Service_Type_Questions":
				strPageName = "Service Type Questions";
				SecurityConstantID = 23130;
				break;
			case "Cancellation_Policies":
				strPageName = "Cancellation Policies";
				SecurityConstantID = 23150;
				break;
			case "Service_Pricing":
				strPageName = "Service";
				SecurityConstantID = 23010;
				break;
			//Vimlesh
			//BOC
			//case "Access_to_Mandatory_Services":
			//    strPageName = "Access to Mandatory Services";
			//    SecurityConstantID = 28190;
			//    break;
			case "Mandatory_Services_Access":
				strPageName = "Mandatory Services";	//Nikita()
				SecurityConstantID = 28190;
				break;
			//EOC
			case "Service_Export_Import":
				strPageName = "Service Export/Import";
				SecurityConstantID = 28200;
				break;
			case "Villa_Room_Name":
				strPageName = "Villa Room Name";
				SecurityConstantID = 28220;
				break;
			case "Update_Booking_Costs":
				strPageName = "Update Booking Costs";
				SecurityConstantID = 400040;
				break;
			case "Supplier_Extranet_Messages":
				strPageName = "Supplier Extranet Messages";
				SecurityConstantID = 400170;
				break;
			case "Yield_Rule_Setup":
				strPageName = "Yield Rule Setup";
				SecurityConstantID = 402290;
				break;
			case "Query_Tool":
				strPageName = "Query Tool";
				SecurityConstantID = 402300;
				break;
			//Boc Shivanand(11)
			case "Instalment_Discounts":
				strPageName = "Instalment Discounts";
				SecurityConstantID = 28480;
				break;

			case "Batch_Instalment_Generator":
				strPageName = "Batch Instalment Generator";
				SecurityConstantID = 28470;
				break;
			//Eoc Shivanand(11)
			case "Availability_Updater":  //Kedar(22)
				strPageName = "Availability Updater";
				SecurityConstantID = 402430;
				break;
			//BOC Vikrant(58)
			case "Supplier_Servcie_Document":
				strPageName = "Supplier Service Document";
				SecurityConstantID = 404800; // Devadree(68)
				break;
			//EOC Vikrant(58)
			//BOC Clerance(53)
			case "Bulk_Contract_Maintenance":
				strPageName = "Bulk Contract Maintenance";
				SecurityConstantID = 403560;
				break;
			case "Bulk_Contract_Maintenance_History":
				strPageName = "Bulk Contract Maintenance History";
				SecurityConstantID = 403570;
				break;
			//EOC Clerance(xx) 
			//BOC Sujata(54)
			case "Offline_Price_Editor":
				strPageName = "Offline Price Editor";
				SecurityConstantID = 403590;
				if(UserSecurity.GetMenuAccessRights("", strPageName, SecurityConstantID))
					return true;                 
				SecurityConstantID = 403600;
				break;           
			//EOC Sujata(54)
			//BOC Omkar N.(81)
			case "Discount":
				strPageName = "Discount";
				SecurityConstantID = 406840;
				if (UserSecurity.GetMenuAccessRights("", strPageName, SecurityConstantID))
					return true;
				break;
			//EOC Omkar N.(81)
			#endregion
			#region Flights
			case "Airlines":
				strPageName = "Airlines";
				SecurityConstantID = 28150;
				break;
			case "Flight_Cities":
				strPageName = "Flight Cities";
				SecurityConstantID = 28160;
				break;

			case "Flight_Schedule_Utility":
				strPageName = "Flight Schedule Utilty";
				SecurityConstantID = 400060;
				break;
			case "Update_FSDT_Flight_Booking_Details":
				strPageName = "Update FSDT Flight Booking Details";
				SecurityConstantID = 400180;
				break;
			case "TermsAndConditions":
				strPageName = "Terms & Conditions"; //Wayne(26)
				SecurityConstantID = 402600;
				break;
			//BOC Wayne(23)
			case "Special_Requests":
				strPageName = "Special Requests";
				SecurityConstantID = 402550;
				break;
			//EOC Wayne(23)
			//BOC Kalpi(41)
			case "Flight_Service_Fees":
				strPageName = "Flight Service Fees";
				SecurityConstantID = 402780;
				break;
			//EOC Kalpi(41)
			//BOC Reema(47)
			case "Fare_Rules_Configuration":
				strPageName = "Fare Rules Configuration";
				SecurityConstantID = 402880;  //Reema(48)
				break;
			//EOC Reema(47)
			//BOC Reema(49)
			case "MarkUp_Rule_Priorities":
				strPageName = "Markup Rule Priorities";  //Reema(53)
				SecurityConstantID = 402890;  //Reema(49)
				break;
			//EOC Reema(49)
			//BOC Sandip P.(50)
			case "Fare_Increase_Decrease_Handling":
				strPageName = "Fare Increase/Decrease Handling";
				SecurityConstantID = 403030;
				break;
			//EOC Sandip P.(50)
			//BOC Ashley(55)
			case "Agent_MarkUp_On_Service_Fee":
				strPageName = "Agent Markup on Service Fee";
				SecurityConstantID = 28630;
				break;
			//EOC Ashley(55) 
			//BOC Rejeena
			case "Agent_Flights_Commission":
				strPageName = "Agent Flights Commission";
				SecurityConstantID = 403040;
				break;
			//EOC Rejeena 

			//BOC Poonam(60)
			case "Airports":
				strPageName = "Airports";
				SecurityConstantID = 28160;
				break;
			//EOC Poonam(60)

			//BOC Siddhi B(74)
			case "Schedule_Change_Manager":
				strPageName = "Schedule Change Manager";
				SecurityConstantID = 406620;
				break;
			//EOC Siddhi B(74)			
			
			#endregion
			#region Program
			case "Calculator":
				strPageName = "";
				break;
			case "Notepad":
				strPageName = "";
				break;
			case "Task_Manager":
				strPageName = "Task Manager";
				SecurityConstantID = 22050;
				break;
			case "Word":
				strPageName = "";
				break;
			case "Excel":
				strPageName = "";
				break;
			case "Internet_Explorer":
				strPageName = "";
				break;
			#endregion
			#region Reports
			case "Generate_Report":
				strPageName = "Generate Report";
				break;
			//BOC Harshad(63)
			case "Report_Generation_Restrictions":
				strPageName = "Report Generation Restrictions";
				break;
			//EOC Harshad(63)

			//BOC Pradnya(65)
			case "Report_Schedule":
				strPageName = "Report Schedule";
				break;
			
			//BOC Nagesh(74)
			case "Unsent_Messages":
				strPageName = "Unsent Messages";
				SecurityConstantID = 28130; // Sunil (75) 
			   
				break;
			//EOC Nagesh(74)
			//BOC Sunil(1043)
			case "Manage_Reports":
				strPageName = "Manage Reports";
				return CheckRightsForManageReports(strPageName, 25030, 25050);
				break;
			//EOC Sunil(1043)
			//BOC Sajjan H ()
			case "Generate_Manifest":
				strPageName = "Generate Manifest";
				//SecurityConstantID = 406940;
				return true;
				break;
				
			//EOC  Sajjan H ()
			//case "Service_Report_Screen":
			//    strPageName = "";
			//    break;
			//case "Supplier_Report_Screen":
			//    strPageName = "Supplier Report Screen";
			//    break;
			//case "Tariff_Export_Report_Screen":
			//    strPageName = "Tariff Export Report Screen";
			//    break;
			//case "Finance_Report_Screen":
			//    strPageName = "Finance Report Screen";
			//    break;
			//case "Quote_Reports_Screen":
			//    strPageName = "Quote Reports Screen";
			//    break;
			//case "Booking_Notes_Report_Screen":
			//    strPageName = "Booking Notes Report Screen";
			//    break;
			case "Report_Group":
				strPageName = "Report Group";
				SecurityConstantID = 25050;
				break;
			case "Report_Registration":
				strPageName = "Report Registration";
				SecurityConstantID = 25030;
				break;
			//case "Package_Report_Screen":
			//    strPageName = "Package Report Screen";
			//    break;
			//case "Flight_Report_Screen":
			//    strPageName = "Flight Report";
			//    break;
			//case "Allocation_Usage_Graph_Report_Screen":
			//    strPageName = "Allocation Usage Graph Report Screen";
			//    break;
			//case "Agent_Report_Options_Screen":
			//    strPageName = "";
			//    break;
			//case "Rail_Report_Screen":
			//    strPageName = "Rail Report Screen";
			//    break;
			//case "AutoMessaging_Failed_Messages":
			//    strPageName = "AutoMessaging Failed Messages";
			//    break;
		
			#endregion
			#region Account
			case "Export_Financial_Details":
				strPageName = "Export Financial Details";
				SecurityConstantID = 24000;
				break;
			case "Batch_Invoice_Creation":
				strPageName = "Batch Invoice Creation";
				SecurityConstantID = 24020;
				break;
			case "Purchase_Invoice_Creation":
				strPageName = "Purchase Invoice Creation";
				SecurityConstantID = 24010;
				break;
			//BOC Anshul(77)
			case "Purchase_Invoice_Import":
				strPageName = "Purchase Invoice Import";
				SecurityConstantID = 24080;
				break;
			//EOC Anshul(77)
			case "Reprint_Invoices":
				strPageName = "Reprint Invoices";
				SecurityConstantID = 24040;
				break;
			case "Batch_Voucher_Close":
				strPageName = "BATCH VOUCHER CLOSE";
				SecurityConstantID = 24050;
				break;
			case "Exchange_Rates":
				strPageName = "Exchange Rates";
				SecurityConstantID = 24030;
				break;
			case "Batch_Receipts_Entry"://Amey.R(61) //Gautami(62)
				strPageName = "Batch Receipts Entry";
				SecurityConstantID = 28240;
				break;
			case "Tax_Codes":
				strPageName = "Tax Codes";
				SecurityConstantID = 22010;
				break;
			case "Currency":
				strPageName = "Currency";
				SecurityConstantID = 20090;
				break;
			case "Create_GL_Accounts":
				strPageName = "Create GL Accounts";
				SecurityConstantID = 24070;
				break;
			case "Check_Commission_Payments":
				strPageName = "Check Commission Payments";
				SecurityConstantID = 24060;
				break;
			case "Access_to_Commission_Margin_Setup":
				strPageName = "Access to Commission Margin Setup";
				SecurityConstantID = 28180;
				break;
			case "TIC_Insurance_Export":
				strPageName = "TIC Insurance Export";
				SecurityConstantID = 400560;
				break;
			case "Suppliers_Invoice_Submission":
				strPageName = "Suppliers Invoice Submission";
				SecurityConstantID = 400070;
				break;
			case "Banked_Receipts": //Kedar(12)
				strPageName = "Banked Receipts";
				SecurityConstantID = 401830;
				break;
			case "Bank_Profiles": //Sudeep(15)
				strPageName = "Bank Profiles";
				SecurityConstantID = 28490;
				break;
			case "Invoice_Daily_Exchange_Rates"://Pranav(62)
				strPageName = "Invoice Daily Exchange Rates";
				
				SecurityConstantID = 406380;//Lorraine(67)
				//SecurityConstantID = 24030; //Vimlesh(63) Commented and moved down
				//BOC Vimlesh(63)
				enmAccountingExportFileType ExportFileType;
				ExportFileType = (enmAccountingExportFileType)FileTypeID;
				if (ExportFileType == enmAccountingExportFileType.enmLawsonAccounting)
				{
					SecurityConstantID = 24030;
				}
				else
				{
					SecurityConstantID = 0;
				}
				//EOC Vimlesh(63)
				break;
			case "Refund_Export":
				SecurityConstantID = 407010;
				strPageName = "Refund Export";
				break;
			//BOC Poonam(82)
			case "Receipts_Reconciliation":
				strPageName = "Receipts Reconciliation";
				SecurityConstantID = 28330;
				break;
			//BOC Poonam(82)
			#endregion
			#region Fulfillment
			case "Create_Document_Packages":
				strPageName = "Create Document Packages";
				SecurityConstantID = 27070;
				break;
			case "Print_Document_Packages":
				strPageName = "Print Document Packages";
				SecurityConstantID = 27080;
				break;
			case "MessageEditor":
				strPageName = "Message Editor";
				SecurityConstantID = 27120;
				break;
			case "Mail_Shot":
				strPageName = "Mail Shot";
				SecurityConstantID = 28120;
				break;
			//case "Batch_Message_Generation":
			//    strPageName = "Batch Message Generation";
			//    SecurityConstantID = 400480;
			//    break;
			case "Manual_Manifest_Generation":
				strPageName = "Manual Manifest Generation";
				SecurityConstantID = 401660;
				break;
			#endregion
			#region Setup
			case "Server_Setup":
				strPageName = "";
				SecurityConstantID = 26000;
				break;
			case "Web_Server_Setup":
				strPageName = "";
				SecurityConstantID = 26010;
				break;
			case "Setup_Debug_Mode":
				strPageName = "";
				break;
			#endregion
			#region Training
			case "Search_Service":
				strPageName = "ServiceSearch";
				SecurityConstantID = 301110;
				break;
			#endregion
			//BOC Sahil(75)
			#region Cache
			case "Cache_Rules":
				SecurityConstantID = 406740;
				break;
			case "Cache_Search_Criteria":
				SecurityConstantID = 406740;
				break;
			case "Remote_Services":
				SecurityConstantID = 406740;
				break;
			case "Cache_Statistics":
				SecurityConstantID = 406740;
				break;
			#endregion Cache
			//EOC Sahil(75)
		}
		//BOC Sarika(18)
		////if (strPageName == "Reset Cache") //Nasia(72) Commented since was always returning true
		////    return true;
		//EOC Sarika(18)

		//// //BOC Rejeena
		////   if (strPageName == "Agent Flights Commission")
		////   return true;
		//////EOC Rejeena

		//BOC Wayne(35)
		//if (strPageName == "About")//Nasia(72) Commented since was always returning true
		//    return true;
		//EOC Wayne(35)

		//BOC Silvia(20)
		if (strPageName == "Generate Report")
			return CheckReportsPermission();
		//EOC silvia(20)

		//BOC Vimlesh(61)
		#region Commented Code
		////BOC Sandip P.(42)
		//if (strPageName == "Location")
		//    return true;
		////EOC Sandip P.(42)
		////BOC Sandip P.(50)
		//if (strPageName == "Fare Increase/Decrease Handling")
		//    return true;
		////EOC Sandip P.(50)
		#endregion Commented Code
		//EOC Vimlesh(61)
		return UserSecurity.GetMenuAccessRights("", strPageName, SecurityConstantID);

	}
	
	private bool CheckRightsForManageReports(string strPageName, int ReportRegistrationSecurityConstantID, int ReportGroupsSecurityConstantID)
	{
		bool hasAccessRightsReportRegistration = UserSecurity.GetMenuAccessRights("", strPageName, ReportRegistrationSecurityConstantID);
		bool hasAccessRightsReportGroups = UserSecurity.GetMenuAccessRights("", strPageName, ReportGroupsSecurityConstantID);
		return (hasAccessRightsReportRegistration || hasAccessRightsReportGroups);
	}



	//BOC Sneha S.(76)
	private bool CheckRights(List<string> pageNames, List<int> securityConstants)
	{
		bool hasAccess = true;
		int i = 0;
		foreach (int securityConstant in securityConstants)
		{
			hasAccess = UserSecurity.GetMenuAccessRights("", pageNames[i], securityConstant);

			if (hasAccess && securityConstant == 406070)//Amrapali(80)
			{

					hasAccess = GetPackagePricingAnalysisFlag();
			}

			if (!hasAccess)
				break;

			i++;
		}
		return hasAccess;
	}
	//EOC Sneha S.(76)

 
 

	#region Sub Menu Enums
	public enum SubMenuKeySystem
	{
		GeoTree = 1,
		Country = 2,
		Statuses = 3,
		Types = 4,
		Charging_Duration = 5,
		Image = 6,
		Meal_Plan = 7,
		Message_Editor = 8,
		Auto_Messaging = 9,
		Rules = 10,
		User_Manager = 11,
		Organisation = 12,
		Mileage_Map = 13,
		Commission_Maintenance = 14,
		Default_Booking_Tasks = 15,
		Messaging_Settings = 16,
		End_Point_Configuration = 17,
		Import_External_Services = 18,
		QA_Scripts = 19,
		Charging_Policy = 20,
		Status_Maintenance = 21,
		Types_Maintenance = 22,
		Messaging = 23,
		Reset_Cache = 24, //Sarika(18)
		About = 25, // Wayne(35)
		Location = 26,  //Sandip P.(42)
		Price_Update_Status = 27,//Vikrant(59)
		Task_Lists = 28 , //Debasis(62)
		ChannelManagerConfiguration=29//CANDIDA (67)
		,RegisterWidgets=30 //PNaik
		,Supplier_Extranet_Settings = 31 //Clerance(76)
		,Areas = 32 //Vaishakhi(82)
		,Document_Template_Library = 33 //Madhu(83) 
		, Document_Component_Section_Library= 34 //Rajesh(84)
		, PricingEstimationDefault = 35
		
		,Queue_Status = 36 //Wayne(82)
	}
	public enum SubMenuKeyBookings
	{
		New_Booking = 1,
		Booking_Find = 2,
		Replicate_Bookings = 3,
		Package_Search = 4,
		Passenger_Maint = 5,
		Commission_Payment_Approval = 6,
		PNR_Shadow_List = 7,
		Expired_Options = 8,
		Villa_Booking = 9,
		Service_Search = 10,
		Booking_Import = 11,
		Rail_Search = 12,
		NCOA_Address_Export = 13,
		Bulk_Service_Replacement = 14,
		Batch_Status_Update = 15,
		Flight_Search = 16,
		Booked_Service_Search = 17,
		Task_Manager = 18, //Abhijit L.(33)
		Purchase_Space_Management = 19 //Ravish(51)
		,Book_Promotional_Package = 20, //Harshad(54)
		New_Enquiry = 21,    //kartheek(58)
		Enquiry_Search = 22,  //kartheek(58)
		Flight_Hotel_Search = 23, //Harshad(60)
		Generate_Xml = 24, //Shradha(67)
		Operations_Module = 25 //Dejalin(65)
		, Rail_CheckIn = 26 //Tejas(74)
		,Dynamic_Package_Search = 27 //Harshad(75)
		,Expiring_Options= 28 //Omkar N.(80)
		,Batch_Message_Generation = 29 //Priya
		,Batch_Booking_Task_Generation = 30      //Purva(73)
	}
	public enum SubMenuKeyQuotes
	{
		New_Quote = 1,
		Quote_Search = 2,
		Quote_Default = 3
	}
	public enum SubMenuKeyPackage
	{
		New_Package = 1,
		Package_Find = 2,
		Package_Maintenance = 3,
		Package_Data = 4,
		Package_Brochure = 5,
		Waitlist_Maintenance = 6,
		Batch_Package_Sell_Price_Creation = 7,
		Package_Facilities = 8,
		Pattern_Splitting_Wizard = 9,
		Batch_Service_Details_Update = 10,
		Update_Departure_Cost = 11,
		Package_Inventory = 12,
		Pricing_Analysis = 13,
		Departure_Find=14,
		Package_Pricing_Analysis_Module = 15,
		Bulk_Price_Adjustment = 16//Suchina(81)
	}
	public enum SubMenuKeyClients
	{
		Agent = 1,
		Agent_Group = 2,
		Agent_Group_Commission_Update = 3,
		Agent_Import = 4,
		New_Client_Credit = 5,
		Search_Client_Credit = 6,
		Default_Price_Type = 7,
		Merge_Passenger_Bookings = 8,
		Passenger = 9,
		Marketing_Survey_Import = 10,
		Passenger_Maintenance = 11,
		Agent_Portal = 12, //Deepa(16)
		MarkUp_Rule_Priorities = 13 //Reema(49)
	}
	public enum SubMenuKeyProduct
	{
		Supplier = 1,
		Service = 2,
		Contract = 3,
		Villa_Group = 4,
		Option = 5,
		Extra = 6,
		Facilities = 7,
		Rating = 8,
		Child_Policy = 9,
		Supplier_Group = 10,
		Batch_Selling_Price_Creation = 11,
		Batch_Price_Type_Associator = 12,
		Batch_Rule_Generation = 13,
		Rail_Manager = 14,
		Allocation_Name = 15,
		Web_Passenger_Questions = 16,
		Service_Type_Questions = 17,
		Cancellation_Policies = 18,
		Service_Pricing = 19,
		//Access_to_Mandatory_Services = 20,//Vimlesh
		Mandatory_Services_Access = 20,//Vimlesh
		Service_Export_Import = 21,
		Villa_Room_Name = 22,
		Update_Booking_Costs = 23,
		Supplier_Extranet_Messages = 24,
		Yield_Rule_Setup = 25,
		Query_Tool = 26,
		Instalment_Discounts = 27,//Shivanand(11)
		Batch_Instalment_Generator = 28,//Shivanand(11)
		Availability_Updater = 29, //Kedar(22)
		Supplier_Servcie_Document = 30//Vikrant(58)
		,
		Bulk_Contract_Maintenance = 31 //Clerance(53)
			, Bulk_Contract_Maintenance_History = 32 //Clerance(53)
		,Offline_Price_Editor=33 //Sujata(54)
		, Discount = 34 //Omkar N.(81)
	}
	public enum SubMenuKeyFlights
	{
		Airlines = 1,
		Flight_Cities = 2,
		Special_Requests = 3,
		Flight_Schedule_Utility = 4,
		Update_FSDT_Flight_Booking_Details = 5,
		TermsAndConditions = 6,
		Flight_Service_Fees = 7, //Kalpi(41)
		Fare_Rules_Configuration = 8, //Reema(47)
		MarkUp_Rule_Priorities = 9,//Reema(49)
		Fare_Increase_Decrease_Handling = 10, //Sandip P.(50)
		Agent_Flights_Commission = 11,//Rejeena
		Agent_MarkUp_On_Service_Fee = 12, //Ashley(55)
		Airports=13, //Poonam(60)
		Schedule_Change_Manager=14 //Siddhi B(74)
	}
	public enum SubMenuKeyProgram
	{
		Calculator = 1,
		Notepad = 2,
		Task_Manager = 3,
		Word = 4,
		Excel = 5,
		Internet_Explorer = 6
	}
	public enum SubMenuKeyReport
	{
		Generate_Report = 1,
		Booking_Report_Screen = 2,
		Service_Report_Screen = 3,
		Supplier_Report_Screen = 4,
		Tariff_Export_Report_Screen = 5,
		Finance_Report_Screen = 6,
		Quote_Reports_Screen = 7,
		Booking_Notes_Report_Screen = 8,
		Report_Group = 9,
		Report_Registration = 10,
		Package_Report_Screen = 11,
		Flight_Report_Screen = 12,
		Allocation_Usage_Graph_Report_Screen = 13,
		Agent_Report_Options_Screen = 14,
		Rail_Report_Screen = 15,
		AutoMessaging_Failed_Messages = 16
		 , Report_Generation_Restrictions = 17//Harshad(63)
		, Report_Schedule = 18 //Pradnya(65)
		, Unsent_Messages = 19//Amrapali(73)
		, Manage_Reports = 20 // Sunil
		,Generate_Manifest = 21 //Diptesh H() / Sajjan H
	}
	public enum SubMenuKeyAccount
	{
		Export_Financial_Details = 1,
		Batch_Invoice_Creation = 2,
		Purchase_Invoice_Creation = 3,
		Reprint_Invoices = 4,
		Batch_Voucher_Close = 5,
		Exchange_Rates = 6,
		Batch_Receipts_Entry = 7,//Amey.R(61) //Gautami(62)
		Tax_Codes = 8,
		Currency = 10,
		Create_GL_Accounts = 11,
		Check_Commission_Payments = 12,
		Access_to_Commission_Margin_Setup = 13,
		TIC_Insurance_Export = 14,
		Suppliers_Invoice_Submission = 15,
		Banked_Receipts = 16, //Kedar(12)  
		Bank_Profiles = 17, //Sudeep(15)
		Invoice_Daily_Exchange_Rates = 18 //Pranav(62)
		, Purchase_Invoice_Import = 19//Anshul(77)
		,Refund_Export = 20 //Utkarsha(70)
		,Receipts_Reconciliation =21 //Poonam(82)
	}
	public enum SubMenuKeyFulfillment
	{
		Create_Document_Packages = 1,
		Print_Document_Packages = 2,
		MessageEditor = 3,
		Mail_Shot = 4,
		Batch_Message_Generation = 5,
		Manual_Manifest_Generation = 6
	}
	public enum SubMenuKeySetup
	{
		Server_Setup = 1,
		Web_Server_Setup = 2,
		Setup_Debug_Mode = 3
	}
	public enum SubMenuKeyTraining
	{
		Search_Service = 1
	}
	//BOC Sahil(75)
	public enum SubMenuKeyCache
	{
		Cache_Rules = 1,
		Cache_Search_Criteria = 2,
		Remote_Services = 3,
		Cache_Statistics = 4
	}
	//EOC Sahil(75)
	#endregion
	//EOC Prasad(05)
	//BOC ashfaq(6)
	public void CreateTempMenu()//Harshad(9)
	{
		bool ShowdvmainMenu = false;
		_menu = new Dictionary<string, VmMenuItem>();
		//create main table containing menu columns 
		HtmlTable htMaintable = new HtmlTable();
		htMaintable.ID = "tblMainForMenu";

		HtmlTableRow htMainMenuRow = new HtmlTableRow();
		htMainMenuRow.ID = "trForMainMenu";

		//top menu will have 6 columns for new menu items grouping
		string[] MainMenuArray = new string[10];
		MainMenuArray[0] = "Training";
		MainMenuArray[1] = "Setup";
		MainMenuArray[2] = "Product";
		MainMenuArray[3] = "Booking";
		MainMenuArray[4] = "CRM";
		MainMenuArray[5] = "Reports";
		MainMenuArray[6] = "Finance";
		MainMenuArray[7] = "Flights";   //Jayesh(17)
		MainMenuArray[8] = "Package";   //Wayne(45)
		//MainMenuArray[9] = "Cache";   //Sahil(75)

		var _mainMenuArray = new[]
		{
			"Setup",
			"Product",
			"Booking",
			"CRM",
			"Reports",
			"Finance",
			"Flights",
			"Package",
			"Cache"
		};

		IEnumerator ieForMainMenu = _mainMenuArray.GetEnumerator();// objMenuHashtable.GetEnumerator();
		#region Main menu items
		while (ieForMainMenu.MoveNext())
		{
			HtmlTableCell htMainMenuCell = new HtmlTableCell();
			htMainMenuCell.Attributes.Add("style", "valign:top;");
			//each menu cell has one div conatining menu
			HtmlGenericControl dvmenuItem = new HtmlGenericControl("div");
			dvmenuItem.Attributes.Add("class", "menu_l2");

			//each div contain two div one for item text and another for all items
			//div for menu text
			HtmlGenericControl dvmenuItemText = new HtmlGenericControl("div");
			dvmenuItemText.Attributes.Add("class", "menu_l2_item");
			dvmenuItemText.InnerText = ieForMainMenu.Current.ToString();
			dvmenuItem.Controls.Add(dvmenuItemText);
			//end div menuitem containing text

			var menuId = ieForMainMenu.Current.ToString();
			_menu.Add(menuId, new VmMenuItem
			{
				DisplayLabel = menuId,
				Label = menuId,
			});

			// div for all sub menu items
			HtmlGenericControl dvSubmenuItem = new HtmlGenericControl("div");

			string leftSubmenutext = ""; //(ieForMainMenu.Current.ToString()).Substring(0, (ieForMainMenu.Current.ToString()).LastIndexOf("_"));
			string rightSubmenutext = "";//(ieForMainMenu.Current.ToString()).Substring(((ieForMainMenu.Current.ToString()).LastIndexOf("_") + 1));
			switch (ieForMainMenu.Current.ToString())
			{
				case "Setup":
					leftSubmenutext = "System";
					rightSubmenutext = "Setup";
					break;
				case "Product":
					leftSubmenutext = "Product";
					//rightSubmenutext = "Package"; //Wayne(45) Commented 
					break;
				case "Booking":
					leftSubmenutext = "Booking";
					break;
				case "CRM":
					leftSubmenutext = "Client";
					rightSubmenutext = "Fulfilment";
					break;
				case "Reports":
					leftSubmenutext = "Reports";

					break;
				case "Finance":
					leftSubmenutext = "Accounts";
					rightSubmenutext = "Finance"; //Virag
					break;
				//BOC Jayesh(17)
				case "Flights":
					leftSubmenutext = "Flights";
					break;
				//EOC Jayesh(17)
				//BOC Wayne(45)
				case "Package":
					leftSubmenutext = "Package";
					break;
				//EOC Wayne(45)
				//BOC Sahil(75)
				case "Cache":
					leftSubmenutext = "Catalog Cache";
					rightSubmenutext = "Cache";
					break;
				//EOC Sahil(75)
				//BOC Ritesh
				case "Training":
					leftSubmenutext = "Training";
					break;
				//EOC Ritesh
			}
			dvSubmenuItem.Attributes.Add("class", "menu_l3");
			//contains table with three cells 
			HtmlTable tblSubMenuitem = new HtmlTable();
			tblSubMenuitem.ID = "tblSubmenuitems";
			tblSubMenuitem.Border = 0;
			tblSubMenuitem.CellPadding = 0;
			tblSubMenuitem.CellSpacing = 0;
			HtmlTableRow trSubMenuitems = new HtmlTableRow();
			IDictionaryEnumerator ieForSubMenus = null;
			//left cell for left menu items
			HtmlTableCell tdForLeftSubMenuItems = new HtmlTableCell();
			//items
			int countOfItems = 0;
			//Hashtable htSubMenuleft = ReturnSubMenuhashTable(leftSubmenutext);

			Hashtable htSubMenuleft1 = ReturnSubMenuhashTable(leftSubmenutext); //Abhijit L.(40)
			IDictionary htSubMenuleft = SortHashtable(htSubMenuleft1); //Abhijit L.(40)                       

			if (htSubMenuleft != null)
			{
				countOfItems = htSubMenuleft.Count;
				ieForSubMenus = htSubMenuleft.GetEnumerator();
				while (ieForSubMenus.MoveNext())
				{
					if (GetPagePermissions(ieForSubMenus.Key.ToString()))
					{
						HtmlGenericControl dvLeftSubmenuItem = new HtmlGenericControl("div");
						dvLeftSubmenuItem.Attributes.Add("class", "menu_l3_item");
						HtmlAnchor haleftMenulink = new HtmlAnchor();
						//BOC Sarika(18)
						if (ieForSubMenus.Key.ToString().Equals("Reset_Cache"))
							haleftMenulink.HRef = "~/Home" + ".aspx?ResetSystemCache=true";
						else//EOC Sarika(18)
							haleftMenulink.HRef = "../Pages/System/" + ".aspx";
						haleftMenulink.Attributes.Add("class", "FrameLink"); //Abhijit L.(21)
						haleftMenulink.Attributes.Add("style", "text-align:left;");
						string[] strSplitedMulitlingualText = GetTextWithToolTip((ieForSubMenus.Value ?? string.Empty).ToString());
						if (strSplitedMulitlingualText != null && strSplitedMulitlingualText.Count() > 0)
						{
							//Sriker(10) Replaced strSplitedMulitlingualText[0] with ieForSubMenus.Key
							if (ieForSubMenus.Key.ToString() == SubMenuKeySystem.Message_Editor.ToString() ||
								   ieForSubMenus.Key.ToString() == SubMenuKeySystem.End_Point_Configuration.ToString() || ieForSubMenus.Key.ToString() == SubMenuKeySystem.Import_External_Services.ToString()
								|| ieForSubMenus.Key.ToString() == SubMenuKeySystem.QA_Scripts.ToString()
								//|| ieForMainMenu.Current.ToString() == "Reports" Silvia
								/*|| ieForMainMenu.Current.ToString() == "Finance"*/ //Virag D.
								|| ieForSubMenus.Key.ToString() == SubMenuKeyProduct.Batch_Price_Type_Associator.ToString()
								//|| ieForSubMenus.Key.ToString() == SubMenuKeyProduct.Rail_Manager.ToString()       //Bhaskar(68) --Commented this line
								|| ieForSubMenus.Key.ToString() == SubMenuKeyProduct.Service_Pricing.ToString()
								//|| ieForSubMenus.Key.ToString() == SubMenuKeyProduct.Access_to_Mandatory_Services.ToString() || ieForSubMenus.Key.ToString() == SubMenuKeyProduct.Service_Export_Import.ToString()//Vimlesh(59)
								|| ieForSubMenus.Key.ToString() == SubMenuKeyProduct.Update_Booking_Costs.ToString() || ieForSubMenus.Key.ToString() == SubMenuKeyClients.Agent_Import.ToString()
								|| ieForSubMenus.Key.ToString() == SubMenuKeyClients.New_Client_Credit.ToString() || ieForSubMenus.Key.ToString() == SubMenuKeyClients.Marketing_Survey_Import.ToString()
								|| ieForSubMenus.Key.ToString() == SubMenuKeyClients.Merge_Passenger_Bookings.ToString() || ieForSubMenus.Key.ToString() == SubMenuKeySystem.Default_Booking_Tasks.ToString()
								|| (ieForMainMenu.Current.ToString() == "Booking" && (ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Booking_Find.ToString() &&
									ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Service_Search.ToString() &&
									ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Package_Search.ToString() &&
									ieForSubMenus.Key.ToString() != SubMenuKeyBookings.New_Booking.ToString() &&
										 ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Flight_Search.ToString() && //Ravish(43)
									ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Commission_Payment_Approval.ToString() && ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Task_Manager.ToString()
									 && ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Generate_Xml.ToString()) //Shradha(67)
									&& ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Booked_Service_Search.ToString()
									 && ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Book_Promotional_Package.ToString() //SiddheshPrb(25) //Abhijit L.(33) //Silvia (34)//Ravish(51) //Harshad(54) - Added Book_Promotional_Package
									 && ieForSubMenus.Key.ToString() != SubMenuKeyBookings.New_Enquiry.ToString() && ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Enquiry_Search.ToString() && ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Rail_Search.ToString() //kartheek(58) //Poornima(71)
									 && ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Operations_Module.ToString())  //Dejalin(65)
									&& ieForSubMenus.Key.ToString() != SubMenuKeyProduct.Bulk_Contract_Maintenance.ToString()
									&& ieForSubMenus.Key.ToString() != SubMenuKeyProduct.Bulk_Contract_Maintenance_History.ToString()
									&& ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Purchase_Space_Management.ToString()              //Ravish(51)
									&& ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Flight_Hotel_Search.ToString()    //Harshad(60)                      
									&& ieForSubMenus.Key.ToString() != SubMenuKeyProduct.Offline_Price_Editor.ToString() //Sujata(54)
								  && ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Rail_CheckIn.ToString()//Tejas(74)
									&& ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Dynamic_Package_Search.ToString()    //Harshad(75)
									&& ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Expiring_Options.ToString() //Omkar N.(80)
								&& ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Batch_Message_Generation.ToString() //Priya
								&& ieForSubMenus.Key.ToString() != SubMenuKeyBookings.Batch_Booking_Task_Generation.ToString()
								 //&& ieForSubMenus.Key.ToString() != SubMenuKeyProduct.Discount.ToString() //Omkar N.(81)
								) //Clerance(53)
								haleftMenulink.Disabled = true;
							haleftMenulink.InnerText = strSplitedMulitlingualText[0];
							if (strSplitedMulitlingualText.Count() > 2)
							{
								haleftMenulink.Attributes.Add("class", "FrameLink"); //Abhijit L.(21)
								haleftMenulink.HRef = strSplitedMulitlingualText[2];
								haleftMenulink.Title = strSplitedMulitlingualText[1];
							}
						}
						else
							haleftMenulink.InnerText = (ieForSubMenus.Value ?? string.Empty).ToString();
						if (!haleftMenulink.Disabled)
						{
							AddToMenu(menuId, haleftMenulink);
							dvLeftSubmenuItem.Controls.Add(haleftMenulink);
							tdForLeftSubMenuItems.Controls.Add(dvLeftSubmenuItem);
						}
					}
				}
			}
			//end items
			trSubMenuitems.Cells.Add(tdForLeftSubMenuItems);
			//end left cell
			//todo: add vertical bar in middle cell
			HtmlTableCell tcMidBar = new HtmlTableCell();
			HtmlImage imgVBar = new HtmlImage();
			imgVBar.Src = "../Masters/Images/vbar.jpg";
			imgVBar.Alt = "Bar";


			// right cell
			HtmlTableCell tdForRightSubMenuItems = new HtmlTableCell();
			tdForRightSubMenuItems.Attributes.Add("style", "padding:2px; border-left: solid 2px #e7e7ff");
			HtmlGenericControl dvRightSubmenuItemHeader = new HtmlGenericControl("div");
			//header
			dvRightSubmenuItemHeader.Attributes.Add("class", "menu_l3_header");
			dvRightSubmenuItemHeader.InnerText = rightSubmenutext;
			tdForRightSubMenuItems.Controls.Add(dvRightSubmenuItemHeader);
			//end header
			//items
			Hashtable htSubMenuright = ReturnSubMenuhashTable(rightSubmenutext);

			if (htSubMenuright != null)
			{
				if (htSubMenuright.Count > countOfItems)
					countOfItems = htSubMenuright.Count;
				ieForSubMenus = htSubMenuright.GetEnumerator();
				while (ieForSubMenus.MoveNext())
				{
					if (GetPagePermissions(ieForSubMenus.Key.ToString()))
					{
						HtmlGenericControl dvrightSubmenuItem = new HtmlGenericControl("div");
						dvrightSubmenuItem.Attributes.Add("class", "menu_l3_item");
						HtmlAnchor harightMenulink = new HtmlAnchor();
						//BOC Sarika(18)
						if (ieForSubMenus.Key.ToString().Equals("Reset_Cache"))
							harightMenulink.HRef = "~/" + ".aspx?ResetSystemCache=true";
						else//EOC Sarika(18)
							harightMenulink.HRef = "../System/" + ".aspx";
						harightMenulink.Attributes.Add("class", "FrameLink"); //Abhijit L.(21)
						harightMenulink.Attributes.Add("style", "text-align:left;");
						string[] strSplitedMulitlingualText = GetTextWithToolTip((ieForSubMenus.Value ?? string.Empty).ToString());
						if (strSplitedMulitlingualText != null && strSplitedMulitlingualText.Count() > 0)
						{
							harightMenulink.InnerText = strSplitedMulitlingualText[0];
							harightMenulink.Disabled = true;
							if (strSplitedMulitlingualText.Count() > 2)
							{
								harightMenulink.Attributes.Add("class", "FrameLink"); //Abhijit L.(21)
								harightMenulink.HRef = strSplitedMulitlingualText[2];
							}
						}
						else
							harightMenulink.InnerText = (ieForSubMenus.Value ?? string.Empty).ToString();
						dvrightSubmenuItem.Controls.Add(harightMenulink);
						tdForRightSubMenuItems.Controls.Add(dvrightSubmenuItem);
					}
				}
				//only add when there are two cols
				//trSubMenuitems.Cells.Add(tcMidBar);
				//tcMidBar.Controls.Add(imgVBar);

				trSubMenuitems.Cells.Add(tdForRightSubMenuItems);
			}
			imgVBar.Width = 3;
			imgVBar.Height = countOfItems * 29;

			//end items

			//End right cell
			tblSubMenuitem.Rows.Add(trSubMenuitems);
			dvSubmenuItem.Controls.Add(tblSubMenuitem);
			// end div with all sub menu

			//add sub menu containing div to menu div
			dvmenuItem.Controls.Add(dvSubmenuItem);

			// add menu containing div to cell
			htMainMenuCell.Controls.Add(dvmenuItem);
			//add cell in row
			if (tdForLeftSubMenuItems.Controls.Count >= 1 || tdForRightSubMenuItems.Controls.Count > 1)
				htMainMenuRow.Cells.Add(htMainMenuCell);
		}

		#endregion Main menu items
		htMaintable.Rows.Add(htMainMenuRow);
		plcForMenutable.Controls.Add(htMaintable);
	}

	private Hashtable ReturnSubMenuhashTable(string mainMenu)
	{
		Hashtable htReturn = null;
		bool bRailDisplayFlag = false;
		bool bEnableOperationalModuleFlag = false; //Dejalin(65)
		string mm = (mainMenu ?? string.Empty).ToLower();
		switch (mm)
		{
			case "system":
				#region SYSTEM SUB MENU
				//System Menu
				//Hashtable for System menu
				Hashtable systemHashtable = new Hashtable();
				systemHashtable.Add(SubMenuKeySystem.GeoTree.ToString(), "Geo Tree");
				systemHashtable.Add(SubMenuKeySystem.Country.ToString(), "Country");
				systemHashtable.Add(SubMenuKeySystem.Statuses.ToString(), "Statuses");
				systemHashtable.Add(SubMenuKeySystem.Types.ToString(), "Types");
				systemHashtable.Add(SubMenuKeySystem.Charging_Duration.ToString(), "Charging Duration");
				systemHashtable.Add(SubMenuKeySystem.Charging_Policy.ToString(), "Charging Policy");
				systemHashtable.Add(SubMenuKeySystem.Image.ToString(), "Image");
				systemHashtable.Add(SubMenuKeySystem.Meal_Plan.ToString(), "Meal Plan");
				//  systemHashtable.Add(SubMenuKeySystem.Meal_Plan1.ToString(), "Meal Plan1");
				systemHashtable.Add(SubMenuKeySystem.Message_Editor.ToString(), "Message Editor");
				systemHashtable.Add(SubMenuKeySystem.Rules.ToString(), "Rules");
				systemHashtable.Add(SubMenuKeySystem.User_Manager.ToString(), "User Manager");
				systemHashtable.Add(SubMenuKeySystem.Organisation.ToString(), "Organisation");
				systemHashtable.Add(SubMenuKeySystem.Mileage_Map.ToString(), "Mileage Map");
				systemHashtable.Add(SubMenuKeySystem.Commission_Maintenance.ToString(), "Commission Maintenance");
				systemHashtable.Add(SubMenuKeySystem.Default_Booking_Tasks.ToString(), "Default Booking Task");
				systemHashtable.Add(SubMenuKeySystem.Messaging_Settings.ToString(), "Messaging Settings");
				systemHashtable.Add(SubMenuKeySystem.End_Point_Configuration.ToString(), "End Point Configuration");
				systemHashtable.Add(SubMenuKeySystem.Import_External_Services.ToString(), "Import External Services");
				systemHashtable.Add(SubMenuKeySystem.QA_Scripts.ToString(), "QA Scripts");
				systemHashtable.Add(SubMenuKeySystem.Reset_Cache.ToString(), "Reset Cache");//Sarika(18)
				systemHashtable.Add(aboutTabString,aboutTabString); //Wayne(35) //Nasia(73)
				systemHashtable.Add(SubMenuKeySystem.Location.ToString(), "Location"); //Sandip P(42)
				systemHashtable.Add(SubMenuKeySystem.Price_Update_Status.ToString(), "Price Update Status"); //Vikrant(59)
				systemHashtable.Add(SubMenuKeySystem.ChannelManagerConfiguration.ToString(), "Channel Manager Configuration");//CANDIDA(67)
				systemHashtable.Add(SubMenuKeySystem.RegisterWidgets.ToString(), "Register Widgets");//Pnaik(xx)
				systemHashtable.Add(SubMenuKeySystem.Supplier_Extranet_Settings.ToString(), "Supplier Extranet Settings");//Clerance(76)
				systemHashtable.Add(SubMenuKeySystem.Areas.ToString(), "Areas");//Vaishakhi(82)
				systemHashtable.Add(SubMenuKeySystem.Document_Template_Library.ToString(), "Document Template Library");//Madhu(83)
				systemHashtable.Add(SubMenuKeySystem.Document_Component_Section_Library.ToString(), "Document Component Section Library");//Rajesh(84)
				systemHashtable.Add(SubMenuKeySystem.PricingEstimationDefault.ToString(), "Pricing Estimation Default");
				systemHashtable.Add(SubMenuKeySystem.Queue_Status.ToString(), "Queue Status");//Wayne(82)
				//BOC Rejeena(64)
				  DataClasses.SecurityClasses.UserRight objUserRights = SecurityManager.UserSecurity.GetAccessRights((int)enmTaskList.TaskList);
				  if (objUserRights != null && objUserRights.Access)
				  {
					  systemHashtable.Add(SubMenuKeySystem.Task_Lists.ToString(), "Task Lists"); //Debasis(62)
				  }
				//EOC Rejeena(64)s
				//systemHashtable.Add("Geotree3", "Geotree - Asp controls");
				systemHashtable = Base.GetMultilingualMessageList("Menu", systemHashtable);
				systemHashtable[SubMenuKeySystem.GeoTree.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.GeoTree.ToString()]) + "||../Pages/System/GeoTree.aspx";
				systemHashtable[SubMenuKeySystem.Country.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Country.ToString()]) + "||../Pages/System/Country.aspx";
				systemHashtable[SubMenuKeySystem.Statuses.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Statuses.ToString()]) + "||../Pages/Product/Status.aspx";
				systemHashtable[SubMenuKeySystem.Types.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Types.ToString()]) + "||../Pages/Product/Types.aspx";
				systemHashtable[SubMenuKeySystem.Charging_Duration.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Charging_Duration.ToString()]) + "||../Pages/Product/ChargingDuration.aspx";
				systemHashtable[SubMenuKeySystem.Charging_Policy.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Charging_Policy.ToString()]) + "||../Pages/Product/ChargingPolicy.aspx";
				systemHashtable[SubMenuKeySystem.Image.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Image.ToString()]) + "||../Pages/Product/ImageSearch.aspx";
				systemHashtable[SubMenuKeySystem.Meal_Plan.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Meal_Plan.ToString()]) + "||../Pages/Product/MealPlan.aspx";
				////  systemHashtable.Add(SubMenuKeySystem.Meal_Plan1.ToString(), "Meal Plan1");

				systemHashtable[SubMenuKeySystem.Rules.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Rules.ToString()]) + "||../Pages/Product/Rules.aspx";//systemHashtable.Add(SubMenuKeySystem.Rules.ToString(), "Rules");
				systemHashtable[SubMenuKeySystem.User_Manager.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.User_Manager.ToString()]) + "||../Pages/System/UserManager.aspx";//systemHashtable.Add(SubMenuKeySystem.User_Manager.ToString(), "User Manager");
				systemHashtable[SubMenuKeySystem.Organisation.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Organisation.ToString()]) + "||../Pages/Organisation/Organisation.aspx";//systemHashtable.Add(SubMenuKeySystem.Organisation.ToString(), "Organisation");
				systemHashtable[SubMenuKeySystem.Mileage_Map.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Mileage_Map.ToString()]) + "||../Pages/System/MileageMap.aspx";//systemHashtable.Add(SubMenuKeySystem.Mileage_Map.ToString(), "Mileage Map");
				systemHashtable[SubMenuKeySystem.Commission_Maintenance.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Commission_Maintenance.ToString()]) + "||../Pages/Product/CommisionScheme.aspx";//systemHashtable.Add(SubMenuKeySystem.Commission_Maintenance.ToString(), "Commission Maintenance");

				systemHashtable[SubMenuKeySystem.Messaging_Settings.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Messaging_Settings.ToString()]) + "||../Pages/Messaging/TSWeb.aspx";//systemHashtable.Add(SubMenuKeySystem.Messaging_Settings.ToString(), "Messaging Settings");
				systemHashtable[SubMenuKeySystem.Reset_Cache.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Reset_Cache.ToString()]) + "||~/Home.aspx?ResetSystemCache=true";//Sarika(18)
				systemHashtable[aboutTabString] = Convert.ToString(systemHashtable[aboutTabString]) + "||../Pages/System/About.aspx"; //Nasia(73)
				systemHashtable[SubMenuKeySystem.Location.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Location.ToString()]) + "||../Pages/System/Location.aspx"; //Sandip P.(42)
				systemHashtable[SubMenuKeySystem.Price_Update_Status.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Price_Update_Status.ToString()]) + "||../Pages/System/PriceUpdateStatus.aspx";//Vikrant(59)
				//systemHashtable[SubMenuKeySystem.Pricing_Estimation_Default.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Pricing_Estimation_Default.ToString()]) + "||../PricingEstimationDefault/PricingEstimationDefault";
				  systemHashtable[SubMenuKeySystem.ChannelManagerConfiguration.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.ChannelManagerConfiguration.ToString()]) + "||../Pages/System/ChannelManagerConfiguration.aspx";//CANDIDA (67)
				  systemHashtable[SubMenuKeySystem.RegisterWidgets.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.RegisterWidgets.ToString()]) + "||../RegisterWidget/RegisterWidgets";//Pnaik (xx)
				systemHashtable[SubMenuKeySystem.Supplier_Extranet_Settings.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Supplier_Extranet_Settings.ToString()]) + "||../Pages/System/SupplierExtranetSettings.aspx";//Clerance(76)
				systemHashtable[SubMenuKeySystem.Areas.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Areas.ToString()]) + "||../Areas/Areas";//Vaishakhi(82)
				systemHashtable[SubMenuKeySystem.Document_Template_Library.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Document_Template_Library.ToString()]) + "||../TemplateBuilder/TemplateBuilder";//Madhu(83)
			   systemHashtable[SubMenuKeySystem.Document_Component_Section_Library.ToString()] =string.Format("{0}||../DocumentSectionBuilder/DocumentSectionBuilder", systemHashtable[SubMenuKeySystem.Document_Component_Section_Library.ToString()]); //Rajesh(84)
			   systemHashtable[SubMenuKeySystem.PricingEstimationDefault.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.PricingEstimationDefault.ToString()]) + "||../PricingEstimationDefault/PricingEstimationDefault"; //string.Format("{0}||../PricingEstimationDefault/PricingEstimationDefault", systemHashtable[SubMenuKeySystem.Pricing_Estimation_Default.ToString()]);
			   
			// systemHashtable.Add(SubMenuKeySystem.Document_Component_Section_Library.ToString(), "Document Section Builder");
			  
				systemHashtable[SubMenuKeySystem.Queue_Status.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Queue_Status.ToString()]) + "||../QueueStatus/QueueStatus";//Wayne(82)

				//BOC Rejeena(64)
				if (objUserRights != null && objUserRights.Access)
				{
					systemHashtable[SubMenuKeySystem.Task_Lists.ToString()] = Convert.ToString(systemHashtable[SubMenuKeySystem.Task_Lists.ToString()]) + "||../DefaultTasks/DefaultTasks";//Debasis(62)
				}
			   //EOC Rejeena(64)
				htReturn = systemHashtable;
				#endregion
				break;
			/*
		case "setup":
			Hashtable setupHashtable = new Hashtable();
			setupHashtable.Add(SubMenuKeySetup.Server_Setup.ToString(), "Setup Server");
			setupHashtable.Add(SubMenuKeySetup.Web_Server_Setup.ToString(), "Setup Web Server");
			setupHashtable.Add(SubMenuKeySetup.Setup_Debug_Mode.ToString(), "Setup Debug Mode");

			setupHashtable = Base.GetMultilingualMessageList("Menu", setupHashtable);
			htReturn = setupHashtable;
			break;
			 * */
			case "booking":
				Hashtable bookingHashTable = new Hashtable();
				bookingHashTable.Add(SubMenuKeyBookings.New_Booking.ToString(), "New Booking");
				bookingHashTable.Add(SubMenuKeyBookings.Booking_Find.ToString(), "Booking Search");
				bookingHashTable.Add(SubMenuKeyBookings.Replicate_Bookings.ToString(), "Replicate Bookings");
				bookingHashTable.Add(SubMenuKeyBookings.Package_Search.ToString(), "Package Search");
				bookingHashTable.Add(SubMenuKeyBookings.Passenger_Maint.ToString(), "Passenger Maintenance");
				bookingHashTable.Add(SubMenuKeyBookings.Commission_Payment_Approval.ToString(), "Comm. Payment Appr.");
				bookingHashTable.Add(SubMenuKeyBookings.PNR_Shadow_List.ToString(), "PNR Shadow List");
				bookingHashTable.Add(SubMenuKeyBookings.Expired_Options.ToString(), "Expired Options");
				bookingHashTable.Add(SubMenuKeyBookings.Villa_Booking.ToString(), "Villa Search");
				bookingHashTable.Add(SubMenuKeyBookings.Service_Search.ToString(), "Service Search");
				bookingHashTable.Add(SubMenuKeyBookings.Booking_Import.ToString(), "Booking Import");
				//BOC Poornima(71)
				if (GetRailDisplayFlag())
				{
					bRailDisplayFlag = true;
					bookingHashTable.Add(SubMenuKeyBookings.Rail_Search.ToString(), "Rail Search");
				}
				//EOC Poornima(71)
				bookingHashTable.Add(SubMenuKeyBookings.NCOA_Address_Export.ToString(), "NCOA Address Export");
				bookingHashTable.Add(SubMenuKeyBookings.Bulk_Service_Replacement.ToString(), "Bulk Service Replacement");
				bookingHashTable.Add(SubMenuKeyBookings.Booked_Service_Search.ToString(), "Booked Service Search");
				bookingHashTable.Add(SubMenuKeyBookings.Batch_Status_Update.ToString(), "Batch Status Update");
				bookingHashTable.Add(SubMenuKeyBookings.Flight_Search.ToString(), "Search / Book Flight.");
				bookingHashTable.Add(SubMenuKeyBookings.Task_Manager.ToString(), "Task Manager"); //Abhijit L.(33)
				bookingHashTable.Add(SubMenuKeyBookings.Book_Promotional_Package.ToString(), "Book Promotional Package"); //Harshad(54)
				bookingHashTable.Add(SubMenuKeyBookings.New_Enquiry.ToString(), "New Enquiry");        //kartheek(58)
				bookingHashTable.Add(SubMenuKeyBookings.Enquiry_Search.ToString(), "Enquiry Search");  //kartheek(58)
				bookingHashTable.Add(SubMenuKeyBookings.Purchase_Space_Management.ToString(), "Purchase Space Management"); //Ravish(51)
				bookingHashTable.Add(SubMenuKeyBookings.Flight_Hotel_Search.ToString(), "Flight & Hotel Search");  //Harshad(60)
				bookingHashTable.Add(SubMenuKeyBookings.Dynamic_Package_Search.ToString(), "Dynamic Package Search");  //Harshad(75)
				bookingHashTable.Add(SubMenuKeyBookings.Generate_Xml.ToString(), "Generate XMLs");  //Shradha(67)
				//BOC Dejalin(65)
				if (GetEnableOperationalModuleFlag())
				{
					bEnableOperationalModuleFlag = true;
					bookingHashTable.Add(SubMenuKeyBookings.Operations_Module.ToString(), "Operations Module"); 
				}
				//EOC Dejalin(65)
				bookingHashTable.Add(SubMenuKeyBookings.Batch_Booking_Task_Generation.ToString(), "Batch Booking Task Generation");      //Purva(73)

				bookingHashTable.Add(SubMenuKeyBookings.Rail_CheckIn.ToString(), "Rail CheckIn");//Tejas(74)
				bookingHashTable.Add(SubMenuKeyBookings.Expiring_Options.ToString(), "Expiring Options"); //Omkar N.(80)
				bookingHashTable.Add(SubMenuKeyBookings.Batch_Message_Generation.ToString(), "Batch Message Generation"); //Priya
		   
				bookingHashTable = Base.GetMultilingualMessageList("Menu", bookingHashTable);
				bookingHashTable[SubMenuKeyBookings.Booking_Find.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Booking_Find.ToString()]) + "||../Pages/Booking/BookingSearchResults.aspx";
				//BOC Vismita(86)
				if (IsOldPackageSearchUI())
				{
					bookingHashTable[SubMenuKeyBookings.Package_Search.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Package_Search.ToString()]) + "||../Pages/Booking/BookingPackageSearch.aspx";
				}
				else
				{
					bookingHashTable[SubMenuKeyBookings.Package_Search.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Package_Search.ToString()]) + "||../PackageSearch/PackageSearchContainer";   
				}
				//EOC Vismita(86)       
				bookingHashTable[SubMenuKeyBookings.Service_Search.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Service_Search.ToString()]) + "||../Pages/ServiceSearch/TSServiceSearch.aspx";    //Jayesh(37)
				bookingHashTable[SubMenuKeyBookings.New_Booking.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.New_Booking.ToString()]) + "||../Pages/Booking/NewBooking.aspx";
				bookingHashTable[SubMenuKeyBookings.Commission_Payment_Approval.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Commission_Payment_Approval.ToString()]) + "||../Pages/Booking/CommissionPaymentsApproval.aspx"; //SiddheshPrb(25)
				bookingHashTable[SubMenuKeyBookings.Task_Manager.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Task_Manager.ToString()]) + "||../Pages/Booking/TaskManager.aspx"; //Abhijit L.(33)
				bookingHashTable[SubMenuKeyBookings.Booked_Service_Search.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Booked_Service_Search.ToString()]) + "||../Pages/Booking/BookedServiceSearch.aspx"; //Ravish(34)
				bookingHashTable[SubMenuKeyBookings.Flight_Search.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Flight_Search.ToString()]) + "||../Pages/Booking/FlightSearch.aspx"; //Ravish(43)
				bookingHashTable[SubMenuKeyBookings.Book_Promotional_Package.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Book_Promotional_Package.ToString()]) + "||../Pages/Booking/PromotionalPackageSearch.aspx"; //Harshad(54)
				bookingHashTable[SubMenuKeyBookings.New_Enquiry.ToString()] = string.Format("{0}||../ItineraryBuilder/ItineraryBuilder", bookingHashTable[SubMenuKeyBookings.New_Enquiry.ToString()]);             //kartheek(58)//Savira(81)
				bookingHashTable[SubMenuKeyBookings.Enquiry_Search.ToString()] = string.Format("{0}||../Pages/Booking/EnquirySearch.aspx", bookingHashTable[SubMenuKeyBookings.Enquiry_Search.ToString()]);  //kartheek(58)
				bookingHashTable[SubMenuKeyBookings.Purchase_Space_Management.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Purchase_Space_Management.ToString()]) + "||../Pages/Booking/PurchaseSpaceManagement.aspx"; //Ravish(51)
				bookingHashTable[SubMenuKeyBookings.Flight_Hotel_Search.ToString()] = string.Format("{0}||../Pages/Booking/FlightHotelSearch.aspx", bookingHashTable[SubMenuKeyBookings.Flight_Hotel_Search.ToString()]);  //Harshad(60)
				bookingHashTable[SubMenuKeyBookings.Dynamic_Package_Search.ToString()] = string.Format("{0}||../Pages/Booking/DynamicPackageSearch.aspx", bookingHashTable[SubMenuKeyBookings.Dynamic_Package_Search.ToString()]);  //Harshad(75)

				bookingHashTable[SubMenuKeyBookings.Generate_Xml.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Generate_Xml.ToString()]) + "||" + Convert.ToString(bookingHashTable[SubMenuKeyBookings.Generate_Xml.ToString()]) + "||../Pages/Booking/GenerateXml.aspx"; //Shradha(67)
				//BOC Poornima(71)
				if (bRailDisplayFlag)
					bookingHashTable[SubMenuKeyBookings.Rail_Search.ToString()] = string.Format("{0}||../Pages/Booking/RailServiceSearch.aspx", bookingHashTable[SubMenuKeyBookings.Rail_Search.ToString()]);
				//EOC Poornima(71)
			  
				//BOC Dejalin(65)
				if (bEnableOperationalModuleFlag)
					bookingHashTable[SubMenuKeyBookings.Operations_Module.ToString()] = string.Format("{0}||../Pages/Booking/OperationsModule.aspx", bookingHashTable[SubMenuKeyBookings.Operations_Module.ToString()]);

				//EOC Dejalin(65)
				bookingHashTable[SubMenuKeyBookings.Batch_Booking_Task_Generation.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Batch_Booking_Task_Generation.ToString()]) + "||../Pages/Booking/BatchBookingTaskGeneration.aspx";     //Purva(73)
				bookingHashTable[SubMenuKeyBookings.Rail_CheckIn.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Rail_CheckIn.ToString()]) + "||../RailCheckIn/RailCheckIn";//Tejas(74)
				bookingHashTable[SubMenuKeyBookings.Expiring_Options.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Expiring_Options.ToString()]) + "||../ExpiringOptions/ExpiringOptionsContainer";//Omkar N.(80) 
				bookingHashTable[SubMenuKeyBookings.Batch_Message_Generation.ToString()] = Convert.ToString(bookingHashTable[SubMenuKeyBookings.Batch_Message_Generation.ToString()]) + "||../Messages/BatchMessageGeneration"; //Priya

				htReturn = bookingHashTable;
				break;
			case "package":

				#region PACKAGE SUB MENU

				//Package Hashtable
				Hashtable packageHashtable = new Hashtable();
				packageHashtable.Add(SubMenuKeyPackage.New_Package.ToString(), "New Package");  //Wayne(45)
				/*packageHashtable.Add(SubMenuKeyPackage.Package_Find.ToString(), "Package Find");
				packageHashtable.Add(SubMenuKeyPackage.Package_Maintenance.ToString(), "Departure Maintenance");
				packageHashtable.Add(SubMenuKeyPackage.Package_Allocation.ToString(), "Package Allocation");
				packageHashtable.Add(SubMenuKeyPackage.Package_Brochure.ToString(), "Package Brochure");*/
				packageHashtable.Add(SubMenuKeyPackage.Waitlist_Maintenance.ToString(), "Waitlist Maintenance");//Shruti(63)
				/*packageHashtable.Add(SubMenuKeyPackage.Batch_Package_Sell_Price_Creation.ToString(), "Batch Pkg Sell Price Creation");
				packageHashtable.Add(SubMenuKeyPackage.Package_Facilities.ToString(), "Package Facilities");
				packageHashtable.Add(SubMenuKeyPackage.Pattern_Splitting_Wizard.ToString(), "Pattern Splitting Wizard");
				packageHashtable.Add(SubMenuKeyPackage.Batch_Service_Details_Update.ToString(), "Batch Service Details Update");
				//Check for  if edit right of package for below menu
				packageHashtable.Add(SubMenuKeyPackage.Update_Departure_Cost.ToString(), "Update Departure Cost");
				packageHashtable.Add(SubMenuKeyPackage.Package_Inventory.ToString(), "Package Inventory");*/

				packageHashtable.Add(SubMenuKeyPackage.Package_Find.ToString(), "Package Find");//Lorraine M (46)
				packageHashtable.Add(SubMenuKeyPackage.Package_Data.ToString(), "Package Data");  //Vrundavani(59)
				packageHashtable.Add(SubMenuKeyPackage.Departure_Find.ToString(), "Departure Find");  //Vrundavani(59)
				packageHashtable.Add(SubMenuKeyPackage.Package_Pricing_Analysis_Module.ToString(), "Package Pricing Analysis Module");//Sundeep
				//BOC Suchina(81)
				  DataClasses.SecurityClasses.UserRight objUserRightsBulkPriceAdjustment = SecurityManager.UserSecurity.GetAccessRights((int)enmBulkPriceAdjustment.BulkPriceAdjustment);
				if (objUserRightsBulkPriceAdjustment != null && objUserRightsBulkPriceAdjustment.Access)
				  {
					  packageHashtable.Add(SubMenuKeyPackage.Bulk_Price_Adjustment.ToString(), "Bulk Price Adjustments"); 
				  }
				//EOC Suchina(81)
				packageHashtable = Base.GetMultilingualMessageList("Menu", packageHashtable);
				packageHashtable[SubMenuKeyPackage.New_Package.ToString()] = Convert.ToString(packageHashtable[SubMenuKeyPackage.New_Package.ToString()]) + "||../PackageBuilder/NewPackageRedirection";  //Wayne(45)
				packageHashtable[SubMenuKeyPackage.Departure_Find.ToString()] = Convert.ToString(packageHashtable[SubMenuKeyPackage.Departure_Find.ToString()]) + "||../DepartureFind/DepartureFindContainer";
				packageHashtable[SubMenuKeyPackage.Package_Find.ToString()] = Convert.ToString(packageHashtable[SubMenuKeyPackage.Package_Find.ToString()]) + "||..//Pages/Packages/PackageFind.aspx";//Lorraine M (46)
				packageHashtable[SubMenuKeyPackage.Package_Data.ToString()] = Convert.ToString(packageHashtable[SubMenuKeyPackage.Package_Data.ToString()]) + "||..//Pages/Packages/PackageData.aspx";//Vrundavani(59)
				packageHashtable[SubMenuKeyPackage.Waitlist_Maintenance.ToString()] = Convert.ToString(packageHashtable[SubMenuKeyPackage.Waitlist_Maintenance.ToString()]) + "||..//Pages/Packages/WaitlistMaintenance.aspx";//Shruti(63)
				packageHashtable[SubMenuKeyPackage.Package_Pricing_Analysis_Module.ToString()] = Convert.ToString(packageHashtable[SubMenuKeyPackage.Package_Pricing_Analysis_Module.ToString()]) + "||../PackagePricingAnalysis/PackagePricingAnalysis";//Sundeep
				//BOC Suchina(81)
				if (objUserRightsBulkPriceAdjustment != null && objUserRightsBulkPriceAdjustment.Access)
				{
					packageHashtable[SubMenuKeyPackage.Bulk_Price_Adjustment.ToString()] = Convert.ToString(packageHashtable[SubMenuKeyPackage.Bulk_Price_Adjustment.ToString()]) + "||../BulkPriceAdjustment/BulkPriceAdjustment";
				}
				//EOC Suchina(81)
				 htReturn = packageHashtable;

				#endregion
				break;
			case "product":
				#region PRODUCTS SUB MENU

				Hashtable productsHashtable = new Hashtable();
				productsHashtable.Add(SubMenuKeyProduct.Supplier.ToString(), "Supplier");
				productsHashtable.Add(SubMenuKeyProduct.Service.ToString(), "Service");
				productsHashtable.Add(SubMenuKeyProduct.Contract.ToString(), "Contract");
				productsHashtable.Add(SubMenuKeyProduct.Villa_Group.ToString(), "Villa Group");
				productsHashtable.Add(SubMenuKeyProduct.Option.ToString(), "Option");
				productsHashtable.Add(SubMenuKeyProduct.Extra.ToString(), "Extra");
				productsHashtable.Add(SubMenuKeyProduct.Facilities.ToString(), "Facilities");
				productsHashtable.Add(SubMenuKeyProduct.Rating.ToString(), "Rating");
				productsHashtable.Add(SubMenuKeyProduct.Child_Policy.ToString(), "Child Policy");
				productsHashtable.Add(SubMenuKeyProduct.Supplier_Group.ToString(), "Supplier Group");
				productsHashtable.Add(SubMenuKeyProduct.Batch_Selling_Price_Creation.ToString(), "Batch Service Sell Price Generator");//Ravish(74)
				productsHashtable.Add(SubMenuKeyProduct.Batch_Price_Type_Associator.ToString(), "Batch Price Type Associator");
				productsHashtable.Add(SubMenuKeyProduct.Batch_Rule_Generation.ToString(), "Batch Rule Generator");
				//Check for display rail flag from organization settings to enable below menu for Rail
				productsHashtable.Add(SubMenuKeyProduct.Rail_Manager.ToString(), "Rail Manager");
				productsHashtable.Add(SubMenuKeyProduct.Allocation_Name.ToString(), "Allocation Name");
				productsHashtable.Add(SubMenuKeyProduct.Web_Passenger_Questions.ToString(), "Web Passenger Questions");
				productsHashtable.Add(SubMenuKeyProduct.Service_Type_Questions.ToString(), "Service Type Questions");
				productsHashtable.Add(SubMenuKeyProduct.Cancellation_Policies.ToString(), "Cancellation Policies");
				productsHashtable.Add(SubMenuKeyProduct.Service_Pricing.ToString(), "Service Pricing");
				//productsHashtable.Add(SubMenuKeyProduct.Access_to_Mandatory_Services.ToString(), "Mandatory/Discount Services");//Vimlesh(59)
				productsHashtable.Add(SubMenuKeyProduct.Mandatory_Services_Access.ToString(), "Mandatory Services");//Vimlesh(59)	//Nikita()
				//productsHashtable.Add(SubMenuKeyProduct.Service_Export_Import.ToString(), "Service Export Import");//Pradnya(60)Commented
				productsHashtable.Add(SubMenuKeyProduct.Villa_Room_Name.ToString(), "Villa Room Name");
				productsHashtable.Add(SubMenuKeyProduct.Update_Booking_Costs.ToString(), "Update Booking Costs");
				productsHashtable.Add(SubMenuKeyProduct.Supplier_Extranet_Messages.ToString(), "Supplier Extranet Messages");
				productsHashtable.Add(SubMenuKeyProduct.Yield_Rule_Setup.ToString(), "Yield Rule Setup");
				productsHashtable.Add(SubMenuKeyProduct.Query_Tool.ToString(), "Query Tool");
				productsHashtable.Add(SubMenuKeyProduct.Instalment_Discounts.ToString(), "Instalment Discounts");//Shivanand(11)
				productsHashtable.Add(SubMenuKeyProduct.Batch_Instalment_Generator.ToString(), "Batch Instalment Generator");//Shivanand(11)
				productsHashtable.Add(SubMenuKeyProduct.Availability_Updater.ToString(), "Availability Updater");//Kedar(22)
				productsHashtable.Add(SubMenuKeyProduct.Supplier_Servcie_Document.ToString(), "Supplier Service Document");//Vikrant(58)
				productsHashtable.Add(SubMenuKeyProduct.Bulk_Contract_Maintenance.ToString(), "Bulk Contract Maintenance"); //Clerance(53)
				productsHashtable.Add(SubMenuKeyProduct.Bulk_Contract_Maintenance_History.ToString(), "Bulk Contract Maintenance History"); //Clerance(53)
				productsHashtable.Add(SubMenuKeyProduct.Offline_Price_Editor.ToString(), "Offline Price Editor"); //Sujata(54)
				productsHashtable.Add(SubMenuKeyProduct.Discount.ToString(), "Discount"); //Omkar N.(81)
				productsHashtable = Base.GetMultilingualMessageList("Menu", productsHashtable);

				productsHashtable[SubMenuKeyProduct.Supplier.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Supplier.ToString()]) + "||../Pages/Client/SupplierSearch.aspx";
				productsHashtable[SubMenuKeyProduct.Service.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Service.ToString()]) + "||../Pages/Services/ServiceSearch.aspx";//productsHashtable[SubMenuKeyProduct.Service.ToString()];
				productsHashtable[SubMenuKeyProduct.Contract.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Contract.ToString()]) + "||../Pages/Product/Contracts.aspx";//productsHashtable[SubMenuKeyProduct.Contract.ToString()]
				productsHashtable[SubMenuKeyProduct.Villa_Group.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Villa_Group.ToString()]) + "||../Pages/Product/VillaGroup.aspx";//productsHashtable[SubMenuKeyProduct.Contract.ToString()];
				productsHashtable[SubMenuKeyProduct.Option.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Option.ToString()]) + "||../Pages/Product/Option.aspx";//productsHashtable[SubMenuKeyProduct.Villa_Group.ToString()];
				productsHashtable[SubMenuKeyProduct.Extra.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Extra.ToString()]) + "||../Pages/Product/Extra.aspx";//productsHashtable[SubMenuKeyProduct.ST_Option.ToString()];
				productsHashtable[SubMenuKeyProduct.Facilities.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Facilities.ToString()]) + "||../Pages/Product/Facilities.aspx";//productsHashtable[SubMenuKeyProduct.ST_Extra.ToString()];
				productsHashtable[SubMenuKeyProduct.Rating.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Rating.ToString()]) + "||../Pages/Product/Ratings.aspx";//productsHashtable[SubMenuKeyProduct.ST_Facilities.ToString()];
				productsHashtable[SubMenuKeyProduct.Child_Policy.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Child_Policy.ToString()]) + "||../Pages/Product/ChildPolicy.aspx";//productsHashtable[SubMenuKeyProduct.ST_Type_Rating.ToString()];
				productsHashtable[SubMenuKeyProduct.Supplier_Group.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Supplier_Group.ToString()]) + "||../Pages/Product/SupplierGroups.aspx";//productsHashtable[SubMenuKeyProduct.Child_Policy.ToString()];
				productsHashtable[SubMenuKeyProduct.Batch_Selling_Price_Creation.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Batch_Selling_Price_Creation.ToString()]) + "||../Pages/Product/BatchSellingPriceGenerator.aspx"; //Vanessa (39)
				productsHashtable[SubMenuKeyProduct.Batch_Rule_Generation.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Batch_Rule_Generation.ToString()]) + "||../Pages/Product/BatchRuleGenerator.aspx";//productsHashtable[SubMenuKeyProduct.Supplier_Group.ToString()];
				productsHashtable[SubMenuKeyProduct.Allocation_Name.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Allocation_Name.ToString()]) + "||../Pages/Product/AllocationName.aspx";//productsHashtable[SubMenuKeyProduct.Batch_Selling_Price_Creation.ToString()];
				productsHashtable[SubMenuKeyProduct.Web_Passenger_Questions.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Web_Passenger_Questions.ToString()]) + "||../Pages/Product/WebPassengerQuestions.aspx";//productsHashtable[SubMenuKeyProduct.Batch_Price_Type_Associator.ToString()];
				productsHashtable[SubMenuKeyProduct.Service_Type_Questions.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Service_Type_Questions.ToString()]) + "||../Pages/Product/ServiceTypeQuestions.aspx";//productsHashtable[SubMenuKeyProduct.Batch_Rule_Generation.ToString()];
				productsHashtable[SubMenuKeyProduct.Cancellation_Policies.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Cancellation_Policies.ToString()]) + "||../Pages/Product/CancellationPolicy.aspx";////Check for display rail flag from organization settings to enable below menu for Rail
				productsHashtable[SubMenuKeyProduct.Villa_Room_Name.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Villa_Room_Name.ToString()]) + "||../Pages/Product/VillaRoomName.aspx";//productsHashtable[SubMenuKeyProduct.Rail_Manager.ToString()];
				productsHashtable[SubMenuKeyProduct.Supplier_Extranet_Messages.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Supplier_Extranet_Messages.ToString()]) + "||../Pages/Product/SupplierExtranetMessage.aspx";//productsHashtable[SubMenuKeyProduct.Allocation_Name.ToString()];
				productsHashtable[SubMenuKeyProduct.Mandatory_Services_Access.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Mandatory_Services_Access.ToString()]) + "||../Pages/Product/MandatoryServices.aspx";//Vimlesh(59)

				//BOC Nagesh(07)
				productsHashtable[SubMenuKeyProduct.Yield_Rule_Setup.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Yield_Rule_Setup.ToString()]) + "||../Pages/Product/YieldRules.aspx";
				productsHashtable[SubMenuKeyProduct.Query_Tool.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Query_Tool.ToString()]) + "||../Pages/Product/QueryTool.aspx";
				//EOC Nagesh(07)
				//Boc Shivanand(11)
				productsHashtable[SubMenuKeyProduct.Instalment_Discounts.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Instalment_Discounts.ToString()]) + "||../Pages/Product/InstalmentDiscounts.aspx";
				productsHashtable[SubMenuKeyProduct.Batch_Instalment_Generator.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Batch_Instalment_Generator.ToString()]) + "||../Pages/Product/BatchInstalmentGenerator.aspx";
				//Eoc Shivanand(11)
				productsHashtable[SubMenuKeyProduct.Availability_Updater.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Availability_Updater.ToString()]) + "||../Pages/Product/AvailabilityUpdater.aspx"; //Kedar(22)
				productsHashtable[SubMenuKeyProduct.Supplier_Servcie_Document.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Supplier_Servcie_Document.ToString()]) + "||../Pages/Product/SupplierServiceDocument.aspx"; //Vikrant(58)
				productsHashtable[SubMenuKeyProduct.Bulk_Contract_Maintenance.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Bulk_Contract_Maintenance.ToString()] + "||../Pages/Product/BulkContractMaintenance.aspx");//Clerance(53)
				productsHashtable[SubMenuKeyProduct.Bulk_Contract_Maintenance_History.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Bulk_Contract_Maintenance_History.ToString()] + "||../Pages/Product/BulkContractMaintenanceHistory.aspx");//Clerance(53)
				productsHashtable[SubMenuKeyProduct.Offline_Price_Editor.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Offline_Price_Editor.ToString()] + "||../Pages/Product/OfflinePriceEditor.aspx");//Sujata(54)
				productsHashtable[SubMenuKeyProduct.Discount.ToString()] = Convert.ToString(productsHashtable[SubMenuKeyProduct.Discount.ToString()]) + "||../DiscountSearch/DiscountSearchContainer"; //Omkar N.(81)

				htReturn = productsHashtable;

				#endregion
				break;
			case "client":
				#region CLIENTS SUB MENU


				Hashtable clientsHashtable = new Hashtable();
				clientsHashtable.Add(SubMenuKeyClients.Agent.ToString(), "Agent");
				clientsHashtable.Add(SubMenuKeyClients.Agent_Group.ToString(), "Agent Group");
				clientsHashtable.Add(SubMenuKeyClients.Agent_Group_Commission_Update.ToString(), "Agent Group Commission Update");
				clientsHashtable.Add(SubMenuKeyClients.Agent_Import.ToString(), "Agents Import");
				clientsHashtable.Add(SubMenuKeyClients.New_Client_Credit.ToString(), "New Client Credit");
				clientsHashtable.Add(SubMenuKeyClients.Search_Client_Credit.ToString(), "Search Client Credit");
				clientsHashtable.Add(SubMenuKeyClients.Default_Price_Type.ToString(), "Price Type Default");
				clientsHashtable.Add(SubMenuKeyClients.Merge_Passenger_Bookings.ToString(), "Merge Passenger Bookings");
				clientsHashtable.Add(SubMenuKeyClients.Passenger.ToString(), "Passenger Maintenance");
				clientsHashtable.Add(SubMenuKeyClients.Marketing_Survey_Import.ToString(), "Marketing Survey Import");
				clientsHashtable.Add(SubMenuKeyClients.Agent_Portal.ToString(), "Agent Portal Settings"); //Deepa(16)

				clientsHashtable = Base.GetMultilingualMessageList("Menu", clientsHashtable);
				clientsHashtable[SubMenuKeyClients.Agent.ToString()] = Convert.ToString(clientsHashtable[SubMenuKeyClients.Agent.ToString()]) + "||../Pages/Client/AgentSearch.aspx";
				clientsHashtable[SubMenuKeyClients.Agent_Group.ToString()] = Convert.ToString(clientsHashtable[SubMenuKeyClients.Agent_Group.ToString()]) + "||../Pages/Client/AgentGroup.aspx";
				clientsHashtable[SubMenuKeyClients.Agent_Group_Commission_Update.ToString()] = Convert.ToString(clientsHashtable[SubMenuKeyClients.Agent_Group_Commission_Update.ToString()]) + "||../Pages/Client/AgentGroupCommission.aspx";

				clientsHashtable[SubMenuKeyClients.Search_Client_Credit.ToString()] = Convert.ToString(clientsHashtable[SubMenuKeyClients.Search_Client_Credit.ToString()]) + "||../Pages/Client/SearchClientCredit.aspx";
				clientsHashtable[SubMenuKeyClients.Default_Price_Type.ToString()] = Convert.ToString(clientsHashtable[SubMenuKeyClients.Default_Price_Type.ToString()]) + "||../Pages/Client/PriceTypeDefault.aspx";


				clientsHashtable[SubMenuKeyClients.Passenger.ToString()] = Convert.ToString(clientsHashtable[SubMenuKeyClients.Passenger.ToString()]) + "||../Pages/Client/PassengerSearch.aspx";
				clientsHashtable[SubMenuKeyClients.Agent_Portal.ToString()] = Convert.ToString(clientsHashtable[SubMenuKeyClients.Agent_Portal.ToString()]) + "||../Pages/Client/AgentPortalSettings.aspx";//Deepa(16)
				htReturn = clientsHashtable;
				#endregion
				break;
			case "fulfilment":
				#region FULFILLMENT SUB MENU

				//hashtable for Fullfillment
				/*
				Hashtable fulfillmentHashtable = new Hashtable();
				fulfillmentHashtable.Add(SubMenuKeyFulfillment.Create_Document_Packages.ToString(), "Create Document Pkgs");
				fulfillmentHashtable.Add(SubMenuKeyFulfillment.Print_Document_Packages.ToString(), "Print Document Packages");
				fulfillmentHashtable.Add(SubMenuKeyFulfillment.MessageEditor.ToString(), "Message Editor");
				fulfillmentHashtable.Add(SubMenuKeyFulfillment.Mail_Shot.ToString(), "Mail Shot");
				fulfillmentHashtable.Add(SubMenuKeyFulfillment.Batch_Message_Generation.ToString(), "Batch Message Generation");
				fulfillmentHashtable.Add(SubMenuKeyFulfillment.Manual_Manifest_Generation.ToString(), "Manual Manifest Generation");
				fulfillmentHashtable = Base.GetMultilingualMessageList("Menu", fulfillmentHashtable);
				htReturn = fulfillmentHashtable;
				*/
				#endregion
				break;
			case "reports":
				#region REPORTS SUB MENU

				Hashtable reportHashtable = new Hashtable();
				reportHashtable.Add(SubMenuKeyReport.Generate_Report.ToString(), "Generate Report");
				reportHashtable.Add(SubMenuKeyReport.Report_Generation_Restrictions.ToString(), "Report Generation Restrictions");
				reportHashtable.Add(SubMenuKeyReport.Report_Schedule.ToString(), "Report Schedule");//Pradnya(65)
				reportHashtable.Add(SubMenuKeyReport.Unsent_Messages.ToString(), "Unsent Messages");//Nagesh(74)
				reportHashtable.Add(SubMenuKeyReport.Manage_Reports.ToString(), "Manage Reports");//Sunil(1043)				
				reportHashtable.Add(SubMenuKeyReport.Generate_Manifest.ToString(), "Generate Manifest");//Diptesh H() /Sajjan H(84)
				//reportHashtable.Add(SubMenuKeyReport.Service_Report_Screen.ToString(), "Service Report");
				//reportHashtable.Add(SubMenuKeyReport.Supplier_Report_Screen.ToString(), "Supplier Report");
				//reportHashtable.Add(SubMenuKeyReport.Tariff_Export_Report_Screen.ToString(), "Tariff Report");
				//reportHashtable.Add(SubMenuKeyReport.Finance_Report_Screen.ToString(), "Finance Report");
				//reportHashtable.Add(SubMenuKeyReport.Quote_Reports_Screen.ToString(), "Quote Reports");
				//reportHashtable.Add(SubMenuKeyReport.Booking_Notes_Report_Screen.ToString(), "Booking Notes Report");
				//reportHashtable.Add(SubMenuKeyReport.Report_Group.ToString(), "Report Group");
				//reportHashtable.Add(SubMenuKeyReport.Report_Registration.ToString(), "Report Registration");
				//reportHashtable.Add(SubMenuKeyReport.Package_Report_Screen.ToString(), "Package Report");
				//reportHashtable.Add(SubMenuKeyReport.Flight_Report_Screen.ToString(), "Flight Report");
				//reportHashtable.Add(SubMenuKeyReport.Allocation_Usage_Graph_Report_Screen.ToString(), "Allocation Usage Graph");
				//reportHashtable.Add(SubMenuKeyReport.AutoMessaging_Failed_Messages.ToString(), "Failed Messages Report");
				//reportHashtable.Add(SubMenuKeyReport.Agent_Report_Options_Screen.ToString(), "Agent Report Options");
				//reportHashtable.Add(SubMenuKeyReport.Rail_Report_Screen.ToString(), "Rail Report Options");

				reportHashtable = Base.GetMultilingualMessageList("Menu", reportHashtable);
				reportHashtable[SubMenuKeyReport.Generate_Report.ToString()] = Convert.ToString(reportHashtable[SubMenuKeyReport.Generate_Report.ToString()]) + "||../Pages/Report/Reports.aspx";
				reportHashtable[SubMenuKeyReport.Report_Generation_Restrictions.ToString()] = Convert.ToString(reportHashtable[SubMenuKeyReport.Report_Generation_Restrictions.ToString()]) + "||../Pages/Report/ReportGenerationRestrictions.aspx";//Harshad(63)
				reportHashtable[SubMenuKeyReport.Report_Schedule.ToString()] = Convert.ToString(reportHashtable[SubMenuKeyReport.Report_Schedule.ToString()]) + "||../Pages/Report/ReportSchedule.aspx";//Pradnya(65)
				reportHashtable[SubMenuKeyReport.Unsent_Messages.ToString()] = Convert.ToString(reportHashtable[SubMenuKeyReport.Unsent_Messages.ToString()]) + "||../UnsentMessages/UnsentMessages";//Nagesh(74)				
				reportHashtable[SubMenuKeyReport.Manage_Reports.ToString()] = Convert.ToString(reportHashtable[SubMenuKeyReport.Manage_Reports.ToString()]) + "||../ManageReports/ManageReport";//Sunil(1043)
				reportHashtable[SubMenuKeyReport.Generate_Manifest.ToString()] = Convert.ToString(reportHashtable[SubMenuKeyReport.Generate_Manifest.ToString()]) + "||../GenerateManifest/GenerateManifest";//Sajjan.H(84)
				htReturn = reportHashtable;

				#endregion
				break;

			case "accounts":
				#region ACCOUNTS SUB MENU

				Hashtable accountsHashtable = new Hashtable();
				//BOC Commented Virag D.
				accountsHashtable.Add(SubMenuKeyAccount.Export_Financial_Details.ToString(), "Export Financial Details");//Harshad(44)
				accountsHashtable.Add(SubMenuKeyAccount.Batch_Invoice_Creation.ToString(), "Batch Invoice Creation");//Harshad(19)
				accountsHashtable.Add(SubMenuKeyAccount.Purchase_Invoice_Creation.ToString(), "Purchase Invoice Creation");
				accountsHashtable.Add(SubMenuKeyAccount.Purchase_Invoice_Import.ToString(), "Purchase Invoice Import");//Anshul(77)
				accountsHashtable.Add(SubMenuKeyAccount.Reprint_Invoices.ToString(), "Reprint Invoices");
				accountsHashtable.Add(SubMenuKeyAccount.Batch_Voucher_Close.ToString(), "Batch Voucher Close");//Ravish(27)
				//accountsHashtable.Add(SubMenuKeyAccount.Exchange_Rates.ToString(), "Exchange Rate");
				accountsHashtable.Add(SubMenuKeyAccount.Batch_Receipts_Entry.ToString(), "Batch Receipts Entry");//Amey.R(61) //Gautami(62)
				accountsHashtable.Add(SubMenuKeyAccount.Tax_Codes.ToString(), "Tax Codes");//Sarika(29)
				//EOC Commented Virag D.
				accountsHashtable.Add(SubMenuKeyAccount.Currency.ToString(), "Currency");
				//BOC Commented Virag D.
				accountsHashtable.Add(SubMenuKeyAccount.Create_GL_Accounts.ToString(), "Create GL Accounts");//Deepa(28)
				accountsHashtable.Add(SubMenuKeyAccount.Check_Commission_Payments.ToString(), "Check Comm. Payment");   //SiddheshPrb(25)
				//accountsHashtable.Add(SubMenuKeyAccount.Access_to_Commission_Margin_Setup.ToString(), "Commission Margin Setup");
				//accountsHashtable.Add(SubMenuKeyAccount.TIC_Insurance_Export.ToString(), "TIC Insurance Export");
				//accountsHashtable.Add(SubMenuKeyAccount.Suppliers_Invoice_Submission.ToString(), "Suppliers Invoice Submission");
				//EOC Commented Virag D.
				accountsHashtable.Add(SubMenuKeyAccount.Banked_Receipts.ToString(), "Banked Receipts"); //Kedar(12)
				accountsHashtable.Add(SubMenuKeyAccount.Exchange_Rates.ToString(), "Exchange Rate"); //Sarika(14)
				accountsHashtable.Add(SubMenuKeyAccount.Bank_Profiles.ToString(), "Bank Profiles"); //Sudeep(15)
				accountsHashtable.Add(SubMenuKeyAccount.Invoice_Daily_Exchange_Rates.ToString(), "Invoice Daily Exchange Rate");//Pranav(62)
				accountsHashtable.Add(SubMenuKeyAccount.Receipts_Reconciliation.ToString(), "Receipts Reconciliation"); //Sudeep(15)

				//BOC Utkarsha(70)
				GetAllRefundEndpointTypeResponse ObjResp = new GetAllRefundEndpointTypeResponse();
				List<GetAllRefundEndpointTypeResponseData> Resplst = new List<GetAllRefundEndpointTypeResponseData>();
			   ServiceProxyManager.Factory.SystemSetup.OrganisationFactory ObjFac = new ServiceProxyManager.Factory.SystemSetup.OrganisationFactory();
			   ObjResp = ObjFac.GetAllRefundEndpointType();
			   bool IsBankExportTypeEnable = false;
			   if (ObjResp != null && ObjResp.GetAllRefundEndpointTypeResponseData  != null && ObjResp.GetAllRefundEndpointTypeResponseData .Count > 0)
			   {
				   Resplst = ObjResp.GetAllRefundEndpointTypeResponseData;

				   IsBankExportTypeEnable = Resplst.Any(obj => obj.IsEnable == true && obj.EndPointName == (BankExportType.ABF).ToString());
			   }
			   if (IsBankExportTypeEnable)
			   {
				   accountsHashtable.Add(SubMenuKeyAccount.Refund_Export.ToString(), "Refund Export");
			   }
			//EOC Utkarsha(70)
				accountsHashtable = Base.GetMultilingualMessageList("Menu", accountsHashtable);
				accountsHashtable[SubMenuKeyAccount.Currency.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Currency.ToString()]) + "||../Pages/Product/Currencies.aspx"; //Virag D.
				accountsHashtable[SubMenuKeyAccount.Banked_Receipts.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Banked_Receipts.ToString()]) + "||../Pages/Finance/BankedReceipt.aspx"; //Kedar(12)
				accountsHashtable[SubMenuKeyAccount.Batch_Invoice_Creation.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Batch_Invoice_Creation.ToString()]) + "||../Pages/Finance/BatchInvoiceCreation.aspx"; //Harshad(19)
				//accountsHashtable[SubMenuKeyAccount.Purchase_Invoice_Creation.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Purchase_Invoice_Creation.ToString()]) + "||../Pages/Finance/PurChaseInvoiceCreation.aspx"; //Harshad(24) //Bipul(79)
				accountsHashtable[SubMenuKeyAccount.Purchase_Invoice_Creation.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Purchase_Invoice_Creation.ToString()]) + "||../Pages/Finance/PurchaseInvoiceCreationNew.aspx"; //Bipul(79)
				accountsHashtable[SubMenuKeyAccount.Reprint_Invoices.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Reprint_Invoices.ToString()]) + "||../Pages/Finance/ReprintInvoices.aspx";//Harshad(24)
				accountsHashtable[SubMenuKeyAccount.Purchase_Invoice_Import.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Purchase_Invoice_Import.ToString()]) + "||../PurchaseInvoiceImport/PurchaseInvoice";//Anshul(77)
				accountsHashtable[SubMenuKeyAccount.Exchange_Rates.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Exchange_Rates.ToString()]) + "||../Pages/Product/ExchangeRates.aspx"; //Sarika(14)
				accountsHashtable[SubMenuKeyAccount.Bank_Profiles.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Bank_Profiles.ToString()]) + "||../Pages/Finance/BankProfiles.aspx"; //Sudeep(15)
				accountsHashtable[SubMenuKeyAccount.Check_Commission_Payments.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Check_Commission_Payments.ToString()]) + "||../Pages/Finance/CheckCommissionPayments.aspx"; //SiddheshPrb(25)
				accountsHashtable[SubMenuKeyAccount.Batch_Voucher_Close.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Batch_Voucher_Close.ToString()]) + "||../BatchVoucherClose/BatchVoucherClose"; //Ravish(27) //Sunil(80)
			 
				accountsHashtable[SubMenuKeyAccount.Create_GL_Accounts.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Create_GL_Accounts.ToString()]) + "||../Pages/Product/GLAccounts.aspx"; //Deepa(28)
				accountsHashtable[SubMenuKeyAccount.Tax_Codes.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Tax_Codes.ToString()]) + "||../Pages/Finance/TaxCodes.aspx"; //Sarika(29)
				accountsHashtable[SubMenuKeyAccount.Export_Financial_Details.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Export_Financial_Details.ToString()]) + "||../Pages/Finance/ExportFinancialDetails.aspx"; //Harshad(44)
				accountsHashtable[SubMenuKeyAccount.Batch_Receipts_Entry.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Batch_Receipts_Entry.ToString()]) + "||../Pages/Finance/BatchReceiptsEntry.aspx";//Amey.R() //Gautami(62)
				accountsHashtable[SubMenuKeyAccount.Invoice_Daily_Exchange_Rates.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Invoice_Daily_Exchange_Rates.ToString()]) + "||../Pages/Product/InvoiceDailyExchangeRates.aspx";//Pranav(62)||Invoice Daily Exchange Rate
				if (IsBankExportTypeEnable)
				{
					accountsHashtable[SubMenuKeyAccount.Refund_Export.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Refund_Export.ToString()]) + "||../Pages/Finance/ExportRefundDetails.aspx";//Utkarsha(70)
				}
				accountsHashtable[SubMenuKeyAccount.Receipts_Reconciliation.ToString()] = Convert.ToString(accountsHashtable[SubMenuKeyAccount.Receipts_Reconciliation.ToString()]) + "||../ReceiptsReconciliation/ReceiptsReconciliation";//Poonam(82)
				htReturn = accountsHashtable;
				#endregion
				break;

			//BOC Jayesh(17)
			case "flights":
				Hashtable flightsHT = new Hashtable();
				flightsHT.Add(SubMenuKeyFlights.Airlines.ToString(), "Airlines");
				flightsHT.Add(SubMenuKeyFlights.Airports.ToString(), "Airports"); //Poonam(60)
				flightsHT.Add(SubMenuKeyFlights.Special_Requests.ToString(), "Special Requests"); //Wayne(23)
				flightsHT.Add(SubMenuKeyFlights.Schedule_Change_Manager.ToString(), "Schedule Change Manager"); //Siddhi B (74)
				flightsHT.Add(SubMenuKeyFlights.TermsAndConditions.ToString(), "Terms & Conditions"); //Wayne(26)
				flightsHT.Add(SubMenuKeyFlights.Flight_Service_Fees.ToString(), "Flight Service Fees"); //Kalpi(41)
				flightsHT.Add(SubMenuKeyFlights.Fare_Rules_Configuration.ToString(), "Fare Rules Configuration"); //Reema(47)
				flightsHT.Add(SubMenuKeyFlights.MarkUp_Rule_Priorities.ToString(), "Markup Rule Priorities"); //Reema(49)(53)
				flightsHT.Add(SubMenuKeyFlights.Fare_Increase_Decrease_Handling.ToString(), "Fare Increase/Decrease Handling"); //Sandip P.(50)
				flightsHT.Add(SubMenuKeyFlights.Agent_Flights_Commission.ToString(), "Agent Flights Commission"); //Rejeena

				flightsHT.Add(SubMenuKeyFlights.Agent_MarkUp_On_Service_Fee.ToString(), "Agent Markup on Service Fee"); //Ashley(55)
				flightsHT = Base.GetMultilingualMessageList("Menu", flightsHT);
				flightsHT[SubMenuKeyFlights.Airlines.ToString()] = Convert.ToString(flightsHT[SubMenuKeyFlights.Airlines.ToString()]) + "||../Pages/Product/Airlines.aspx";
				flightsHT[SubMenuKeyFlights.Airports.ToString()] = Convert.ToString(flightsHT[SubMenuKeyFlights.Airports.ToString()]) + "||../Pages/Product/AirportSearch.aspx"; //Poonam(60)
				flightsHT[SubMenuKeyFlights.Special_Requests.ToString()] = Convert.ToString(flightsHT[SubMenuKeyFlights.Special_Requests.ToString()]) + "||../Pages/Product/SpecialRequests.aspx"; //Wayne(23)
				flightsHT[SubMenuKeyFlights.Schedule_Change_Manager.ToString()] = Convert.ToString(flightsHT[SubMenuKeyFlights.Schedule_Change_Manager.ToString()]) + "||../FlightSCM/FlightSCMContainer";  //Siddhi B (74)//Pranav(75)
				flightsHT[SubMenuKeyFlights.TermsAndConditions.ToString()] = Convert.ToString(flightsHT[SubMenuKeyFlights.TermsAndConditions.ToString()]) + "||../Pages/Product/TermsAndConditions.aspx"; //Wayne(26)
				flightsHT[SubMenuKeyFlights.Flight_Service_Fees.ToString()] = Convert.ToString(flightsHT[SubMenuKeyFlights.Flight_Service_Fees.ToString()]) + "||../Pages/Product/FlightServiceFees.aspx"; //Kalpi(41)
				flightsHT[SubMenuKeyFlights.Fare_Rules_Configuration.ToString()] = Convert.ToString(flightsHT[SubMenuKeyFlights.Fare_Rules_Configuration.ToString()]) + "||../Pages/Product/FareRulesConfiguration.aspx"; //Reema(47)
				flightsHT[SubMenuKeyFlights.MarkUp_Rule_Priorities.ToString()] = Convert.ToString(flightsHT[SubMenuKeyFlights.MarkUp_Rule_Priorities.ToString()]) + "||../Pages/Product/MarkUpRulePriorities.aspx"; //Reema(49)
				flightsHT[SubMenuKeyFlights.Fare_Increase_Decrease_Handling.ToString()] = Convert.ToString(flightsHT[SubMenuKeyFlights.Fare_Increase_Decrease_Handling.ToString()]) + "||../Pages/Product/FareIncreaseDecreaseHandling.aspx"; //Sandip P.(50)
				flightsHT[SubMenuKeyFlights.Agent_MarkUp_On_Service_Fee.ToString()] = Convert.ToString(flightsHT[SubMenuKeyFlights.Agent_MarkUp_On_Service_Fee.ToString()]) + "||../Pages/Product/AgentMarkuponServiceFee.aspx";//Ashley(55)
				flightsHT[SubMenuKeyFlights.Agent_Flights_Commission.ToString()] = Convert.ToString(flightsHT[SubMenuKeyFlights.Agent_Flights_Commission.ToString()]) + "||../Pages/Product/AgentFlightsCommission.aspx"; //Rejeena

				htReturn = flightsHT;
				break;
			//EOC Jayesh(17)

				//BOC Sahil(75)
			case "catalog cache":
				#region CACHE SUB MENU

				Hashtable cacheHashtable = new Hashtable();
				if (GetEnableCatalogCacheFlag())
				{
				cacheHashtable.Add(SubMenuKeyCache.Cache_Rules.ToString(), "Cache Rules");
				cacheHashtable.Add(SubMenuKeyCache.Cache_Search_Criteria.ToString(), "Cache Search Criteria");
				cacheHashtable.Add(SubMenuKeyCache.Remote_Services.ToString(), "Remote Services");
					cacheHashtable.Add(SubMenuKeyCache.Cache_Statistics.ToString(), "Cache Statistics");
				cacheHashtable = Base.GetMultilingualMessageList("Menu", cacheHashtable);

				cacheHashtable[SubMenuKeyCache.Cache_Rules.ToString()] = Convert.ToString(cacheHashtable[SubMenuKeyCache.Cache_Rules.ToString()]) + "||../CacheRules/CacheRulesContainer";
				cacheHashtable[SubMenuKeyCache.Cache_Search_Criteria.ToString()] = Convert.ToString(cacheHashtable[SubMenuKeyCache.Cache_Search_Criteria.ToString()]) + "||../FlightCacheSearchCriteria/FlightCacheSearchCriteriaContainer";
				cacheHashtable[SubMenuKeyCache.Remote_Services.ToString()] = Convert.ToString(cacheHashtable[SubMenuKeyCache.Remote_Services.ToString()]) + "||../RemoteServices/RemoteServicesContainer";
					cacheHashtable[SubMenuKeyCache.Cache_Statistics.ToString()] = Convert.ToString(cacheHashtable[SubMenuKeyCache.Cache_Statistics.ToString()]) + "||../CacheStatistics/CacheStatisticsContainer";
				}
				htReturn = cacheHashtable;

				#endregion CACHE SUB MENU
				break;
				//EOC Sahil(75)
			//BOC Ritesh(98)
			case "training":
				#region TRAINING SUB MENU

				Hashtable trainingHashtable = new Hashtable();
				trainingHashtable.Add(SubMenuKeyTraining.Search_Service.ToString(), "Search Service");
				trainingHashtable = Base.GetMultilingualMessageList("Menu", trainingHashtable);

				trainingHashtable[SubMenuKeyTraining.Search_Service.ToString()] = 
					Convert.ToString(trainingHashtable[SubMenuKeyTraining.Search_Service.ToString()]) + "||../Pages/Training/ServiceSearchT.aspx";

				htReturn = trainingHashtable;
				#endregion
				break;
			//EOC Ritesh(98)
		}
		return htReturn;
	}
	private string GetNavigateURL(string submenu)
	{
		string ReturnVal = "../Pages/";
		if (submenu ==
		 SubMenuKeySystem.GeoTree.ToString() || submenu == SubMenuKeySystem.User_Manager.ToString() || submenu == SubMenuKeySystem.Mileage_Map.ToString()
			|| submenu == SubMenuKeySystem.Country.ToString() || submenu == SubMenuKeySystem.ChannelManagerConfiguration.ToString())//CANDIDA(67)
		{
			ReturnVal += "System";
		}
		/*
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Country.ToString()].ToString(), SubMenuKeySystem.Country.ToString(), MenuKeyIndex.System, "../Pages/System/Country.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Statuses.ToString()].ToString(), SubMenuKeySystem.Statuses.ToString(), MenuKeyIndex.System, "../Pages/Product/Status.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Types.ToString()].ToString(), SubMenuKeySystem.Types.ToString(), MenuKeyIndex.System, "../Pages/Product/Types.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Charging_Duration.ToString()].ToString(), SubMenuKeySystem.Charging_Duration.ToString(), MenuKeyIndex.System, "../Pages/Product/ChargingDuration.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Charging_Policy.ToString()].ToString(), SubMenuKeySystem.Charging_Policy.ToString(), MenuKeyIndex.System, "../Pages/Product/ChargingPolicy.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Image.ToString()].ToString(), SubMenuKeySystem.Image.ToString(), MenuKeyIndex.System, "../Pages/Product/ImageSearch.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Meal_Plan.ToString()].ToString(), SubMenuKeySystem.Meal_Plan.ToString(), MenuKeyIndex.System, "../Pages/Product/MealPlan.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Message_Editor.ToString()].ToString(), SubMenuKeySystem.Message_Editor.ToString(), MenuKeyIndex.System, "");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Rules.ToString()].ToString(), SubMenuKeySystem.Rules.ToString(), MenuKeyIndex.System, "../Pages/Product/Rules.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.User_Manager.ToString()].ToString(), SubMenuKeySystem.User_Manager.ToString(), MenuKeyIndex.System, "../Pages/System/UserManager.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Organisation.ToString()].ToString(), SubMenuKeySystem.Organisation.ToString(), MenuKeyIndex.System, "../Pages/Organisation/Organisation.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Mileage_Map.ToString()].ToString(), SubMenuKeySystem.Mileage_Map.ToString(), MenuKeyIndex.System, "../Pages/System/MileageMap.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Commission_Maintenance.ToString()].ToString(), SubMenuKeySystem.Commission_Maintenance.ToString(), MenuKeyIndex.System, "../Pages/Product/CommisionScheme.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Default_Booking_Tasks.ToString()].ToString(), SubMenuKeySystem.Default_Booking_Tasks.ToString(), MenuKeyIndex.System, "");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Messaging_Settings.ToString()].ToString(), SubMenuKeySystem.Auto_Messaging.ToString(), MenuKeyIndex.System, "../Pages/Messaging/TSWeb.aspx");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.End_Point_Configuration.ToString()].ToString(), SubMenuKeySystem.End_Point_Configuration.ToString(), MenuKeyIndex.System, "");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.Import_External_Services.ToString()].ToString(), SubMenuKeySystem.Import_External_Services.ToString(), MenuKeyIndex.System, "");
		AddNewSubMenuItem(systemHashtable[SubMenuKeySystem.QA_Scripts.ToString()].ToString(), SubMenuKeySystem.QA_Scripts.ToString(), MenuKeyIndex.System, "../Pages/System/QAScripts.aspx");
		*/
		//"../Pages/System/GeoTree.aspx");
		return ReturnVal;
	}
	//BOC Sarika(36)   commented foll code 
	protected void btnLogout_Click(object sender, EventArgs e)
	{
		//Release the Licence
		//Sriker(31) Commented 
		//string strSecurityKey = SessionManager.TSBSession.SecurityKey;
		//ServiceProxyManager.Factory.SystemSetup.UserFactory objUserFactory = new ServiceProxyManager.Factory.SystemSetup.UserFactory();
		//objUserFactory.ReleaseLicence(strSecurityKey);

	   // HttpContext.Current.Session.Abandon();
		//BOC PNaik(78)
		var pageUrl = !Request.ApplicationPath.EndsWith("/") ? Request.ApplicationPath + "/" : Request.ApplicationPath;
		var url = string.Format("{0}Login/LogOut", pageUrl);
		//BOC PNaik(78)
		//BOC Sarika(57)
		if (Session["WinAuth"] != null && Session["WinAuth"].ToString() == "1")
			Response.Redirect(url, true);//PNaik(78)
	   
		else
			//EOC Sarika(57)
			Response.Redirect(url); //Sarika(60) //PNaik(78)
	}
	//EOC Sarika(36)   commented abv code 

	//BOC Silvia(20)
	protected bool CheckReportsPermission()
	{
		if ((UserSecurity.GetMenuAccessRights("", "Allocation Usage Graph Report Screen", 25100)) ||
			(UserSecurity.GetMenuAccessRights("", "AutoMessaging Failed Messages", 28130)) ||
			(UserSecurity.GetMenuAccessRights("", "Booking Notes Report Screen ", 25080)) ||
			(UserSecurity.GetMenuAccessRights("", "Booking Report Screen", 25000)) ||
			(UserSecurity.GetMenuAccessRights("", "Finance Report Screen", 25060)) ||
			(UserSecurity.GetMenuAccessRights("", "Package Report Screen", 25090)) ||
			(UserSecurity.GetMenuAccessRights("", "Quote Reports Screen", 25070)) ||
			(UserSecurity.GetMenuAccessRights("", "Rail Report Screen", 400580)) ||
			(UserSecurity.GetMenuAccessRights("", "Service Report Screen", 25010)) ||
			(UserSecurity.GetMenuAccessRights("", "Supplier Report Screen", 25020)) ||
			(UserSecurity.GetMenuAccessRights("", "Tariff Export Report Screen", 25040)))

			return true;
		else
			return false;

	}
	//EOC Silvia(20)

	//BOC Abhijit L.(41)
	public static IDictionary SortHashtable(Hashtable ht)
	{
		return new SortedList((IDictionary)ht);

	}

	//BOC Dejalin(65)
	protected bool GetEnableOperationalModuleFlag()
	{
		bool bReturn = false;
		ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequest ObjReq = new ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequest();
		ObjReq.GetSystemWideSettingsRequestData = new ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsRequestData();
		ObjReq.GetSystemWideSettingsRequestData.SystemType = ServiceProxyManager.ProxyClasses.SystemSetup.SystemTypes.Booking;
		System.Collections.Generic.List<string> FieldNames = new System.Collections.Generic.List<string>();
		FieldNames.Add(Convert.ToString(ServiceProxyManager.ProxyClasses.SystemSetup.BookingSettingsColumnNames.EnableOperationsModule));
		ObjReq.GetSystemWideSettingsRequestData.ColumnNames = FieldNames;
		ServiceProxyManager.Factory.SystemSetup.OrganisationFactory ObjFactory = new ServiceProxyManager.Factory.SystemSetup.OrganisationFactory();
		ServiceProxyManager.ProxyClasses.SystemSetup.GetSystemWideSettingsResponse ObjResp = ObjFactory.GetSystemWideSettings(ObjReq);
		if (ObjResp != null && ObjResp.GetSystemWideSettingResponseData != null && ObjResp.GetSystemWideSettingResponseData.Count > 0)
		{
			// return Convert.ToBoolean(ObjResp.GetSystemWideSettingResponseData.First().FieldValue);
			Hashtable ObjHshTbl = new Hashtable();
			foreach (GetSystemWideSettingsResponseData Objres in ObjResp.GetSystemWideSettingResponseData)
			{
				ObjHshTbl.Add(Objres.FieldName, Objres.FieldValue);

			}
			bReturn = (ObjHshTbl[BookingSettingsColumnNames.EnableOperationsModule.ToString()]).ToString() == "0" ? false : true;
		}
		return bReturn;
	}

	private string GetDatabaseName()
	{
		string dbName="";
		IDbConnection connection = new SqlConnection(SessionManager.TSBSession.ConnectionString);
		dbName= connection.Database.Trim();
		return dbName;
	}


	//EOC Dejalin(65)


	//EOC Abhijit L.(41)

	//Sriker(08) Commented
	//BOC by Naadia Khan(01)
	//protected void GetUserName()
	//{
	//    try
	//    {
	//        //Log to Audit manager
	//        AuditManager.AuditManager.Log("UtilityControls.usrctl_mainmenu : GetUserName", "Start", AuditManager.AuditManager.AuditType.Debug, AuditManager.AuditManager.ApplicationLayer.Website);

	//        ServiceProxyManager.Factory.SystemSetup.UserFactory objUser = new ServiceProxyManager.Factory.SystemSetup.UserFactory();
	//        ServiceProxyManager.ProxyClasses.SystemSetup.GetUserResponse objResponse = new ServiceProxyManager.ProxyClasses.SystemSetup.GetUserResponse();

	//        int? UserId = null;

	//        if (SessionManager.TSBSession.UserID != "" || SessionManager.TSBSession.UserID != null)
	//            UserId = Convert.ToInt32(SessionManager.TSBSession.UserID);

	//        objResponse = objUser.GetUser(UserId, null);

	//        if (objResponse != null && objResponse.GetUserResponseData != null)
	//        {
	//            if (objResponse.GetUserResponseData.UserList.Count > 0)
	//                LnkUserName.Text = objResponse.GetUserResponseData.UserList[0].FirstName + " " + objResponse.GetUserResponseData.UserList[0].SystemUserName;
	//        }
	//        LnkUserName.ToolTip = SessionManager.TSBSession.UserName;

	//        //Log to Audit manager
	//        AuditManager.AuditManager.Log("UtilityControls.usrctl_mainmenu : GetUserName", "End", AuditManager.AuditManager.AuditType.Debug, AuditManager.AuditManager.ApplicationLayer.Website);

	//    }
	//    catch (Exception ex)
	//    {
	//        //Log to Audit manager
	//        AuditManager.AuditManager.Log("UtilityControls.usrctl_mainmenu : GetUserName", "Error", AuditManager.AuditManager.AuditType.Debug, AuditManager.AuditManager.ApplicationLayer.Website);
	//        string popupScript = "alert('" + ex.Message.ToString() + "')";
	//        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "clientScript", popupScript, true);
	//    }

	//}
	//EOC by Naadia Khan(01)
	//EOC ashfaq(6)
	public enum BankExportType
	{
		None,
		ABF
	}
}


//EOC Prasad(05)
////Add Header Menus that are visible
//protected void AddNewMenuItem1(string MenuDisplayName, string MenuKey, string MenuImgName)
//{
//    //if (UserSecurity.GetMenuAccessRights(MenuKey, ""))
//    //{
//    MenuItem ObjNewMenuItem = new MenuItem();
//    ObjNewMenuItem.ImageUrl = "../Masters/Images/" + MenuImgName + ".png";

//    //    string[] strSplitedMulitlingualText = GetTextWithToolTip(MenuDisplayName);
//    //  MenuDisplayName = Convert.ToString(strSplitedMulitlingualText[0]);
//    ObjNewMenuItem.Text = MenuDisplayName;
//    //if (strSplitedMulitlingualText.Length > 1)
//    //    ObjNewMenuItem.ToolTip = Convert.ToString(strSplitedMulitlingualText[1]);

//    ObjNewMenuItem.Value = MenuDisplayName; // MenuKey.ToString();
//    ObjNewMenuItem.Selectable = false;

//    if (!mnu_TSBrowser.Items.Contains(ObjNewMenuItem))
//    {
//        mnu_TSBrowser.Items.Add(ObjNewMenuItem);
//    }
//    //}
//}


////To Add Sub Menu to the Header menus
//protected void AddNewSubMenuItem1(string MenuDisplayName, string MenuKey, MenuKeyIndex ParentMenuKey, string NavigateURL)
//{
//    MenuItem SelectedMenuItem = mnu_TSBrowser.FindItem(ParentMenuKey.ToString());
//    if (SelectedMenuItem != null)
//    {
//        //if (UserSecurity.GetMenuAccessRights("", MenuKey))
//        //{
//        MenuItem ObjNewMenuItem = new MenuItem();
//        ObjNewMenuItem.ImageUrl = "";

//        string[] strSplitedMulitlingualText = GetTextWithToolTip(MenuDisplayName);
//        MenuDisplayName = Convert.ToString(strSplitedMulitlingualText[0]);
//        ObjNewMenuItem.Text = MenuDisplayName;
//        if (strSplitedMulitlingualText.Length > 1)
//            ObjNewMenuItem.ToolTip = Convert.ToString(strSplitedMulitlingualText[1]);

//        if (MenuKey != string.Empty)
//            ObjNewMenuItem.Value = MenuKey.ToString();
//        else
//            ObjNewMenuItem.Value = MenuDisplayName.ToString();

//        ObjNewMenuItem.NavigateUrl = NavigateURL;


//        //select the menu visible menu item based on the index number
//        //   MenuItem SelectedMenuItem = mnu_TSBrowser.Items[(int)ParentMenuKey]; // Silvia - will not work as the indexes change when some menu are not created

//        ////Disable other menus done only for WTM
//        //if ((ParentMenuKey.ToString() != "System") && (ParentMenuKey.ToString() != "Products"))
//        //{
//        //    ObjNewMenuItem.Enabled = false;

//        //}
//        //else if (ParentMenuKey.ToString() == "System")
//        //{
//        //    if ((ObjNewMenuItem.Text == "Mileage Map") || (ObjNewMenuItem.Text == "Message Editor") || (ObjNewMenuItem.Text == "Mileage Map")
//        //    || (ObjNewMenuItem.Text == "End Point Configuration") || (ObjNewMenuItem.Text == "Messaging Settings") || (ObjNewMenuItem.Text == "Defaults Booking Tasks")
//        //        || (ObjNewMenuItem.Text == "Default Booking Tasks"))
//        //    {
//        //        ObjNewMenuItem.Enabled = false;
//        //    }
//        //}
//        //else if (ParentMenuKey.ToString() == "Products")
//        //{
//        //    if ((ObjNewMenuItem.Text != "Service") && (ObjNewMenuItem.Text != "Contract") && (ObjNewMenuItem.Text != "Web Passenger Questions") && (ObjNewMenuItem.Text != "Service Type Questions"))
//        //    {
//        //        ObjNewMenuItem.Enabled = false;
//        //    }

//        //}
//        //End code for WTM
//        // Insert the submenu item in the ChildItems collection of the root menu item at index number.
//        SelectedMenuItem.ChildItems.Add(ObjNewMenuItem);
//        // }
//    }
//}

//protected void AddMenu(Hashtable HashTable)
//{
//    foreach (DictionaryEntry objHashTable in HashTable)
//    {
//        if (UserSecurity.GetMenuAccessRights(objHashTable.Key.ToString(), ""))
//        {
//            MenuItem ObjNewMenuItem = new MenuItem();
//            ObjNewMenuItem.ImageUrl = "../Masters/Images/" + objHashTable.Key.ToString() + ".png";
//            ObjNewMenuItem.Text = objHashTable.Value.ToString().ToString();
//            ObjNewMenuItem.Value = objHashTable.Key.ToString();
//            if (!mnu_TSBrowser.Items.Contains(ObjNewMenuItem))
//            {
//                mnu_TSBrowser.Items.Add(ObjNewMenuItem);
//            }
//        }
//    }
//}
