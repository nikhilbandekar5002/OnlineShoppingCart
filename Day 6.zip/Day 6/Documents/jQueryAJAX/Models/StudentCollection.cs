﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace jQueryAJAX.Models
{
    public class StudentCollection : List<Student>
    {
        public StudentCollection()
        {
            Add(new Student { StudentId = 1, StudentName = "John", Marks = 78 });
            Add(new Student { StudentId = 2, StudentName = "Abby", Marks = 58 });
            Add(new Student { StudentId = 3, StudentName = "Kevin", Marks = 88 });
            Add(new Student { StudentId = 4, StudentName = "Albert", Marks = 48 });
            Add(new Student { StudentId = 5, StudentName = "Simeon", Marks = 38 });
            Add(new Student { StudentId = 6, StudentName = "Perry", Marks = 68 });
            Add(new Student { StudentId = 7, StudentName = "Paul", Marks = 65 });
            Add(new Student { StudentId = 8, StudentName = "James", Marks = 66 });
            Add(new Student { StudentId = 9, StudentName = "Sam", Marks = 18 });
            Add(new Student { StudentId = 10, StudentName = "Peter", Marks = 68 });
            Add(new Student { StudentId = 11, StudentName = "Kate", Marks = 95 });
            Add(new Student { StudentId = 12, StudentName = "Sally", Marks = 38 });
        }
    }
}