﻿/// <reference path="jquery-3.1.1.js" />


$(document).ready(function()
{
    $("#btnSearch").click(function () {

        $.ajax({
            type: "POST",
            url: "StudentWebService.asmx/GetStudents",
            data: '{ name: "' + $("#txtName").val().trim() + '" }',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                var divResult = $('#divResult');

                divResult.html("");
                var studs = response.d;

                var result = "";
                $.each(studs, function (index, stud) {
                    //Add as last child
                    //divResult.append('<p><strong>' + stud.StudentId + ' ' +
                    //                      stud.StudentName + '</strong><br />' +
                    //                      stud.Marks + '</p>');

                    result += '<p><strong>' + stud.StudentId + ' ' +
                            stud.StudentName + '</strong><br />' +
                            stud.Marks + '</p>'
                });

                divResult.html(result);
            },
            failure: function (msg) {
                $('#divResult').html(msg);
            }
        });

    });

})