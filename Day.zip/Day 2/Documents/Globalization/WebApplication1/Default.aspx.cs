﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Default : System.Web.UI.Page
    {

        protected override void InitializeCulture()
        {
            string selLanguage = Request["dpLang"];
            if (!string.IsNullOrEmpty(selLanguage))
            {
                CultureInfo ci = new CultureInfo(selLanguage);
                Thread.CurrentThread.CurrentCulture = ci;
                Thread.CurrentThread.CurrentUICulture = ci;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Request["dpLang"]))
            {
                dpLang.SelectedValue = Thread.CurrentThread.CurrentCulture.Name;
            }

            txtName.Text = GetGlobalResourceObject("GlbResource", "someText").ToString();

            //OR
            txtName.Text = Resources.GlbResource.someText;
        }

        protected void btnGreet_Click(object sender, EventArgs e)
        {
            double amount = 5600.45;
            lblMessage.Text = amount.ToString("C");
        }
    }
}