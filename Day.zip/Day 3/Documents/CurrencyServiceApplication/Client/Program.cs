﻿using Client.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            CurrencyWebServiceSoapClient proxy = new CurrencyWebServiceSoapClient();
            Console.WriteLine(proxy.GetCurrencySymbol("US"));

            Console.ReadKey();
        }
    }
}
