﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using System.Globalization;

namespace CurrencyServiceApplication
{
    /// <summary>
    /// Summary description for CurrencyWebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    public class CurrencyWebService : System.Web.Services.WebService
    {

        [WebMethod]
        public string GetCurrencySymbol(string regionCode)
        {
            RegionInfo ri = new RegionInfo(regionCode);
            return ri.CurrencySymbol;
        }

        [WebMethod]
        public string GetISOCurrencySymbol(string regionCode)
        {
            RegionInfo ri = new RegionInfo(regionCode);
            return ri.ISOCurrencySymbol;
        }
    }
}
