﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DALOnlineShoppingCart;
using BEOnlineShoppingCart;

namespace BALOnlineShoppingCart
{
    public class OrderBAL
    {

        OrderDAL orderDAL = new OrderDAL();

        public OrderResponseBE AddOrder(OrderRequestBE request)
        {
            OrderResponseBE response = null;

            try
            {
                response = orderDAL.AddOrder(request);
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new OrderResponseBE();
                }

                response.ErrorCode = 101;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }


        public OrderResponseBE FetchProduct()
        {
            OrderResponseBE response = null;

            try
            {
                response = orderDAL.FetchProduct();
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new OrderResponseBE();
                }

                response.ErrorCode = 102;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }
    }
}
