﻿function Focus(objname, waterMarkText) {
    obj = document.getElementById(objname);
    if (obj.value == waterMarkText) {
        obj.value = "";
        obj.className = "NormalTextBox";
    }
}
function Blur(objname, waterMarkText) {
    obj = document.getElementById(objname);
    if (obj.value == "") {
        obj.value = waterMarkText;
        obj.className = "WaterMarkedTextBox";
    }
    else {
        obj.className = "NormalTextBox";
    }
}


$(document).ready(function () {

    $("#form1").validate({
        focusInvalid: false,
        focusCleanup: true,
        debug: false,
        onkeyup: false,
         onclick: true,
         onsubmit: true,
         onkeyup: false,

        rules: {

            txtUserName: { required: true }        
        },


        messages: {
            txtUserName: {
                    required: "Please enter User Name"
            }
            
        }
    });
   
});

