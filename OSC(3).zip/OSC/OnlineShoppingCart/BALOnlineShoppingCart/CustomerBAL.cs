﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BEOnlineShoppingCart;
using DALOnlineShoppingCart;

namespace BALOnlineShoppingCart
{
    public class CustomerBAL
    {
        CustomerDAL customerDal = new CustomerDAL();

        public CustomerResponseBE LoginCredential(CustomerRequestBE request)
        {
            CustomerResponseBE response = null;

            try
            {
                response = customerDal.LoginCredential(request);
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 100;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }

        public CustomerResponseBE Register(CustomerRequestBE request)
        {
            CustomerResponseBE response = null;

            try
            {
                response = customerDal.Register(request);
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 101;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }


        public CustomerResponseBE AddOrder(CustomerRequestBE request)
        {
            CustomerResponseBE response = null;

            try
            {
                response = customerDal.AddOrder(request);
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 101;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }


        public CustomerResponseBE FetchProduct()
        {
            CustomerResponseBE response = null;

            try
            {
                response = customerDal.FetchProduct();
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 102;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }




        public CustomerResponseBE FetchStates()
        {
            CustomerResponseBE response = null;

            try
            {
                response = customerDal.FetchStates();
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 102;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }
    }
}
