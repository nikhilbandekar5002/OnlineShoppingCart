﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Transactions;
using BEOnlineShoppingCart;

namespace DALOnlineShoppingCart
{
    public class CustomerDAL
    {
        public static string connectionstr = ConfigurationManager.ConnectionStrings["OnlineShoppingNikhil"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionstr);


        public CustomerResponseBE Register(CustomerRequestBE request)
        {
            CustomerResponseBE response = new CustomerResponseBE();

            try
            {

                con.Open();
                using (var transaction = con.BeginTransaction())
                {
                    
                    SqlCommand cmd = new SqlCommand("usp_REGISTER", con, transaction);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@USERNAME", request.UserName);
                    cmd.Parameters.AddWithValue("@CONTACTNO", request.ContactNo);
                    cmd.Parameters.AddWithValue("@EMAIL", request.Email);
                    cmd.Parameters.AddWithValue("@ADDRESS", request.Address);
                    cmd.Parameters.AddWithValue("@MARRIED", request.Married);
                    cmd.Parameters.AddWithValue("@STATE", request.State);
                    cmd.Parameters.AddWithValue("@ZIPCODE", request.ZipCode);
                    cmd.Parameters.AddWithValue("@DATEOFJOIN", request.DateOfBirth);

                    SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                    statusParameter.Direction = ParameterDirection.Output;

                    SqlParameter userIDParameter = cmd.Parameters.Add("@USERID", SqlDbType.Int);
                    userIDParameter.Direction = ParameterDirection.Output;



                    cmd.ExecuteScalar();
                    response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);
                    response.UserID = Convert.ToInt32(cmd.Parameters["@USERID"].Value);


                    if (response.Status >= 1)
                    {
                        cmd = new SqlCommand("usp_LOGINDTLS", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@USERID", response.UserID);
                        cmd.Parameters.AddWithValue("@USERNAME", request.UserName);
                        cmd.Parameters.AddWithValue("@PASSWORD", request.Password);



                        cmd.Transaction = transaction;
                        response.Status = cmd.ExecuteNonQuery();



                    }

                    if (response.Status >= 1)
                    {
                        transaction.Commit();

                    }
                    con.Close();
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                con.Close();
            }

            return response;

        }


        public CustomerResponseBE LoginCredential(CustomerRequestBE request)
        {
            CustomerResponseBE response = new CustomerResponseBE();

            try
            {
                SqlCommand cmd = new SqlCommand("usp_Login", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@USERNAME", request.UserName);
                cmd.Parameters.AddWithValue("@PASSWORD", request.Password);

                
                SqlParameter userIDParameter = cmd.Parameters.Add("@USERID", SqlDbType.Int);
                userIDParameter.Direction = ParameterDirection.Output;

                SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;

                con.Open();
                response.UserName = Convert.ToString(cmd.ExecuteScalar());
                response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);
                response.UserID = Convert.ToInt32(cmd.Parameters["@USERID"].Value); ;
                con.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
            }

            return response;

        }


        public CustomerResponseBE AddOrder(CustomerRequestBE request)
        {
            CustomerResponseBE response = new CustomerResponseBE();

            try
            {
                SqlCommand cmd = new SqlCommand("usp_AddOrder", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@USERID", request.UserID);
                cmd.Parameters.AddWithValue("@PRODUCTNAME", request.Product);
                cmd.Parameters.AddWithValue("@QUANTITY", request.Quantity);
                cmd.Parameters.AddWithValue("@PRICE", request.Price);
                SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;

                con.Open();
                //response.UserName = Convert.ToString(cmd.ExecuteScalar());
                response.Status = Convert.ToInt32(cmd.ExecuteScalar());
                //response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);
                con.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
            }

            return response;

        }



        public CustomerResponseBE FetchProduct()
        {
            CustomerResponseBE response = new CustomerResponseBE();

            try
            {
                string query = "usp_FETCHPRODUCTDETAILS";
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);

                foreach (DataRow row in dt.Rows)
                {
                    ProductInfo productItem = new ProductInfo();
                    productItem.ProductName = row[0].ToString();
                    productItem.Price = Convert.ToInt32(row[1].ToString());
                    response.ProductList.Add(productItem);
                }

                con.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
            }

            return response;

        }



        public CustomerResponseBE FetchStates()
        {
            CustomerResponseBE response = new CustomerResponseBE();

            try
            {
                string query = "usp_FETCHSTATES";
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);

                foreach (DataRow row in dt.Rows)
                {                  
                    response.States.Add(row[0].ToString());
                }

                con.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
            }

            return response;

        }
    }
}
