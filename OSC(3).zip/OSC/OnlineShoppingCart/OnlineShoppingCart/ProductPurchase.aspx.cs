﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BALOnlineShoppingCart;
using BEOnlineShoppingCart;

namespace OnlineShoppingCart
{
    public partial class ProductPurchase : System.Web.UI.Page
    {

        public static CustomerBAL customerBAL = new CustomerBAL();
      

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                CustomerResponseBE response = customerBAL.FetchProduct();
                grdProducts.DataSource = response.ProductList;
                grdProducts.DataBind();
            }
            catch(Exception)
            {
                throw;
            }
        }

       

        protected void grdProducts_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdProducts.PageIndex = e.NewPageIndex;
            grdProducts.DataBind();
        }

        protected void grdProducts_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (e.CommandName == "AddToCart")
                {
                    int index = Convert.ToInt32(e.CommandArgument);

                    GridViewRow row = grdProducts.Rows[index];

                    CustomerRequestBE request = new CustomerRequestBE();

                    request.UserID = Convert.ToInt32(Session["UserID"].ToString());
                    request.Product = row.Cells[0].Text.Trim();
                    request.Quantity = Convert.ToInt32((row.FindControl("nudQuantity") as UserControls.NumericUpDown).EnteredNumber);
                    request.Price = Convert.ToInt32(row.Cells[2].Text.Trim());
                    request.OrderStatus = "ADDEDTOCART";
             
                    customerBAL.AddOrder(request);
                   
                }
            }
            catch(Exception)
            {
                throw;
            }
        }

    
    }
}