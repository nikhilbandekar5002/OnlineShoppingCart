﻿function Focus(objname, waterMarkText) {
    obj = document.getElementById(objname);
    if (obj.value == waterMarkText) {
        obj.value = "";
        obj.className = "NormalTextBox";
    }
}
function Blur(objname, waterMarkText) {
    obj = document.getElementById(objname);
    if (obj.value == "") {
        obj.value = waterMarkText;
        obj.className = "WaterMarkedTextBox";
    }
    else {
        obj.className = "NormalTextBox";
    }
}


$(document).ready(function () {

    $("#form1").validate({
        focusInvalid: false,
        focusCleanup: true,
        debug: false,
        onkeyup: false,
         onclick: true,
         onsubmit: true,
         onkeyup: false,

        rules: {

            txtUserName: { required: true },

            txtContactNo: { required: true, number: true, minlength: 10, maxlength: 10  },
      
            txtEmail: { required: true, email: true },
            txaAddress: { required: true },
            txtZipCode: { maxlength: 6, number: true },
            //rdoMarried: { required: true },
            //txtCalender: { required: true },
            //drpState: { required: true },
            //txtPassword: { required: true, minlength: 8, matches: "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})"},
            txtConfirmPass: { required: true, equalTo: "#txtPassword" }
        
           
        


        
        },


        messages: {
            txtUserName: { required: "Please Enter UserName" },

            txtContactNo: {
                required: "Please Enter Contact No.",
                number: "Please Enter Only Digits",
                minlength: "Please Enter 10 Digits"
            },

           

            txtEmail: { required: "Please Enter Email ID", email: "Invalid Email ID" },

            txaAddress: { required: "Please Enter Address" },

            txtZipCode: { maxlength: "Please Enter 6 digits code", number: "Please enter numeric code" },

            //rdoMarried: { required: "Please Select One Option" },

            //dateOfBirth: { required: "Please Enter your Date Of Birth" },

            //drpState: { required: "Please Select State" },

            //txtPassword: { required: "Please Enter Password", minlength: "Password must be minimum 8 characters", matches: "Must contain atleast 1 small,Capital,number & Special Symbol" },

            txtConfirmPass: { required: "Please Re-Enter Password", equalTo: "Password does not match"}




            


            
        }
    });
   
});

