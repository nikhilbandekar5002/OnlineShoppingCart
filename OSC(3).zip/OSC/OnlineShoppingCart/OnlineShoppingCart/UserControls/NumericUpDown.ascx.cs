﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineShoppingCart.UserControls
{
    public partial class NumericUpDown : System.Web.UI.UserControl
    {


        public int EnteredNumber
        {
            get { return Convert.ToInt32((txtNumber.Text)); }

            set
            {
                txtNumber.Text = value.ToString();
            }

        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}