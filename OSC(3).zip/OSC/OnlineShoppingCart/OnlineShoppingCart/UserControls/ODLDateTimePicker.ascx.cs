﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineShoppingCart.User_Controls
{
    public partial class ODLDateTimePicker : System.Web.UI.UserControl
    {
        public DateTime SelectedDate
        {
            get { return Convert.ToDateTime(txtCalender.Text); }

            set 
            {
                txtCalender.Text = value.ToString();
            }

        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}