﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using BEOnlineShoppingCart;
using System.Data;

namespace DALOnlineShoppingCart
{
    public class OrderDAL
    {
        public static string connectionstr = ConfigurationManager.ConnectionStrings["OnlineShopping"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionstr);

        public OrderResponseBE AddOrder(OrderRequestBE request)
        {
            OrderResponseBE response = new OrderResponseBE();

            try
            {
                SqlCommand cmd = new SqlCommand("usp_AddOrder", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@USERNAME", request.UserName);
                cmd.Parameters.AddWithValue("@PRODUCTNAME", request.Product);
                cmd.Parameters.AddWithValue("@QUANTITY", request.Quantity);
                cmd.Parameters.AddWithValue("@PRICE", request.Price);
                SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;

                con.Open();
                //response.UserName = Convert.ToString(cmd.ExecuteScalar());
                response.Status = Convert.ToInt32(cmd.ExecuteScalar());
                //response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);
                con.Close();
            }
            catch (Exception)
            {
                throw;
            }

            return response;

        }



        public OrderResponseBE FetchProduct()
        {
            OrderResponseBE response = new OrderResponseBE();

            try
            {
                string query = "usp_FETCHPRODUCTDETAILS";
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);

                foreach(DataRow row in dt.Rows)
                {
                    ProductInfo productItem = new ProductInfo();
                    productItem.ProductName = row[0].ToString();
                    productItem.Price = Convert.ToInt32(row[1].ToString());
                    response.ProductList.Add(productItem);
                }
                
                con.Close();
            }
            catch (Exception)
            {
                throw;
            }

            return response;

        }
    }
}
