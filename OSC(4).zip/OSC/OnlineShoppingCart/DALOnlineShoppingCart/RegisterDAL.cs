﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BEOnlineShoppingCart;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Transactions;


namespace DALOnlineShoppingCart
{
    public class RegisterDAL
    {

        public static string connectionstr = ConfigurationManager.ConnectionStrings["OnlineShopping"].ConnectionString;
     

        
        public RegisterResponseBE LoginCredential(RegisterRequestBE request)
        {
            RegisterResponseBE response = new RegisterResponseBE();

            try
            {
                SqlConnection con = new SqlConnection(connectionstr);
                con.Open();
                using(var transaction = con.BeginTransaction())
                {
                    
                    SqlCommand cmd = new SqlCommand("usp_REGISTER", con,transaction);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@USERNAME", request.UserName);
                    cmd.Parameters.AddWithValue("@CONTACTNO", request.ContactNo);
                    cmd.Parameters.AddWithValue("@EMAIL", request.Email);
                    cmd.Parameters.AddWithValue("@AGE", request.Age);
                    cmd.Parameters.AddWithValue("@ADDRESS", request.Address);
                    cmd.Parameters.AddWithValue("@MARRIED", request.Married);
                    cmd.Parameters.AddWithValue("@STATE", request.State);
                    cmd.Parameters.AddWithValue("@ZIPCODE", request.ZipCode);
                    cmd.Parameters.AddWithValue("@DATEOFJOIN", request.DateOfJoin);

                    SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                    statusParameter.Direction = ParameterDirection.Output;

                    SqlParameter userIDParameter = cmd.Parameters.Add("@USERID", SqlDbType.Int);
                    userIDParameter.Direction = ParameterDirection.Output;

                    
 
                        cmd.ExecuteScalar();
                    response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);
                    response.UserID = Convert.ToInt32(cmd.Parameters["@USERID"].Value);
                  

                    if(response.Status >= 1)
                    {
                        cmd = new SqlCommand("usp_LOGINDTLS", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@USERID", response.UserID);
                        cmd.Parameters.AddWithValue("@USERNAME", request.UserName);
                        cmd.Parameters.AddWithValue("@PASSWORD", request.Password);



                        cmd.Transaction = transaction;
                        response.Status = cmd.ExecuteNonQuery();
                        
                     

                    }

                    if(response.Status >= 1)
                    {
                        transaction.Commit();
                  
                    }
                  
                }
            }
            catch (Exception)
            {
                
                throw;
            }
            

            return response;

        }
    }
}
