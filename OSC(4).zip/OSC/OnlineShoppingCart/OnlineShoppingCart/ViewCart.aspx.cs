﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BALOnlineShoppingCart;
using BEOnlineShoppingCart;

namespace OnlineShoppingCart
{
    public partial class ViewCart : System.Web.UI.Page
    {

        public static CustomerBAL customerBAL = new CustomerBAL();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    CustomerRequestBE request = new CustomerRequestBE();

                    request.UserID = Convert.ToInt32(Session["UserID"].ToString());

                    CustomerResponseBE response = customerBAL.FetchCart(request);

                    if (response.ProductList.Count != 0)
                    {
                        grdProducts.DataSource = response.ProductList;
                        grdProducts.DataBind();
                        lblMsg.Visible = false;
                    }
                    else
                    {
                        lblMsg.Visible = true;
                        grdProducts.Visible = false;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        protected void grdProducts_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdProducts.PageIndex = e.NewPageIndex;
            BindData();
        }

        public void BindData()
        {
            CustomerResponseBE response = customerBAL.FetchProduct();
            grdProducts.DataSource = response.ProductList;
            grdProducts.DataBind();
        }

        protected void grdProducts_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (e.CommandName == "UpdateCart")
                {

                    int index = Convert.ToInt32(e.CommandArgument);

                    GridViewRow row = grdProducts.Rows[index];



                    CustomerRequestBE request = new CustomerRequestBE();

                    request.UserID = Convert.ToInt32(Session["UserID"].ToString());
                    request.Product = row.Cells[0].Text.Trim();
                    request.Quantity = Convert.ToInt32((row.FindControl("nudQuantity") as UserControls.NumericUpDown).EnteredNumber);
                    request.Price = Convert.ToInt32(row.Cells[2].Text.Trim()) * request.Quantity;
                    request.OrderStatus = "ADDEDTOCART";

                    
                    customerBAL.AddOrder(request);
                    

                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        protected void btnBuy_Click(object sender, EventArgs e)
        {
            try
            {
               
                    CustomerRequestBE request = new CustomerRequestBE();

                    request.UserID = Convert.ToInt32(Session["UserID"].ToString());
                    request.OrderStatus = "BOUGHT";

                    customerBAL.Buy(request);

                    lblMsg.Text = "Thank You For Shopping with Us!!!";
                    lblMsg.Visible = true;
                    grdProducts.Visible = false;
                    btnBuy.Visible = false;
            }
            catch(Exception)
            {
                throw;
            }
        }

      
    }
}