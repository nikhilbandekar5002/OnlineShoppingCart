﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BEOnlineShoppingCart;
using DALOnlineShoppingCart;

namespace BALOnlineShoppingCart
{
    public class CustomerBAL
    {
       

        public CustomerResponseBE LoginCredential(CustomerRequestBE request)
        {

            CustomerResponseBE response = null;

            try
            {
                using (CustomerDAL customerDal = new CustomerDAL())
                {
                    response = customerDal.LoginCredential(request);
                    response.IsSuccess = (response.Status >= 1);
                }
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 100;
                response.ErrorMsg = ex.Message;
            }
          
            return response;
        }

        public CustomerResponseBE Register(CustomerRequestBE request)
        {
            CustomerResponseBE response = null;

            try
            {
                using (CustomerDAL customerDal = new CustomerDAL())
                {
                    response = customerDal.Register(request);
                    response.IsSuccess = (response.Status >= 1);
                }
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 101;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }


        public CustomerResponseBE AddOrder(CustomerRequestBE request)
        {
            CustomerResponseBE response = null;

            try
            {
                using (CustomerDAL customerDal = new CustomerDAL())
                {
                    response = customerDal.AddOrder(request);
                    response.IsSuccess = (response.Status >= 1);
                }
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 101;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }


        public CustomerResponseBE FetchProduct()
        {
            CustomerResponseBE response = null;

            try
            {
                using (CustomerDAL customerDal = new CustomerDAL())
                {
                    response = customerDal.FetchProduct();
                    response.IsSuccess = (response.Status >= 1);
                }
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 102;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }


        public CustomerResponseBE FetchOrderHistory(CustomerRequestBE request)
        {
            CustomerResponseBE response = null;

            try
            {
                using (CustomerDAL customerDal = new CustomerDAL())
                {
                    response = customerDal.FetchOrderHistory(request);
                    response.IsSuccess = (response.Status >= 1);
                }
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 103;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }



        public CustomerResponseBE FetchOrderDetails(CustomerRequestBE request)
        {
            CustomerResponseBE response = null;

            try
            {
                using (CustomerDAL customerDal = new CustomerDAL())
                {
                    response = customerDal.FetchOrderDetails(request);
                    response.IsSuccess = (response.Status >= 1);
                }
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 108;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }

        public CustomerResponseBE FetchStates()
        {
            CustomerResponseBE response = null;

            try
            {
                using (CustomerDAL customerDal = new CustomerDAL())
                {
                    response = customerDal.FetchStates();
                    response.IsSuccess = (response.Status >= 1);
                }
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 104;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }



        public CustomerResponseBE FetchCart(CustomerRequestBE request)
        {
            CustomerResponseBE response = null;

            try
            {
                using (CustomerDAL customerDal = new CustomerDAL())
                {
                    response = customerDal.FetchCart(request);
                    response.IsSuccess = (response.Status >= 1);
                }

            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 105;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }


        public CustomerResponseBE Buy(CustomerRequestBE request)
        {
            CustomerResponseBE response = null;

            try
            {
                using (CustomerDAL customerDal = new CustomerDAL())
                {
                    response = customerDal.Buy(request);
                    response.IsSuccess = (response.Status >= 1);
                }
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CustomerResponseBE();
                }

                response.ErrorCode = 106;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }

    }
}
