﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEOnlineShoppingCart
{
    public class Order
    {
        public int OrderID { get; set; }

        public int NoOfItems { get; set; }

        public int TotalCost { get; set; }
    }
}
