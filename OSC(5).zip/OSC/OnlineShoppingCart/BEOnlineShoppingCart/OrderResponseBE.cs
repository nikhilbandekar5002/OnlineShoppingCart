﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEOnlineShoppingCart
{
    public class OrderResponseBE : BaseResponse
    {
        public bool IsSuccess { get; set; }

        public List<ProductInfo> ProductList { get; set; }

        public OrderResponseBE()
        {
            ProductList = new List<ProductInfo>();
        }

    }
}
