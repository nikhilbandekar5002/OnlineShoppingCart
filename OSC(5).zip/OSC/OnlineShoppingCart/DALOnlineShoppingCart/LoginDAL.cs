﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BEOnlineShoppingCart;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace DALOnlineShoppingCart
{
    public class LoginDAL
    {
     
         public static string connectionstr = ConfigurationManager.ConnectionStrings["OnlineShopping"].ConnectionString;
         SqlConnection con = new SqlConnection(connectionstr);

         public UserLoginResponseBE LoginCredential(UserLoginRequestBE request)
         {
             UserLoginResponseBE response = new UserLoginResponseBE();

             try
             {
                 SqlCommand cmd = new SqlCommand("usp_Login", con);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@USERNAME", request.UserName);
                 cmd.Parameters.AddWithValue("@PASSWORD", request.Password);
                 SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                 statusParameter.Direction = ParameterDirection.Output;

                 con.Open();
                 response.UserName = Convert.ToString(cmd.ExecuteScalar());
                 response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);
                 con.Close();
             }
             catch (Exception)
             {
                 throw;
             }

             return response;

         }
    }
}
