﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BALOnlineShoppingCart;
using BEOnlineShoppingCart;
using System.Text;
using LogManager;

namespace OnlineShoppingCart
{
    public partial class OrderHistory : System.Web.UI.Page
    {

        public static CustomerBAL customerBAL = new CustomerBAL();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    BindData();
                }


            }
            catch (Exception ex)
            {
                LogException.Log(ex);
                
            }
        }

        protected void grdProducts_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            { 
                grdProducts.PageIndex = e.NewPageIndex;
                BindData();
            }
            catch (Exception ex)
            {
                LogException.Log(ex);

            }
        }

        public void BindData()
        {
            CustomerRequestBE request = new CustomerRequestBE();

            request.UserID = Convert.ToInt32(Session["UserID"].ToString());
            CustomerResponseBE response = customerBAL.FetchOrderHistory(request);
            grdProducts.DataSource = response.OrderList;
            grdProducts.DataBind();
        }

        protected void mnuOptions_MenuItemClick(object sender, MenuEventArgs e)
        {
            try 
            { 
                MenuItem item = e.Item;

                if (item.Text.Equals("Log Out"))
                {
                    Session.Abandon();
                    Response.Redirect("UserLogin.aspx");
                }
            }
            catch (Exception ex)
            {
                LogException.Log(ex);

            }
        }

        protected void grdProducts_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (e.CommandName == "ViewItems")
                {

                    int index = Convert.ToInt32(e.CommandArgument);

                    GridViewRow row = grdProducts.Rows[index];



                    CustomerRequestBE request = new CustomerRequestBE();

                    request.UserID = Convert.ToInt32(Session["UserID"].ToString());
                    Session["OrderID"] = Convert.ToInt32(row.Cells[0].Text.Trim());


                    Response.Redirect("OrderDetails.aspx");


                }
            }
            catch (Exception ex)
            {
                LogException.Log(ex);
               
            }
        }

      
    }
}