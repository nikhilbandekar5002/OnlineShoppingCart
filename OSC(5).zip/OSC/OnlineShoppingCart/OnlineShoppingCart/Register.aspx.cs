﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BEOnlineShoppingCart;
using BALOnlineShoppingCart;
using LogManager;

namespace OnlineShoppingCart
{
    public partial class Register : System.Web.UI.Page
    {
        public static CustomerBAL customerBAL = new CustomerBAL();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                CustomerRequestBE request = new CustomerRequestBE();

                var response = customerBAL.FetchStates();

                drpState.DataSource = response.States;
                drpState.DataBind();
            }
            catch(Exception ex)
            {
                LogException.Log(ex);
            }

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                CustomerRequestBE request = new CustomerRequestBE();
                request.UserName = txtUserName.Text.Trim();
                request.Password = txtPassword.Text.Trim();
                request.ContactNo = txtContactNo.Text.Trim();
                request.Address = txaAddress.Text.Trim();
                request.Email = txtEmail.Text.Trim();
                request.Married = rdoMarried.SelectedValue.Trim();
                request.State = drpState.SelectedValue.Trim();
                request.ZipCode = txtZipCode.Text.Trim();
                request.DateOfBirth = dateOfBirth.SelectedDate;

                var response = customerBAL.Register(request);

                if (response.Status == 0)
                {
                    lblRegisterMsg.Text = "Username " + request.UserName + " already Exists";
                    lblRegisterMsg.Visible = true;
                }
                else
                {
                    lblRegisterMsg.Text = "Registered Successfully!!!";
                    lblRegisterMsg.Visible = true;
                }
                
            }
            catch(Exception ex)
            {
                LogException.Log(ex);
                
            }
        }
    }
}