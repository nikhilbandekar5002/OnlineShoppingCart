﻿function Focus(objname, waterMarkText) {
    obj = document.getElementById(objname);
    if (obj.value == waterMarkText) {
        obj.value = "";
        obj.className = "NormalTextBox";
    }
}
function Blur(objname, waterMarkText) {
    obj = document.getElementById(objname);
    if (obj.value == "") {
        obj.value = waterMarkText;
        obj.className = "WaterMarkedTextBox";
    }
    else {
        obj.className = "NormalTextBox";
    }
}


$(document).ready(function () {

    $("#form1").validate({
        focusInvalid: false,
        focusCleanup: true,
        debug: false,
        onkeyup: false,
         onclick: true,
         onsubmit: true,
         onkeyup: false,

        rules: {

            txtUserName: { required: true },

            txtContactNo: { required: true, number: true, minlength: 10, maxlength: 10  },
      
            txtEmail: { required: true, email: true },
            txaAddress: { required: true },
            txtZipCode: { maxlength: 6, number: true },
            //rdoMarried: { required: true },
            dateOfBirth_txtCalender: { required: true },
            drpState: { required: true },
            txtPassword: { required: true, minlength: 8, rangelength: [8,12]},
            txtConfirmPass: { required: true, equalTo: "#txtPassword" }
        
           
        


        
        },


        messages: {
            txtUserName: { required: "Please Enter UserName" },

            txtContactNo: {
                required: "Please Enter Contact No.",
                number: "Please Enter Only Digits",
                minlength: "Please Enter 10 Digits"
            },

           

            txtEmail: { required: "Please Enter Email ID", email: "Invalid Email ID" },

            txaAddress: { required: "Please Enter Address" },

            txtZipCode: { maxlength: "Please Enter 6 digits code", number: "Please enter numeric code" },

            //rdoMarried: { required: "Please Select One Option" },

            dateOfBirth_txtCalender: { required: "Please Enter your Date Of Birth" },

            drpState: { required: "Please Select State" },

            txtPassword: { required: "Please Enter Password", minlength: "Password must be minimum 8 characters", rangelength: "Must be Less Than 12 Characters" },

            txtConfirmPass: { required: "Please Re-Enter Password", equalTo: "Password does not match"}




            


            
        }
    });
   
});

jQuery.validator.addClassRules("dateOfBirth", {
    required: true,
    date: true
});


$(function () {
    $("#chkShowPass").bind("click", function () {
        var txtPass = $("[id*=txtPass]");
        if ($(this).is(":checked")) {
            txtPass.after('<input onchange = "PasswordChanged(this);" id = "txt_' + txtPass.attr("id") + '" type = "text" value = "' + txtPass.val() + '" />');
            txtPass.hide();
        } else {
            txtPass.val(txtPass.next().val());
            txtPass.next().remove();
            txtPass.show();
        }
    });
});


function PasswordChanged(txt) {
    $(txt).prev().val($(txt).val());
}