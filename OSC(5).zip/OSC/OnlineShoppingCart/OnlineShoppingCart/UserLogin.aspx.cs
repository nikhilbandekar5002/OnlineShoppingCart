﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BEOnlineShoppingCart;
using BALOnlineShoppingCart;
using LogManager;
namespace OnlineShoppingCart
{
    public partial class UserLogin : System.Web.UI.Page
    {
        CustomerBAL customerBal = new CustomerBAL();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click1(object sender, EventArgs e)
        {
            try
            {
                CustomerRequestBE request = new CustomerRequestBE();
                request.UserName = txtUserName.Text.Trim();
                request.Password = txtPass.Text.Trim();

                var response = customerBal.LoginCredential(request);
                if (response.IsSuccess)
                {
                    Session["UserName"] = response.UserName;
                    Session["UserID"] = response.UserID;
                    Response.Redirect("~/ProductPurchase.aspx");
                }
                else
                {
                    lblErroMsg.Text = "Invalid UserName and Password...";
                    lblErroMsg.Visible = true;
                }
            }
            catch (Exception ex)
            {
                LogException.Log(ex);
            } 
        }

       
    }
}