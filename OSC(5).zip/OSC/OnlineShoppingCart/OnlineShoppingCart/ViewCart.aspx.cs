﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BALOnlineShoppingCart;
using BEOnlineShoppingCart;
using LogManager;

namespace OnlineShoppingCart
{
    public partial class ViewCart : System.Web.UI.Page
    {

        public static CustomerBAL customerBAL = new CustomerBAL();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    BindData();
                }
            }
            catch (Exception ex)
            {
                LogException.Log(ex);
                
            }
        }

        protected void grdProducts_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdProducts.PageIndex = e.NewPageIndex;
                BindData();
            }
            catch (Exception ex)
            {
                LogException.Log(ex);
                
            }


        }

        public void BindData()
        {
            CustomerRequestBE request = new CustomerRequestBE();

            request.UserID = Convert.ToInt32(Session["UserID"].ToString());

            CustomerResponseBE response = customerBAL.FetchCart(request);

            if (response.ProductList.Count != 0)
            {
                grdProducts.DataSource = response.ProductList;
                grdProducts.DataBind();
                lblMsg.Visible = false;
            }
            else
            {
                lblMsg.Visible = true;
                grdProducts.Visible = false;
            }
        }

        protected void grdProducts_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (e.CommandName == "UpdateCart")
                {

                    int index = Convert.ToInt32(e.CommandArgument);

                    GridViewRow row = grdProducts.Rows[index];



                    CustomerRequestBE request = new CustomerRequestBE();

                    request.UserID = Convert.ToInt32(Session["UserID"].ToString());
                    request.Product = row.Cells[0].Text.Trim();
                    request.Quantity = Convert.ToInt32((row.FindControl("nudQuantity") as UserControls.NumericUpDown).EnteredNumber);
                    request.Price = Convert.ToInt32(row.Cells[2].Text.Trim()) * request.Quantity;
                    request.OrderStatus = "ADDEDTOCART";

                    
                    customerBAL.AddOrder(request);
                    

                }
            }
            catch (Exception ex)
            {
                LogException.Log(ex);
               
            }
        }

        protected void btnBuy_Click(object sender, EventArgs e)
        {
            try
            {
               
                    CustomerRequestBE request = new CustomerRequestBE();

                    request.UserID = Convert.ToInt32(Session["UserID"].ToString());
                    request.OrderStatus = "BOUGHT";

                    var response = customerBAL.Buy(request);

                    if (response.Status > 0)
                    {
                        lblMsg.Text = "Thank You For Shopping with Us!!!";
                        lblMsg.Visible = true;
                        grdProducts.Visible = false;
                        btnBuy.Visible = false;
                    }
            }
            catch(Exception ex)
            {
                LogException.Log(ex);
            }
        }

        protected void mnuOptions_MenuItemClick(object sender, MenuEventArgs e)
        {
            try
            {
                MenuItem item = e.Item;

                if (item.Text.Equals("Log Out"))
                {
                    Session.Abandon();
                    Response.Redirect("UserLogin.aspx");
                }
            }
            catch(Exception ex)
            {
                LogException.Log(ex);
            }
        }

      
    }
}