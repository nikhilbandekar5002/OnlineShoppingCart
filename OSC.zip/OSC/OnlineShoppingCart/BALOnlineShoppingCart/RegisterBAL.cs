﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BEOnlineShoppingCart;
using DALOnlineShoppingCart;

namespace BALOnlineShoppingCart
{
    public class RegisterBAL
    {
        public static RegisterDAL registerDal = new RegisterDAL();

        public RegisterResponseBE LoginCredential(RegisterRequestBE request)
        {
            RegisterResponseBE response = null;

            try
            {
                response = registerDal.LoginCredential(request);
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new RegisterResponseBE();
                }

                response.ErrorCode = 101;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }
    }
}
