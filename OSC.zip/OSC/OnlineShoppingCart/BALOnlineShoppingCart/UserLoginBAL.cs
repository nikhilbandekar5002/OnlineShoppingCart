﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BEOnlineShoppingCart;
using DALOnlineShoppingCart;

namespace BALOnlineShoppingCart
{
    public class UserLoginBAL
    {

        LoginDAL loginDal = new LoginDAL();

        public UserLoginResponseBE LoginCredential(UserLoginRequestBE request)
        {
            UserLoginResponseBE response = null;

            try
            {
                response = loginDal.LoginCredential(request);
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new UserLoginResponseBE();
                }

                response.ErrorCode = 100;
                response.ErrorMsg = ex.Message;
            }

            return response;
        }
    }
}
