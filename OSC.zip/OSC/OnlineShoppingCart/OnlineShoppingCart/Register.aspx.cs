﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BEOnlineShoppingCart;
using BALOnlineShoppingCart;

namespace OnlineShoppingCart
{
    public partial class Register : System.Web.UI.Page
    {
        public static RegisterBAL registerBAL = new RegisterBAL();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                RegisterRequestBE request = new RegisterRequestBE();
                request.UserName = txtUserName.Text.Trim();
                request.Password = txtPassword.Text.Trim();
                request.ContactNo = txtContactNo.Text.Trim();
                request.Address = txaAddress.Text.Trim();
                request.Email = txtEmail.Text.Trim();
                request.Married = rdoMarried.SelectedValue.Trim();
                request.State = drpState.SelectedValue.Trim();
                request.ZipCode = txtZipCode.Text.Trim();
                request.Age = Convert.ToInt32(txtAge.Text.Trim());
                request.DateOfJoin = dateOfJoin.SelectedDate;

                registerBAL.LoginCredential(request);
                
            }
            catch(Exception)
            {
                throw;
            }
        }
    }
}