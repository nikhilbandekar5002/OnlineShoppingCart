﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BEOnlineShoppingCart;
using BALOnlineShoppingCart;

namespace OnlineShoppingCart
{
    public partial class UserLogin : System.Web.UI.Page
    {
        UserLoginBAL loginBal = new UserLoginBAL();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                UserLoginRequestBE request = new UserLoginRequestBE();
                request.UserName = txtUserName.Text.Trim();
                request.Password = txtPassword.Text.Trim();

                var response = loginBal.LoginCredential(request);
                if (response.IsSuccess)
                {
                    Session["Name"] = response.UserName;
                    Response.Redirect("~/Home.aspx");
                }
                else
                {
                    lblErroMsg.Text = "Invalid UserName and Password...";
                }
            }
            catch (Exception)
            {

                throw;
            } 
        }
    }
}